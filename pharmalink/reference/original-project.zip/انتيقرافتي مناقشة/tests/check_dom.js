const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');

const requiredIds = [
    'view-dashboard',
    'branchChainBadgeContainer',
    'dashBranchName',
    'dashChainName',
    'metaLastSyncTime',
    'metaDataSource',
    'btnImportInventoryTop',
    'btnAddItemManualTop',
    'btnRequestNeedTop',
    'branchActionableAlerts',
    'branchOperationalGrid',
    'valOpNearExpiry',
    'valOpPendingB2B',
    'valOpTransfersAction',
    'valOpTransfersInTransit',
    'valOpDiscrepancies',
    'excelToggleBar',
    'excelHeroSection',
    'inventoryFiltersContainer',
    'inventorySearchInput',
    'inventoryResultsCount',
    'f-ext-ALL',
    'f-ext-NOT_PUBLISHED',
    'f-ext-PENDING_APPROVAL',
    'f-ext-PUBLISHED',
    'f-int-ALL',
    'f-int-SURPLUS_POSTED',
    'f-int-HAS_RESERVATION',
    'f-exp-ALL',
    'f-exp-NEAR_EXPIRY',
    'f-exp-EXPIRED',
    'myListingsTable',
    'myListingsTbody',
    'dashboardHelpBody',
    'branchItemActionModal',
    'branchModalDrugInfoCard',
    'btnTabAction-SURPLUS',
    'btnTabAction-TRANSFER',
    'btnTabAction-EXTERNAL_SALE',
    'btnTabAction-LEDGER',
    'btnTabAction-ADJUSTMENT',
    'paneAction-SURPLUS',
    'paneAction-TRANSFER',
    'paneAction-EXTERNAL_SALE',
    'paneAction-LEDGER',
    'paneAction-ADJUSTMENT',
    'surplusModalQty',
    'transferModalTargetBranch',
    'transferModalQty',
    'externalSaleModalQty',
    'needRequestModal',
    'importInventoryModal'
];

let missing = [];
requiredIds.forEach(id => {
    if (!html.includes('id="' + id + '"')) {
        missing.push(id);
    }
});

console.log('Total required IDs checked:', requiredIds.length);
console.log('Missing IDs:', missing);
if (missing.length === 0) {
    console.log('ALL REQUIRED DOM ELEMENTS ARE PRESENT IN INDEX.HTML!');
}
