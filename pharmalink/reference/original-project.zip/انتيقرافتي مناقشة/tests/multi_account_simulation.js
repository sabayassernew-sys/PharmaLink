/**
 * PharmaLink - Multi-Account End-to-End Simulation Test
 * Simulates real user sessions: Branch A (Hadda), Branch B (Sabeen), and Central Management (Al-Shifa).
 */

const assert = require('assert');
const TransferService = require('../js/transferService');

console.log('================================================================');
console.log('  PharmaLink Multi-Account Session Simulation                   ');
console.log('================================================================\n');

const DB_SEED = {
    chains: {
        agency_shifa: {
            id: 'agency_shifa',
            name: 'مجموعة صيدليات الشفاء التخصصية',
            default_policy: 'centralized'
        }
    },
    pharmacies: {
        pharm_agency_01: {
            id: 'pharm_agency_01',
            chain_id: 'agency_shifa',
            name: 'صيدلية الشفاء - فرع حدة',
            pharmacist_name: 'د. أحمد الصنعاني'
        },
        pharm_agency_02: {
            id: 'pharm_agency_02',
            chain_id: 'agency_shifa',
            name: 'صيدلية الشفاء - فرع السبعين',
            pharmacist_name: 'د. عبدالكريم طاهر'
        }
    },
    inventory: {
        inv_aug_hadda: {
            id: 'inv_aug_hadda',
            pharmacy_id: 'pharm_agency_01',
            brand_name: 'أوجمنتين Augmentin 1g',
            batch_number: 'BT-88421',
            expiry_date: '2026-12-15',
            unit: 'باكت',
            physical_quantity: 30,
            quarantine_quantity: 0
        }
    },
    reservations: [],
    transfers: [],
    discrepancies: [],
    movements: []
};

// Sessions
const SESSION_SABEEN_BRANCH = {
    userId: 'د. عبدالكريم طاهر',
    role: 'agency_branch',
    pharmacyId: 'pharm_agency_02',
    chainId: 'agency_shifa'
};

const SESSION_HADDA_BRANCH = {
    userId: 'د. أحمد الصنعاني',
    role: 'agency_branch',
    pharmacyId: 'pharm_agency_01',
    chainId: 'agency_shifa'
};

const SESSION_MANAGEMENT = {
    userId: 'د. عبدالكريم طاهر (المدير العام)',
    role: 'agency_master',
    pharmacyId: null,
    chainId: 'agency_shifa'
};

async function runMultiAccountSimulation() {
    TransferService.initDatabase(DB_SEED);

    console.log('1. [جلسة فرع السبعين]: تسجيل دخول الفرع الطالب وإنشاء طلب احتياج بـ 10 باكت من فرع حدة');
    const req = await TransferService.createTransferRequest(SESSION_SABEEN_BRANCH, {
        fromPharmacyId: 'pharm_agency_01',
        toPharmacyId: 'pharm_agency_02',
        items: [{ inventoryItemId: 'inv_aug_hadda', quantity: 10 }],
        reason: 'نقص حاد بالسبعين لتغطية وصفات عيادات الأطفال'
    });
    assert(req.success);
    const transferId = req.transfer.id;
    console.log(`   -> تم إنشاء الطلب برمز: ${req.transfer.transfer_code}، الحالة: ${req.transfer.status}`);

    console.log('\n2. [جلسة فرع حدة]: تسجيل دخول الفرع المانح وفحص وموافقة وتخصيص المخزون');
    const senderStockBefore = TransferService.getItemAvailability('inv_aug_hadda');
    console.log(`   -> رصيد حدة قبل الموافقة: الموجود ${senderStockBefore.physicalQuantity}، المتاح ${senderStockBefore.availableQuantity}`);

    const alloc = await TransferService.approveSenderAllocation(SESSION_HADDA_BRANCH, { transferId });
    assert(alloc.success);
    const senderStockAfterAlloc = TransferService.getItemAvailability('inv_aug_hadda');
    console.log(`   -> رصيد حدة بعد الموافقة: الموجود ${senderStockAfterAlloc.physicalQuantity}، المحجوز النشط ${senderStockAfterAlloc.activeReservations}، المتاح ${senderStockAfterAlloc.availableQuantity}`);
    assert.strictEqual(senderStockAfterAlloc.physicalQuantity, 30);
    assert.strictEqual(senderStockAfterAlloc.activeReservations, 10);
    assert.strictEqual(senderStockAfterAlloc.availableQuantity, 20);

    console.log('\n3. [جلسة الإدارة العامة]: مراجعة لوحة الاعتمادات المركزية واعتماد الطلب');
    const mgmt = await TransferService.approveManagement(SESSION_MANAGEMENT, {
        transferId,
        reason: 'معتمد للمصلحة العامة'
    });
    assert(mgmt.success);
    console.log(`   -> اعتمدت الإدارة المناقلة، الحالة: ${mgmt.transfer.status}`);
    assert.strictEqual(mgmt.transfer.status, 'approved_and_reserved');

    console.log('\n4. [جلسة فرع حدة]: تأكيد إرسال المناقلة (دون اشتراط بيانات نقل - يُرتّب النقل بين الفرعين خارج المنصة) وخصم المخزون لمرة واحدة');
    const dispatch = await TransferService.dispatchTransfer(SESSION_HADDA_BRANCH, {
        transferId,
        notes: 'تم تجهيز وإرسال الشحنة وفق الترتيب الخارجي المتفق عليه'
    });
    assert(dispatch.success);
    assert.strictEqual(dispatch.transfer.status, 'in_transit');
    assert.strictEqual(dispatch.transfer.dispatched_by, SESSION_HADDA_BRANCH.userId);
    assert(dispatch.transfer.dispatched_at != null);
    const senderStockAfterDispatch = TransferService.getItemAvailability('inv_aug_hadda');
    console.log(`   -> رصيد حدة بعد الإرسال: الموجود ${senderStockAfterDispatch.physicalQuantity}، المحجوز النشط ${senderStockAfterDispatch.activeReservations} (الحجز أصبح مستهلكاً: ${senderStockAfterDispatch.consumedReservations})`);
    assert.strictEqual(senderStockAfterDispatch.physicalQuantity, 20);
    assert.strictEqual(senderStockAfterDispatch.activeReservations, 0);
    assert.strictEqual(senderStockAfterDispatch.consumedReservations, 10);

    console.log('\n5. [جلسة فرع السبعين]: فحص الشحنة، تسجيل 9 عبوات مقبولة و1 عبوة تالفة لضبط الأرصدة دون مطالبات مالية للنقل');
    const lineId = dispatch.transfer.items[0].id;
    const recv = await TransferService.receiveTransfer(SESSION_SABEEN_BRANCH, {
        transferId,
        receiptLines: [
            {
                itemId: lineId,
                accepted: 9,
                rejected: 1,
                missing: 0,
                rejectReason: 'عبوة واحدة مسحوقة أثناء التحميل في الصندوق'
            }
        ]
    });
    assert(recv.success);
    console.log(`   -> حالة المناقلة بعد الاستلام: ${recv.transfer.status}`);
    assert.strictEqual(recv.transfer.status, 'needs_discrepancy_resolution');

    // Receiver Stock verification
    const receiverItem = Object.values(TransferService.getState().inventory).find(
        i => i.pharmacy_id === 'pharm_agency_02' && i.batch_number === 'BT-88421'
    );
    assert(receiverItem != null);
    console.log(`   -> رصيد السبعين: المتاح السليم=${receiverItem.physical_quantity}، في الحجر الصحي=${receiverItem.quarantine_quantity}`);
    assert.strictEqual(receiverItem.physical_quantity, 9);
    assert.strictEqual(receiverItem.quarantine_quantity, 1);

    // Sender Stock remains intact
    const senderFinal = TransferService.getItemAvailability('inv_aug_hadda');
    assert.strictEqual(senderFinal.physicalQuantity, 20);

    console.log('\n6. التدقيق المحاسبي لحركات الأستاذ (Audit Ledger Movements):');
    const movements = TransferService.getState().movements;
    console.log(`   -> إجمالي الحركات الموثقة غير القابلة للتعديل: ${movements.length} حركة.`);
    movements.forEach((m, idx) => {
        console.log(`      [${idx + 1}] ${m.movement_type}: دلتا فعلي (${m.delta_physical}) | دلتا حجر (${m.delta_quarantine}) | المنفذ: ${m.actor_id}`);
    });

    console.log('\n✅ اكتملت محاكاة الجلسات المتعددة ومطابقة الأرصدة بنجاح تام 100%!');
}

runMultiAccountSimulation();
