/**
 * PharmaLink - Automated End-to-End Acceptance Tests
 * Validates Security Contexts, Atomic Transactions, Idempotency, Concurrency, and Inventory Balances.
 */

const assert = require('assert');
const TransferService = require('../js/transferService');

console.log('================================================================');
console.log('  PharmaLink Internal Transfer System - Automated Test Suite    ');
console.log('================================================================\n');

// 1. Setup Mock Database Seed
const SEED_DATA = {
    chains: {
        agency_shifa: {
            id: 'agency_shifa',
            name: 'مجموعة صيدليات الشفاء التخصصية',
            default_policy: 'centralized',
            announcement_sla_hours: 48,
            reservation_sla_hours: 24
        }
    },
    pharmacies: {
        pharm_agency_01: {
            id: 'pharm_agency_01',
            chain_id: 'agency_shifa',
            name: 'صيدلية الشفاء - فرع حدة',
            pharmacist_name: 'د. أحمد الصنعاني',
            city: 'صنعاء'
        },
        pharm_agency_02: {
            id: 'pharm_agency_02',
            chain_id: 'agency_shifa',
            name: 'صيدلية الشفاء - فرع السبعين',
            pharmacist_name: 'د. عبدالكريم طاهر',
            city: 'صنعاء'
        },
        pharm_external: {
            id: 'pharm_external',
            chain_id: 'other_chain',
            name: 'صيدلية خارج السلسلة',
            pharmacist_name: 'د. خارجي',
            city: 'عدن'
        }
    },
    inventory: {
        inv_test_item_01: {
            id: 'inv_test_item_01',
            pharmacy_id: 'pharm_agency_01',
            brand_name: 'كلكسان Clexane 40mg',
            batch_number: 'CX-TEST-2026',
            expiry_date: '2027-01-20',
            unit: 'باكت',
            physical_quantity: 20, // Exact initial amount: 20
            quarantine_quantity: 0,
            original_price: 8500
        }
    },
    reservations: [],
    transfers: [],
    discrepancies: [],
    movements: []
};

// Security Contexts for Simulated Distinct Users
const SENDER_CONTEXT = {
    userId: 'usr_branch_hadda',
    role: 'agency_branch',
    pharmacyId: 'pharm_agency_01',
    chainId: 'agency_shifa'
};

const RECEIVER_CONTEXT = {
    userId: 'usr_branch_sabeen',
    role: 'agency_branch',
    pharmacyId: 'pharm_agency_02',
    chainId: 'agency_shifa'
};

const MANAGEMENT_CONTEXT = {
    userId: 'usr_agency_master',
    role: 'agency_master',
    pharmacyId: null,
    chainId: 'agency_shifa'
};

const EXTERNAL_CONTEXT = {
    userId: 'usr_external_pharmacy',
    role: 'independent',
    pharmacyId: 'pharm_external',
    chainId: 'other_chain'
};

async function runTests() {
    let passedCount = 0;
    let failedCount = 0;

    function test(name, fn) {
        return Promise.resolve()
            .then(fn)
            .then(() => {
                console.log(`  ✅ [PASS] ${name}`);
                passedCount++;
            })
            .catch(err => {
                console.error(`  ❌ [FAIL] ${name}`);
                console.error(`     Error: ${err.message}\n`);
                failedCount++;
            });
    }

    // Reset database
    TransferService.initDatabase(SEED_DATA);

    console.log('--- المجموعة 1: أمان الصلاحيات وعزل الفروع (Security & RLS) ---');

    await test('1.1 منع إنشاء مناقلة بين فرعين من سلسلتين مختلفتين', async () => {
        try {
            await TransferService.createTransferRequest(SENDER_CONTEXT, {
                fromPharmacyId: 'pharm_agency_01',
                toPharmacyId: 'pharm_external', // Cross-chain
                items: [{ inventoryItemId: 'inv_test_item_01', quantity: 5 }]
            });
            assert.fail('Should have thrown validation error for cross-chain transfer');
        } catch (err) {
            assert(err.message.includes('Internal transfers must be strictly within the same chain'));
        }
    });

    await test('1.2 منع فرع من إنشاء مناقلة لنفس الفرع (from == to)', async () => {
        try {
            await TransferService.createTransferRequest(SENDER_CONTEXT, {
                fromPharmacyId: 'pharm_agency_01',
                toPharmacyId: 'pharm_agency_01',
                items: [{ inventoryItemId: 'inv_test_item_01', quantity: 5 }]
            });
            assert.fail('Should have thrown validation error for same branch');
        } catch (err) {
            assert(err.message.includes('Sender and Receiver branches must be different'));
        }
    });

    let transferId = null;

    await test('1.3 إنشاء طلب مناقلة نظامي بين فرع حدة وفرع السبعين', async () => {
        const res = await TransferService.createTransferRequest(RECEIVER_CONTEXT, {
            fromPharmacyId: 'pharm_agency_01',
            toPharmacyId: 'pharm_agency_02',
            items: [{ inventoryItemId: 'inv_test_item_01', quantity: 10 }],
            reason: 'تغطية نقص عاجل في عيادة السبعين'
        });
        assert(res.success === true);
        assert(res.transfer.status === 'pending_counterpart_approval');
        assert(res.transfer.platform_fee === 0.00); // 0 commission
        transferId = res.transfer.id;
    });

    await test('1.4 منع الفرع المستلم أو طرف خارجي من اعتماد تخصيص مخزون المرسل نيابة عنه', async () => {
        try {
            // Receiver attempts to approve sender's inventory allocation!
            await TransferService.approveSenderAllocation(RECEIVER_CONTEXT, { transferId });
            assert.fail('Should have rejected receiver from approving sender allocation');
        } catch (err) {
            assert(err.code === 'CROSS_BRANCH_FORBIDDEN');
        }
    });

    console.log('\n--- المجموعة 2: حسابات المخزون والحجز الذري والتعامل المتزامن ---');

    await test('2.1 التحقق من الرصيد المبدئي للمرسل (20 موجود، 0 محجوز، 20 متاح)', async () => {
        const avail = TransferService.getItemAvailability('inv_test_item_01');
        assert.strictEqual(avail.physicalQuantity, 20);
        assert.strictEqual(avail.activeReservations, 0);
        assert.strictEqual(avail.availableQuantity, 20);
    });

    await test('2.2 منع الحجز المتزامن الذي يتجاوز المتاح (طلبين بـ 15 عبوة)', async () => {
        // Create 2 separate transfer requests for 15 each (Total 30 > 20 Available)
        const reqA = await TransferService.createTransferRequest(RECEIVER_CONTEXT, {
            fromPharmacyId: 'pharm_agency_01',
            toPharmacyId: 'pharm_agency_02',
            items: [{ inventoryItemId: 'inv_test_item_01', quantity: 15 }]
        });
        const reqB = await TransferService.createTransferRequest(RECEIVER_CONTEXT, {
            fromPharmacyId: 'pharm_agency_01',
            toPharmacyId: 'pharm_agency_02',
            items: [{ inventoryItemId: 'inv_test_item_01', quantity: 15 }]
        });

        // Sender approves A first (reserves 15 -> 5 left)
        const resA = await TransferService.approveSenderAllocation(SENDER_CONTEXT, { transferId: reqA.transfer.id });
        assert(resA.success === true);

        // Sender attempts to approve B (requires 15, but only 5 available!)
        try {
            await TransferService.approveSenderAllocation(SENDER_CONTEXT, { transferId: reqB.transfer.id });
            assert.fail('Should have blocked second allocation exceeding available quantity');
        } catch (err) {
            assert(err.code === 'INSUFFICIENT_AVAILABLE_STOCK');
        }

        // Cancel A to restore clean state for the main calculation test
        await TransferService.cancelOrRejectTransfer(SENDER_CONTEXT, {
            transferId: reqA.transfer.id,
            action: 'CANCEL',
            reason: 'إلغاء اختبار التزامن'
        });

        const restoredAvail = TransferService.getItemAvailability('inv_test_item_01');
        assert.strictEqual(restoredAvail.availableQuantity, 20);
    });

    console.log('\n--- المجموعة 3: مسار المناقلة الإلزامي (السيناريو الحسابي المطلوب بالحرف) ---');

    await test('3.1 تخصيص 10 عبوات للمناقلة: الموجود 20، المحجوز 10، المتاح 10', async () => {
        const res = await TransferService.approveSenderAllocation(SENDER_CONTEXT, { transferId });
        assert(res.success === true);
        // Centralized policy requires management approval next
        assert.strictEqual(res.transfer.status, 'pending_management_approval');

        const avail = TransferService.getItemAvailability('inv_test_item_01');
        assert.strictEqual(avail.physicalQuantity, 20, 'الموجود فعلياً يجب أن يظل 20 قبل الإرسال');
        assert.strictEqual(avail.activeReservations, 10, 'المحجوز النشط يجب أن يصبح 10');
        assert.strictEqual(avail.availableQuantity, 10, 'المتاح يجب أن يصبح 10');
    });

    await test('3.2 اعتماد الإدارة المركزية وحفظ السياسة', async () => {
        const res = await TransferService.approveManagement(MANAGEMENT_CONTEXT, {
            transferId,
            reason: 'معتمد للمصلحة العامة'
        });
        assert(res.success === true);
        assert.strictEqual(res.transfer.status, 'approved_and_reserved');
    });

    await test('3.3 تأكيد إرسال 10 عبوات دون اشتراط بيانات نقل: تسجيل المستخدم والوقت، خصم الموجود لمرة واحدة، الحجز يصبح «مستهلكاً»، الحالة «تم الإرسال — بانتظار الاستلام»', async () => {
        const idempotencyKey = 'DISPATCH-KEY-001';
        const res = await TransferService.dispatchTransfer(SENDER_CONTEXT, {
            transferId,
            notes: 'تم الترتيب للنقل خارج المنصة مباشرة بين الصيدليتين',
            idempotencyKey
        });

        assert(res.success === true);
        assert.strictEqual(res.transfer.status, 'in_transit');
        assert.strictEqual(res.transfer.dispatched_by, SENDER_CONTEXT.userId);
        assert(res.transfer.dispatched_at != null);
        assert.strictEqual(res.transfer.platform_fee, 0.00);

        // Check Inventory at Sender
        const avail = TransferService.getItemAvailability('inv_test_item_01');
        assert.strictEqual(avail.physicalQuantity, 10, 'الموجود لدى المرسل يجب أن ينخفض إلى 10');
        assert.strictEqual(avail.activeReservations, 0, 'حجز المناقلة النشط يجب أن يصبح صفراً');
        assert.strictEqual(avail.consumedReservations, 10, 'الحجز يجب أن ينتقل لحالة مستهلك');
        assert.strictEqual(avail.availableQuantity, 10, 'المتاح يظل 10');

        // Test Idempotency: Repeating dispatch with same key must NOT double-deduct
        const repeatRes = await TransferService.dispatchTransfer(SENDER_CONTEXT, {
            transferId,
            notes: 'إعادة إرسال متكررة لنفس المفتاح',
            idempotencyKey
        });
        assert(repeatRes.success === true);
        const availAfterRepeat = TransferService.getItemAvailability('inv_test_item_01');
        assert.strictEqual(availAfterRepeat.physicalQuantity, 10, 'إعادة الإرسال لنفس المفتاح لا تخصم الرصيد مرتين');
    });

    await test('3.4 استلام 8 مقبولة و1 مرفوضة و1 ناقصة (معادلة التوازن: 10 = 8 + 1 + 1) دون تحميل مسؤولية مالية تلقائية للنقل', async () => {
        const state = TransferService.getState();
        const transfer = state.transfers.find(t => t.id === transferId);
        const lineItemId = transfer.items[0].id;

        // Attempt invalid balance (8 + 1 + 0 = 9 != 10)
        try {
            await TransferService.receiveTransfer(RECEIVER_CONTEXT, {
                transferId,
                receiptLines: [{
                    itemId: lineItemId,
                    accepted: 8,
                    rejected: 1,
                    missing: 0
                }]
            });
            assert.fail('Should have rejected unbalanced receipt calculation');
        } catch (err) {
            assert(err.message.includes('Mathematical Balance Error'));
        }

        // Execute balanced receipt: 8 accepted, 1 rejected, 1 missing
        const res = await TransferService.receiveTransfer(RECEIVER_CONTEXT, {
            transferId,
            receiptLines: [{
                itemId: lineItemId,
                accepted: 8,
                rejected: 1,
                missing: 1,
                rejectReason: 'عبوة مكسورة مسربة للسائل',
                missingReason: 'نقص باكت واحد عند استلام الطرد'
            }]
        });

        assert(res.success === true);
        assert.strictEqual(res.transfer.status, 'needs_discrepancy_resolution');

        // Check Receiver Stock
        const destInv = Object.values(TransferService.getState().inventory).find(
            i => i.pharmacy_id === 'pharm_agency_02' && i.batch_number === 'CX-TEST-2026'
        );
        assert(destInv != null);
        assert.strictEqual(destInv.physical_quantity, 8, 'يضاف 8 فقط إلى المتاح لدى المستلم');
        assert.strictEqual(destInv.quarantine_quantity, 1, 'تظل العبوة المرفوضة في عهدة الحجر الصحي المنفصلة');

        // Check Discrepancies
        const discrepancies = TransferService.getState().discrepancies.filter(d => d.transfer_id === transferId);
        assert.strictEqual(discrepancies.length, 2);

        const rejectedDisc = discrepancies.find(d => d.discrepancy_type === 'rejected_damaged');
        assert.strictEqual(rejectedDisc.quantity, 1);
        assert.strictEqual(rejectedDisc.resolution_status, 'pending_investigation');
        assert.strictEqual(rejectedDisc.financial_claim_status, 'none', 'عدم تحميل السائق أو أي طرف مسؤولية مالية تلقائياً');

        const missingDisc = discrepancies.find(d => d.discrepancy_type === 'missing_investigation');
        assert.strictEqual(missingDisc.quantity, 1);
        assert.strictEqual(missingDisc.resolution_status, 'pending_investigation');
        assert.strictEqual(missingDisc.financial_claim_status, 'none', 'المنصة تسجل الاختلاف المخزني ومعالجته المعتمدة فقط');

        // Ensure missing does NOT return automatically to sender
        const senderAvail = TransferService.getItemAvailability('inv_test_item_01');
        assert.strictEqual(senderAvail.physicalQuantity, 10, 'لا تعاد أي كمية للمرسل تلقائياً');
    });

    console.log('\n--- المجموعة 4: فحص استيراد ملفات الإكسل المحاسبية والتعارضات ---');

    await test('4.1 تعليق تحديث الأصناف المرتبطة بمناقلات مفتوحة دون منع استيراد الأصناف الأخرى', async () => {
        const excelRows = [
            {
                brand_name: 'كلكسان Clexane 40mg',
                batch_number: 'CX-TEST-2026',
                quantity: 40 // Item in open transfer with discrepancies!
            },
            {
                brand_name: 'بانادول Panadol 500mg',
                batch_number: 'PD-NEW-88',
                quantity: 100 // Unaffected item
            }
        ];

        const report = await TransferService.previewAndReconcileExcelImport(SENDER_CONTEXT, {
            pharmacyId: 'pharm_agency_01',
            excelRows
        });

        assert.strictEqual(report.summary.suspendedCount, 1, 'يجب تعليق صنف كلكسان لوجود مناقلة واختلاف مفتوح');
        assert.strictEqual(report.suspendedForReview[0].item.brand_name, 'كلكسان Clexane 40mg');
        assert.strictEqual(report.summary.readyCount, 1, 'يجب السماح باستيراد صنف بانادول الجديد');
        assert.strictEqual(report.readyToImport[0].item.brand_name, 'بانادول Panadol 500mg');
    });

    console.log('\n================================================================');
    console.log(`  نتائج الاختبارات: إجمالي ${passedCount + failedCount} | ناجح: ${passedCount} | فاشل: ${failedCount}`);
    console.log('================================================================\n');

    if (failedCount > 0) {
        process.exit(1);
    }
}

runTests();
