/**
 * PharmaLink - Enterprise Internal Transfer Core Engine (Server-Parity Service)
 * Fully atomic, concurrency-safe, idempotent transactional engine with RLS & permission guards.
 * Works in both Node.js (Automated Tests) and Browser Environment.
 */

(function (root, factory) {
    if (typeof module === 'object' && module.exports) {
        module.exports = factory();
    } else {
        root.TransferService = factory();
    }
}(typeof self !== 'undefined' ? self : this, function () {

    // In-memory persistent stores (Server Datastore Simulation)
    let _chains = {};
    let _pharmacies = {};
    let _users = {};
    let _inventory = {};
    let _reservations = [];
    let _transfers = [];
    let _discrepancies = [];
    let _movements = [];
    let _idempotencyStore = {};

    // Concurrency Lock (Mutex Queue)
    let _mutexQueue = Promise.resolve();
    function runWithLock(operation) {
        const nextInQueue = _mutexQueue.then(() => {
            return Promise.resolve().then(operation);
        }).catch(err => {
            throw err;
        });
        _mutexQueue = nextInQueue.then(() => {}, () => {});
        return nextInQueue;
    }

    // Helper: Generate unique IDs
    function genId(prefix) {
        return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 6)}`.toUpperCase();
    }

    // Helper: Clone data
    function clone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }

    // Helper: Compute Available Quantity
    function getAvailableQuantity(itemId) {
        const item = _inventory[itemId];
        if (!item) return 0;
        const activeReserved = _reservations
            .filter(r => r.inventory_item_id === itemId && r.status === 'active')
            .reduce((sum, r) => sum + r.reserved_quantity, 0);
        return Math.max(0, item.physical_quantity - activeReserved);
    }

    // Helper: Assert Security Context
    function assertSecurity(context, requiredRole, branchConstraint) {
        if (!context || !context.userId) {
            const err = new Error('401 Unauthorized: Valid security context is required');
            err.code = 'UNAUTHORIZED';
            throw err;
        }
        if (requiredRole && context.role !== requiredRole && context.role !== 'admin') {
            const err = new Error(`403 Forbidden: Action requires role [${requiredRole}]`);
            err.code = 'FORBIDDEN_ROLE';
            throw err;
        }
        if (branchConstraint && context.role === 'agency_branch') {
            if (context.pharmacyId !== branchConstraint) {
                const err = new Error(`403 Forbidden: Cannot perform actions on behalf of another branch (${branchConstraint})`);
                err.code = 'CROSS_BRANCH_FORBIDDEN';
                throw err;
            }
        }
    }

    return {
        // Initialize or seed data
        initDatabase(seed) {
            _chains = clone(seed.chains || {});
            _pharmacies = clone(seed.pharmacies || {});
            _users = clone(seed.users || {});
            _inventory = clone(seed.inventory || {});
            _reservations = clone(seed.reservations || []);
            _transfers = clone(seed.transfers || []);
            _discrepancies = clone(seed.discrepancies || []);
            _movements = clone(seed.movements || []);
            _idempotencyStore = {};
        },

        // Expose state snapshots (read-only)
        getState() {
            return {
                chains: clone(_chains),
                pharmacies: clone(_pharmacies),
                inventory: clone(_inventory),
                reservations: clone(_reservations),
                transfers: clone(_transfers),
                discrepancies: clone(_discrepancies),
                movements: clone(_movements)
            };
        },

        // Availability Calculation Engine
        getItemAvailability(itemId) {
            const item = _inventory[itemId];
            if (!item) return null;
            const activeReservations = _reservations
                .filter(r => r.inventory_item_id === itemId && r.status === 'active')
                .reduce((sum, r) => sum + r.reserved_quantity, 0);
            const consumedReservations = _reservations
                .filter(r => r.inventory_item_id === itemId && r.status === 'consumed')
                .reduce((sum, r) => sum + r.reserved_quantity, 0);

            return {
                itemId: item.id,
                brandName: item.brand_name,
                batchNumber: item.batch_number,
                unit: item.unit || 'باكت',
                physicalQuantity: item.physical_quantity,
                activeReservations: activeReservations,
                consumedReservations: consumedReservations,
                availableQuantity: Math.max(0, item.physical_quantity - activeReservations),
                quarantineQuantity: item.quarantine_quantity || 0
            };
        },

        // RPC 1: Create Transfer Request
        createTransferRequest(context, payload) {
            return runWithLock(() => {
                assertSecurity(context, null);

                const { fromPharmacyId, toPharmacyId, items, reason, policyApplied, idempotencyKey } = payload;

                if (idempotencyKey && _idempotencyStore[idempotencyKey]) {
                    return clone(_idempotencyStore[idempotencyKey]);
                }

                // Validation 1: Distinct branches
                if (fromPharmacyId === toPharmacyId) {
                    throw new Error('Validation Error: Sender and Receiver branches must be different');
                }

                // Validation 2: Same chain constraint
                const fromBranch = _pharmacies[fromPharmacyId];
                const toBranch = _pharmacies[toPharmacyId];
                if (!fromBranch || !toBranch) {
                    throw new Error('Validation Error: Invalid branch IDs provided');
                }
                if (fromBranch.chain_id !== toBranch.chain_id) {
                    throw new Error('Validation Error: Internal transfers must be strictly within the same chain');
                }

                // Check authorization
                if (context.role === 'agency_branch') {
                    if (context.pharmacyId !== fromPharmacyId && context.pharmacyId !== toPharmacyId) {
                        throw new Error('403 Forbidden: Branch user can only initiate transfers involving their own branch');
                    }
                }

                const chainPolicy = policyApplied || (_chains[fromBranch.chain_id]?.default_policy || 'centralized');
                const transferId = genId('TRF');
                const transferCode = `PL-TRF-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

                const transferItems = (items || []).map((it, idx) => {
                    const inv = _inventory[it.inventoryItemId];
                    if (!inv || inv.pharmacy_id !== fromPharmacyId) {
                        throw new Error(`Validation Error: Item ${it.inventoryItemId} does not belong to sender branch ${fromPharmacyId}`);
                    }
                    if (it.quantity <= 0) {
                        throw new Error(`Validation Error: Quantity requested must be positive`);
                    }
                    return {
                        id: `ITEM-${transferId}-${idx + 1}`,
                        transfer_id: transferId,
                        inventory_item_id: inv.id,
                        drug_name_snapshot: inv.brand_name,
                        batch_snapshot: inv.batch_number,
                        expiry_snapshot: inv.expiry_date,
                        unit_snapshot: inv.unit || 'باكت',
                        quantity_requested: it.quantity,
                        quantity_sent: 0,
                        quantity_accepted: 0,
                        quantity_rejected: 0,
                        quantity_missing: 0
                    };
                });

                // Determine initial status
                let initialStatus = 'pending_counterpart_approval';
                let senderApprovedBy = null;
                let senderApprovedAt = null;

                // If sender initiated directly, they can approve provisionally
                if (context.pharmacyId === fromPharmacyId) {
                    initialStatus = 'pending_counterpart_approval';
                }

                const transfer = {
                    id: transferId,
                    transfer_code: transferCode,
                    chain_id: fromBranch.chain_id,
                    from_pharmacy_id: fromPharmacyId,
                    to_pharmacy_id: toPharmacyId,
                    policy_applied: chainPolicy,
                    status: initialStatus,
                    items: transferItems,
                    courier_name: null,
                    courier_phone: null,
                    transport_cost: 0.00,
                    platform_fee: 0.00, // Strictly Zero
                    reason: reason || 'مناقلة داخلية بين فروع السلسلة',
                    created_by: context.userId,
                    created_at: new Date().toISOString(),
                    sender_approved_by: senderApprovedBy,
                    sender_approved_at: senderApprovedAt,
                    management_approved_by: null,
                    management_approved_at: null,
                    dispatched_by: null,
                    dispatched_at: null,
                    received_by: null,
                    received_at: null,
                    history: [
                        { action: 'CREATED', actor: context.userId, timestamp: new Date().toISOString(), note: 'تم إنشاء مسار المناقلة' }
                    ]
                };

                _transfers.push(transfer);

                const result = { success: true, transfer: clone(transfer) };
                if (idempotencyKey) _idempotencyStore[idempotencyKey] = result;
                return result;
            });
        },

        // RPC 2: Sender Branch Approves Allocation & Holds Active Reservation
        approveSenderAllocation(context, payload) {
            return runWithLock(() => {
                const { transferId, idempotencyKey } = payload;
                if (idempotencyKey && _idempotencyStore[idempotencyKey]) {
                    return clone(_idempotencyStore[idempotencyKey]);
                }

                const transfer = _transfers.find(t => t.id === transferId);
                if (!transfer) throw new Error(`Transfer ${transferId} not found`);

                // Strict authorization: ONLY sender branch
                assertSecurity(context, null, transfer.from_pharmacy_id);

                if (transfer.status === 'approved_and_reserved' || transfer.status === 'in_transit' || transfer.status === 'completed') {
                    return { success: true, message: 'Transfer is already approved/reserved', status: transfer.status };
                }

                // Check availability and reserve each line item atomically
                for (const item of transfer.items) {
                    const inv = _inventory[item.inventory_item_id];
                    if (!inv) throw new Error(`Item ${item.inventory_item_id} not found in inventory`);

                    const available = getAvailableQuantity(inv.id);
                    if (available < item.quantity_requested) {
                        const err = new Error(`عجز في المخزون: الرصيد المتاح للصنف (${item.drug_name_snapshot} - تشغيلة ${item.batch_snapshot}) هو ${available}، بينما الكمية المطلوبة هي ${item.quantity_requested}`);
                        err.code = 'INSUFFICIENT_AVAILABLE_STOCK';
                        err.available = available;
                        err.requested = item.quantity_requested;
                        throw err;
                    }
                }

                // All items available: create active reservations
                for (const item of transfer.items) {
                    const resId = genId('RES');
                    _reservations.push({
                        id: resId,
                        transfer_id: transfer.id,
                        transfer_item_id: item.id,
                        inventory_item_id: item.inventory_item_id,
                        pharmacy_id: transfer.from_pharmacy_id,
                        reserved_quantity: item.quantity_requested,
                        status: 'active',
                        created_at: new Date().toISOString()
                    });

                    _movements.push({
                        id: genId('MOV'),
                        inventory_item_id: item.inventory_item_id,
                        pharmacy_id: transfer.from_pharmacy_id,
                        transfer_id: transfer.id,
                        movement_type: 'reservation_held',
                        delta_physical: 0,
                        delta_quarantine: 0,
                        balance_after_physical: _inventory[item.inventory_item_id].physical_quantity,
                        balance_after_quarantine: _inventory[item.inventory_item_id].quarantine_quantity || 0,
                        actor_id: context.userId,
                        notes: `حجز مخزني نشط للمناقلة ${transfer.transfer_code}`,
                        created_at: new Date().toISOString()
                    });
                }

                transfer.sender_approved_by = context.userId;
                transfer.sender_approved_at = new Date().toISOString();

                // Status transition based on chain policy
                if (transfer.policy_applied === 'centralized' && !transfer.management_approved_at) {
                    transfer.status = 'pending_management_approval';
                } else {
                    transfer.status = 'approved_and_reserved';
                }

                transfer.history.push({
                    action: 'SENDER_ALLOCATION_APPROVED',
                    actor: context.userId,
                    timestamp: new Date().toISOString(),
                    note: `وافق الفرع المرسل على تخصيص الكميات وحجزها. الحالة الحالية: ${transfer.status}`
                });

                const result = { success: true, transfer: clone(transfer) };
                if (idempotencyKey) _idempotencyStore[idempotencyKey] = result;
                return result;
            });
        },

        // RPC 3: Management Approves Transfer
        approveManagement(context, payload) {
            return runWithLock(() => {
                const { transferId, reason, idempotencyKey } = payload;
                if (idempotencyKey && _idempotencyStore[idempotencyKey]) {
                    return clone(_idempotencyStore[idempotencyKey]);
                }

                const transfer = _transfers.find(t => t.id === transferId);
                if (!transfer) throw new Error(`Transfer ${transferId} not found`);

                // Strict authorization: ONLY agency_master or admin for this chain
                if (context.role !== 'agency_master' && context.role !== 'admin') {
                    throw new Error('403 Forbidden: Only chain management (agency_master) can approve central transfer requests');
                }
                if (context.role === 'agency_master' && context.chainId !== transfer.chain_id) {
                    throw new Error('403 Forbidden: Cannot approve transfers of a different chain');
                }

                if (transfer.status === 'approved_and_reserved' || transfer.status === 'in_transit' || transfer.status === 'completed') {
                    return { success: true, message: 'Transfer is already approved', status: transfer.status };
                }

                transfer.management_approved_by = context.userId;
                transfer.management_approved_at = new Date().toISOString();

                // If sender has already approved and reserved, transition to approved_and_reserved
                if (transfer.sender_approved_at) {
                    transfer.status = 'approved_and_reserved';
                } else {
                    // Waiting for sender acknowledgement
                    transfer.status = 'pending_counterpart_approval';
                }

                transfer.history.push({
                    action: 'MANAGEMENT_APPROVED',
                    actor: context.userId,
                    timestamp: new Date().toISOString(),
                    note: `اعتمدت الإدارة العامة طلب المناقلة. ${reason ? `السبب: ${reason}` : ''}`
                });

                const result = { success: true, transfer: clone(transfer) };
                if (idempotencyKey) _idempotencyStore[idempotencyKey] = result;
                return result;
            });
        },

        // RPC 4: Dispatch Transfer (Records Confirming User & Timestamp, Deducts Physical Stock Once, Consumes Reservation)
        dispatchTransfer(context, payload) {
            return runWithLock(() => {
                const { transferId, notes, idempotencyKey, courierName, courierPhone, transportCost } = payload;
                if (idempotencyKey && _idempotencyStore[idempotencyKey]) {
                    return clone(_idempotencyStore[idempotencyKey]);
                }

                const transfer = _transfers.find(t => t.id === transferId);
                if (!transfer) throw new Error(`Transfer ${transferId} not found`);

                // Strict authorization: ONLY sender branch
                assertSecurity(context, null, transfer.from_pharmacy_id);

                if (transfer.status === 'in_transit') {
                    return { success: true, message: 'Already dispatched', transfer: clone(transfer) };
                }

                if (transfer.status !== 'approved_and_reserved' && transfer.status !== 'in_preparation') {
                    throw new Error(`Cannot dispatch transfer in status [${transfer.status}]. Must be approved_and_reserved.`);
                }

                // Check and execute physical deduction once
                for (const item of transfer.items) {
                    const inv = _inventory[item.inventory_item_id];
                    if (!inv) throw new Error(`Inventory item ${item.inventory_item_id} missing`);

                    if (inv.physical_quantity < item.quantity_requested) {
                        throw new Error(`Critical Deficit: Physical balance (${inv.physical_quantity}) is less than requested (${item.quantity_requested})`);
                    }

                    // 1. Deduct Physical Quantity Once
                    inv.physical_quantity -= item.quantity_requested;

                    // 2. Mark Reservation as CONSUMED (NOT deleted or cancelled!)
                    const reservation = _reservations.find(r => r.transfer_id === transfer.id && r.inventory_item_id === inv.id && r.status === 'active');
                    if (reservation) {
                        reservation.status = 'consumed';
                        reservation.consumed_at = new Date().toISOString();
                    }

                    // 3. Set quantity_sent
                    item.quantity_sent = item.quantity_requested;

                    // 4. Ledger Movement
                    _movements.push({
                        id: genId('MOV'),
                        inventory_item_id: inv.id,
                        pharmacy_id: transfer.from_pharmacy_id,
                        transfer_id: transfer.id,
                        movement_type: 'dispatch_deduction',
                        delta_physical: -item.quantity_requested,
                        delta_quarantine: 0,
                        balance_after_physical: inv.physical_quantity,
                        balance_after_quarantine: inv.quarantine_quantity || 0,
                        actor_id: context.userId,
                        notes: `صرف مخزني فعلي لتأكيد إرسال المناقلة ${transfer.transfer_code}${notes ? ` - ملاحظات: ${notes}` : ''}`,
                        created_at: new Date().toISOString()
                    });
                }

                transfer.status = 'in_transit'; // تم الإرسال — بانتظار الاستلام
                // Preserve historical fields if provided or keep existing, without requiring any transport data
                if (courierName !== undefined) transfer.courier_name = courierName;
                if (courierPhone !== undefined) transfer.courier_phone = courierPhone;
                if (transportCost !== undefined) transfer.transport_cost = parseFloat(transportCost) || 0.00;
                if (notes) transfer.dispatch_notes = notes;
                transfer.platform_fee = 0.00; // Zero platform commission
                transfer.dispatched_by = context.userId;
                transfer.dispatched_at = new Date().toISOString();

                transfer.history.push({
                    action: 'DISPATCHED',
                    actor: context.userId,
                    timestamp: new Date().toISOString(),
                    note: `تم تأكيد إرسال المناقلة من قبل الفرع المرسل (تم الإرسال — بانتظار الاستلام).${notes ? ` ملاحظات: ${notes}` : ''}`
                });

                const result = { success: true, transfer: clone(transfer) };
                if (idempotencyKey) _idempotencyStore[idempotencyKey] = result;
                return result;
            });
        },

        // RPC 5: Receive Transfer & Atomic Discrepancy Balancing
        receiveTransfer(context, payload) {
            return runWithLock(() => {
                const { transferId, receiptLines, idempotencyKey } = payload;
                if (idempotencyKey && _idempotencyStore[idempotencyKey]) {
                    return clone(_idempotencyStore[idempotencyKey]);
                }

                const transfer = _transfers.find(t => t.id === transferId);
                if (!transfer) throw new Error(`Transfer ${transferId} not found`);

                // Strict authorization: ONLY destination branch
                assertSecurity(context, null, transfer.to_pharmacy_id);

                if (transfer.status === 'completed' || transfer.status === 'needs_discrepancy_resolution') {
                    return { success: true, message: 'Already received', transfer: clone(transfer) };
                }

                if (transfer.status !== 'in_transit') {
                    throw new Error(`Transfer must be [in_transit] to receive. Current status: ${transfer.status}`);
                }

                let hasDiscrepancy = false;

                // Process receipt for each item
                for (const line of receiptLines) {
                    const item = transfer.items.find(it => it.id === line.itemId);
                    if (!item) throw new Error(`Item ${line.itemId} not in transfer line items`);

                    const accepted = parseInt(line.accepted || 0, 10);
                    const rejected = parseInt(line.rejected || 0, 10);
                    const missing = parseInt(line.missing || 0, 10);

                    // Mandatory Mathematical Equality: Sent == Accepted + Rejected + Missing
                    if (item.quantity_sent !== (accepted + rejected + missing)) {
                        throw new Error(`Mathematical Balance Error for (${item.drug_name_snapshot}): Sent (${item.quantity_sent}) != Accepted (${accepted}) + Rejected (${rejected}) + Missing (${missing})`);
                    }

                    item.quantity_accepted = accepted;
                    item.quantity_rejected = rejected;
                    item.quantity_missing = missing;

                    if (rejected > 0 || missing > 0) {
                        hasDiscrepancy = true;
                    }

                    // Find or create batch record at destination pharmacy
                    let destInv = Object.values(_inventory).find(inv => 
                        inv.pharmacy_id === transfer.to_pharmacy_id &&
                        inv.brand_name === item.drug_name_snapshot &&
                        inv.batch_number === item.batch_snapshot
                    );

                    if (!destInv) {
                        const newInvId = genId('INV');
                        destInv = {
                            id: newInvId,
                            pharmacy_id: transfer.to_pharmacy_id,
                            brand_name: item.drug_name_snapshot,
                            batch_number: item.batch_snapshot,
                            expiry_date: item.expiry_snapshot,
                            unit: item.unit_snapshot,
                            physical_quantity: accepted,
                            quarantine_quantity: rejected,
                            is_cold_chain: false,
                            status: 'draft'
                        };
                        _inventory[newInvId] = destInv;
                    } else {
                        destInv.physical_quantity += accepted;
                        destInv.quarantine_quantity = (destInv.quarantine_quantity || 0) + rejected;
                    }

                    // 1. Ledger Movement for Accepted Quantity
                    if (accepted > 0) {
                        _movements.push({
                            id: genId('MOV'),
                            inventory_item_id: destInv.id,
                            pharmacy_id: transfer.to_pharmacy_id,
                            transfer_id: transfer.id,
                            movement_type: 'receipt_accepted_addition',
                            delta_physical: accepted,
                            delta_quarantine: 0,
                            balance_after_physical: destInv.physical_quantity,
                            balance_after_quarantine: destInv.quarantine_quantity,
                            actor_id: context.userId,
                            notes: `إضافة مخزون مقبول للمناقلة ${transfer.transfer_code}`,
                            created_at: new Date().toISOString()
                        });
                    }

                    // 2. Discrepancy & Quarantine Entry for Rejected/Damaged
                    if (rejected > 0) {
                        const discId = genId('DISC');
                        _discrepancies.push({
                            id: discId,
                            transfer_id: transfer.id,
                            transfer_item_id: item.id,
                            discrepancy_type: 'rejected_damaged',
                            quantity: rejected,
                            reason: line.rejectReason || 'بضاعة تالفة أو مرفوضة عند الفحص الفيزيائي',
                            notes: line.notes || '',
                            resolution_status: 'pending_investigation',
                            financial_claim_status: 'none', // لا مطالبات مالية خاصة بالنقل عبر المنصة
                            created_at: new Date().toISOString()
                        });

                        _movements.push({
                            id: genId('MOV'),
                            inventory_item_id: destInv.id,
                            pharmacy_id: transfer.to_pharmacy_id,
                            transfer_id: transfer.id,
                            movement_type: 'receipt_quarantine_addition',
                            delta_physical: 0,
                            delta_quarantine: rejected,
                            balance_after_physical: destInv.physical_quantity,
                            balance_after_quarantine: destInv.quarantine_quantity,
                            actor_id: context.userId,
                            notes: `حجر صحي/عهدة لبضاعة مرفوضة (${rejected} عبوة) للمناقلة ${transfer.transfer_code}`,
                            created_at: new Date().toISOString()
                        });
                    }

                    // 3. Discrepancy Entry for Missing Quantity (Stock Variance under Investigation, No Automatic Carrier Liability)
                    if (missing > 0) {
                        const discId = genId('DISC');
                        _discrepancies.push({
                            id: discId,
                            transfer_id: transfer.id,
                            transfer_item_id: item.id,
                            discrepancy_type: 'missing_investigation',
                            quantity: missing,
                            reason: line.missingReason || 'عجز أو نقص في الكمية المستلمة',
                            notes: line.notes || '',
                            resolution_status: 'pending_investigation',
                            financial_claim_status: 'none', // المنصة تسجل الاختلاف المخزني ومعالجته المعتمدة فقط دون تحميل أطراف النقل مطالبات مالية تلقائياً
                            created_at: new Date().toISOString()
                        });
                    }
                }

                transfer.received_by = context.userId;
                transfer.received_at = new Date().toISOString();
                transfer.status = hasDiscrepancy ? 'needs_discrepancy_resolution' : 'completed';

                transfer.history.push({
                    action: 'RECEIVED',
                    actor: context.userId,
                    timestamp: new Date().toISOString(),
                    note: hasDiscrepancy 
                        ? 'تم استلام الشحنة وتسجيل فروقات (نقص/تلف) لضبط الأرصدة المخزنية' 
                        : 'تم استلام الشحنة مطابقة 100% وإغلاق المناقلة'
                });

                const result = { success: true, transfer: clone(transfer), hasDiscrepancy };
                if (idempotencyKey) _idempotencyStore[idempotencyKey] = result;
                return result;
            });
        },

        // RPC 6: Cancel or Reject Transfer (Frees Active Reservations)
        cancelOrRejectTransfer(context, payload) {
            return runWithLock(() => {
                const { transferId, action, reason, idempotencyKey } = payload; // action: 'REJECT' | 'CANCEL'
                if (idempotencyKey && _idempotencyStore[idempotencyKey]) {
                    return clone(_idempotencyStore[idempotencyKey]);
                }

                const transfer = _transfers.find(t => t.id === transferId);
                if (!transfer) throw new Error(`Transfer ${transferId} not found`);

                if (transfer.status === 'in_transit' || transfer.status === 'completed') {
                    throw new Error(`Cannot cancel or reject transfer after dispatch. Current status: [${transfer.status}]`);
                }

                // Check authorization
                if (action === 'CANCEL') {
                    // Only creator, sender branch or admin/management can cancel
                    if (context.role === 'agency_branch' && context.pharmacyId !== transfer.from_pharmacy_id && context.userId !== transfer.created_by) {
                        throw new Error('403 Forbidden: Cannot cancel transfer you did not create or send');
                    }
                } else if (action === 'REJECT') {
                    if (context.role === 'agency_branch' && context.pharmacyId !== transfer.from_pharmacy_id && context.pharmacyId !== transfer.to_pharmacy_id) {
                        throw new Error('403 Forbidden: Only participating branches can reject');
                    }
                }

                // Free active reservations (one-time release)
                const activeRes = _reservations.filter(r => r.transfer_id === transfer.id && r.status === 'active');
                for (const res of activeRes) {
                    res.status = 'released';
                    res.released_at = new Date().toISOString();

                    _movements.push({
                        id: genId('MOV'),
                        inventory_item_id: res.inventory_item_id,
                        pharmacy_id: res.pharmacy_id,
                        transfer_id: transfer.id,
                        movement_type: 'reservation_released',
                        delta_physical: 0,
                        delta_quarantine: 0,
                        balance_after_physical: _inventory[res.inventory_item_id].physical_quantity,
                        balance_after_quarantine: _inventory[res.inventory_item_id].quarantine_quantity || 0,
                        actor_id: context.userId,
                        notes: `فك حجز المخزون لإلغاء/رفض المناقلة ${transfer.transfer_code}`,
                        created_at: new Date().toISOString()
                    });
                }

                transfer.status = (action === 'CANCEL') ? 'cancelled' : 'rejected';
                transfer.history.push({
                    action: transfer.status.toUpperCase(),
                    actor: context.userId,
                    timestamp: new Date().toISOString(),
                    note: `تم ${action === 'CANCEL' ? 'إلغاء' : 'رفض'} المناقلة. السبب: ${reason || 'غير محدد'}. تم فك الحجوزات بنجاح.`
                });

                const result = { success: true, transfer: clone(transfer) };
                if (idempotencyKey) _idempotencyStore[idempotencyKey] = result;
                return result;
            });
        },

        // RPC 7: Excel Accounting Import Diffs & Suspension Logic
        previewAndReconcileExcelImport(context, payload) {
            return runWithLock(() => {
                const { pharmacyId, excelRows } = payload;
                assertSecurity(context, null, pharmacyId);

                const previewReport = {
                    totalRows: excelRows.length,
                    readyToImport: [],
                    suspendedForReview: [],
                    summary: { readyCount: 0, suspendedCount: 0 }
                };

                for (const row of excelRows) {
                    // Match existing item in this pharmacy
                    const existingItem = Object.values(_inventory).find(inv =>
                        inv.pharmacy_id === pharmacyId &&
                        inv.brand_name === row.brand_name &&
                        inv.batch_number === row.batch_number
                    );

                    if (!existingItem) {
                        // Brand new item: safe to import
                        previewReport.readyToImport.push({
                            type: 'NEW_ITEM',
                            item: row,
                            reason: 'صنف جديد يؤسس رصيده لأول مرة'
                        });
                    } else {
                        // Check if item has ACTIVE reservations or OPEN transfers
                        const hasActiveReservations = _reservations.some(r =>
                            r.inventory_item_id === existingItem.id && r.status === 'active'
                        );

                        const hasOpenTransfers = _transfers.some(t =>
                            (t.from_pharmacy_id === pharmacyId || t.to_pharmacy_id === pharmacyId) &&
                            (t.status === 'pending_counterpart_approval' || t.status === 'pending_management_approval' ||
                             t.status === 'approved_and_reserved' || t.status === 'in_transit' || t.status === 'needs_discrepancy_resolution') &&
                            t.items.some(it => it.inventory_item_id === existingItem.id)
                        );

                        if (hasActiveReservations || hasOpenTransfers) {
                            // SUSPEND UPDATE FOR REVIEW
                            previewReport.suspendedForReview.push({
                                type: 'SUSPENDED_CONFLICT',
                                item: row,
                                existingPhysical: existingItem.physical_quantity,
                                importedPhysical: row.quantity,
                                variance: row.quantity - existingItem.physical_quantity,
                                hasActiveReservations,
                                hasOpenTransfers,
                                reason: 'يوجد حجز نشط أو مناقلة مفتوحة؛ عُلّق التحديث لحين إتمام العملية تفادياً لكسر الحجوزات'
                            });
                        } else {
                            // Safe to preview variance
                            previewReport.readyToImport.push({
                                type: 'UPDATE_VARIANCE',
                                item: row,
                                existingPhysical: existingItem.physical_quantity,
                                importedPhysical: row.quantity,
                                variance: row.quantity - existingItem.physical_quantity,
                                reason: 'صنف مستقر بدون حجوزات نشطة'
                            });
                        }
                    }
                }

                previewReport.summary.readyCount = previewReport.readyToImport.length;
                previewReport.summary.suspendedCount = previewReport.suspendedForReview.length;

                return previewReport;
            });
        }
    };
}));
