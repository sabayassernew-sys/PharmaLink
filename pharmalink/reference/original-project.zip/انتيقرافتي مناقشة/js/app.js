/**
 * ترياق B2B - كود المنطق التفاعلي الشامل (Comprehensive App Logic & State Machine)
 * يدعم: حماية خصوصية B2B للزوار، تسجيل الدخول، إنشاء الحساب، الصلاحيات والأدوار، والأدمن، وإكسل يمن سوفت
 */

// 1. حالة المستخدم الحالية (افتراضياً: فرع وكالة - صيدلية الشفاء فرع حدة لفتح جدول المخزون والتكافل مباشرة)
const initialRole = (typeof localStorage !== "undefined" && localStorage.getItem("tiryaq_user_role")) || "agency_branch";
let CURRENT_USER = {
    isLoggedIn: initialRole !== "guest",
    profile: (initialRole !== "guest" && typeof MOCK_USERS !== "undefined") ? (MOCK_USERS[initialRole] || MOCK_USERS.agency_branch) : null,
    role: initialRole // guest | independent | agency_branch | agency_master | pending_user | admin
};

// متغير مؤقت للصفقة الجارية
let selectedListingForDeal = null;

// التهيئة عند تشغيل التطبيق
document.addEventListener("DOMContentLoaded", () => {
    initApp();
});

function initApp() {
    applyUserRole(CURRENT_USER.role);
}

/**
 * 2. تطبيق وتحديث واجهات النظام وفقاً لصلاحيات الدور الحالي
 */
function applyUserRole(roleKey) {
    if (typeof localStorage !== "undefined") {
        try { localStorage.setItem("tiryaq_user_role", roleKey); } catch (e) {}
    }

    if (roleKey === "guest") {
        CURRENT_USER = {
            isLoggedIn: false,
            profile: null,
            role: "guest"
        };
    } else {
        CURRENT_USER = {
            isLoggedIn: true,
            profile: MOCK_USERS[roleKey] || MOCK_USERS.agency_branch,
            role: roleKey
        };
    }

    updateNavbarAndUI();
    renderMarketplace();
    renderMyListingsTable();
    renderEscrowDeals();
    renderRadarGrid();
    renderAdminPanel();
    renderAgencyBranches();
    renderAgencyTransfers();
    renderAgencyExchangeBoard();

    // توجيه المستخدم للشاشة المناسبة
    if (CURRENT_USER.role === "guest") {
        switchTab("landing");
    } else if (CURRENT_USER.role === "pending_user") {
        switchTab("pending");
    } else if (CURRENT_USER.role === "admin") {
        switchTab("admin");
    } else if (CURRENT_USER.role === "agency_master") {
        switchTab("branches");
    } else if (CURRENT_USER.role === "agency_branch") {
        switchTab("dashboard");
    } else {
        switchTab("dashboard");
    }
}

/**
 * 3. تحديث أزرار التنقل ومعلومات الهيدر حسب الدور وحماية الزائر
 */
function updateNavbarAndUI() {
    const roleSelect = document.getElementById("userRoleSelect");
    if (roleSelect) roleSelect.value = CURRENT_USER.role;

    const userProfileHeader = document.getElementById("userProfileHeader");
    const guestAuthButtons = document.getElementById("guestAuthButtons");
    const supplierAlertStrip = document.getElementById("supplierAlertStrip");

    const mainNav = document.getElementById("mainNavigation");
    const guestNav = document.getElementById("guestNavLinks");

    // تابات خاصة بالصلاحيات
    const tabLanding = document.getElementById("tab-btn-landing");
    const tabMarketplace = document.getElementById("tab-btn-marketplace");
    const tabBranches = document.getElementById("tab-btn-branches");
    const tabAdmin = document.getElementById("tab-btn-admin");
    const tabDashboard = document.getElementById("tab-btn-dashboard");
    const tabEscrow = document.getElementById("tab-btn-escrow");
    const tabRadar = document.getElementById("tab-btn-radar");

    if (CURRENT_USER.role === "guest") {
        // حالة الزائر العام غير المسجل (فقط واجهة الهبوط التعريفية الجذابة - بدون بورصة إطلاقاً)
        if (userProfileHeader) userProfileHeader.style.display = "none";
        if (guestAuthButtons) guestAuthButtons.style.display = "flex";
        if (supplierAlertStrip) supplierAlertStrip.style.display = "none";

        // إخفاء شريط أدوات النظام وإظهار روابط صفحة الهبوط
        if (mainNav) mainNav.style.display = "none";
        if (guestNav) guestNav.style.display = "flex";

        if (tabMarketplace) tabMarketplace.style.display = "none";
        if (tabBranches) tabBranches.style.display = "none";
        if (tabAdmin) tabAdmin.style.display = "none";
        if (tabDashboard) tabDashboard.style.display = "none";
        if (tabEscrow) tabEscrow.style.display = "none";
        if (tabRadar) tabRadar.style.display = "none";
    } else {
        // حالة المستخدم المسجل (صيدلية / وكالة / أدمن)
        if (userProfileHeader) userProfileHeader.style.display = "flex";
        if (guestAuthButtons) guestAuthButtons.style.display = "none";

        // إظهار شريط التنقل الداخلي وإخفاء روابط صفحة الهبوط العامة
        if (mainNav) mainNav.style.display = "flex";
        if (guestNav) guestNav.style.display = "none";

        const p = CURRENT_USER.profile;
        document.getElementById("current-pharmacy-name").innerText = p.name;
        document.getElementById("current-pharmacy-meta").innerText = `${p.city} - ${p.district} | ${p.pharmacist}`;

        const badge = document.getElementById("headerVerificationBadge");
        if (badge) {
            if (CURRENT_USER.role === "admin") {
                badge.className = "verification-badge admin-badge";
                badge.innerHTML = '<i class="fa-solid fa-user-shield"></i> مدير النظام';
            } else if (p.verification_status === "pending") {
                badge.className = "verification-badge pending-badge";
                badge.innerHTML = '<i class="fa-solid fa-hourglass-half"></i> قيد المراجعة';
            } else {
                badge.className = "verification-badge";
                badge.innerHTML = '<i class="fa-solid fa-circle-check"></i> موثقة';
            }
        }

        // الرصيد في الهيدر
        const walletBadge = document.getElementById("headerWalletBadge");
        if (CURRENT_USER.role === "admin" || CURRENT_USER.role === "pending_user") {
            if (walletBadge) walletBadge.style.display = "none";
        } else {
            if (walletBadge) {
                walletBadge.style.display = "flex";
                document.getElementById("quick-wallet-balance").innerText = (p.available_balance || 0).toLocaleString();
            }
        }

        // إظهار وإعادة تفعيل تاب البورصة
        if (tabMarketplace) {
            tabMarketplace.style.display = "flex";
            tabMarketplace.innerHTML = '<i class="fa-solid fa-boxes-stacked"></i> البورصة الدوائية';
        }

        // إظهار أو إخفاء التابات حسب الدور
        if (tabBranches) {
            const isAgencyMaster = CURRENT_USER.role === "agency_master";
            const isAgencyBranch = CURRENT_USER.role === "agency_branch";

            if (isAgencyMaster) {
                tabBranches.style.display = "flex";
                const pendingCount = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined")
                    ? MOCK_INTERNAL_TRANSFERS.filter(t => t.status === "PENDING_APPROVAL").length
                    : 0;
                tabBranches.innerHTML = `<i class="fa-solid fa-sitemap"></i> إدارة الأفرع والمناقلات ${pendingCount > 0 ? `<span class="nav-badge" id="agency-transfers-nav-badge">${pendingCount}</span>` : ""}`;
            } else if (isAgencyBranch) {
                tabBranches.style.display = "flex";
                const myActiveTransfers = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined")
                    ? MOCK_INTERNAL_TRANSFERS.filter(t => (t.to_branch_id === CURRENT_USER.profile?.id || t.from_branch_id === CURRENT_USER.profile?.id) && (t.status === "PENDING_APPROVAL" || t.status === "IN_TRANSIT")).length
                    : 0;
                tabBranches.innerHTML = `<i class="fa-solid fa-shuffle"></i> مناقلات الوكالة ${myActiveTransfers > 0 ? `<span class="nav-badge" id="agency-transfers-nav-badge">${myActiveTransfers}</span>` : ""}`;
            } else {
                tabBranches.style.display = "none";
            }
        }

        if (tabAdmin) tabAdmin.style.display = CURRENT_USER.role === "admin" ? "flex" : "none";
        if (tabDashboard) tabDashboard.style.display = (CURRENT_USER.role === "admin" || CURRENT_USER.role === "pending_user") ? "none" : "flex";
        if (tabEscrow) tabEscrow.style.display = (CURRENT_USER.role === "admin" || CURRENT_USER.role === "pending_user") ? "none" : "flex";
        if (tabRadar) tabRadar.style.display = (CURRENT_USER.role === "admin" || CURRENT_USER.role === "pending_user") ? "none" : "flex";

        // ويدجت إشعار الشحنة القادمة للفرع
        const incomingAlert = document.getElementById("branchIncomingTransfersAlert");
        if (incomingAlert) {
            if (CURRENT_USER.role === "agency_branch") {
                const incomingTransfer = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined")
                    ? MOCK_INTERNAL_TRANSFERS.find(t => t.to_branch_id === CURRENT_USER.profile?.id && t.status === "IN_TRANSIT")
                    : null;
                if (incomingTransfer) {
                    incomingAlert.style.display = "flex";
                    const descEl = document.getElementById("branchIncomingTransfersDesc");
                    if (descEl) {
                        descEl.innerHTML = `يوجد <strong>${incomingTransfer.quantity} باكت</strong> من <strong>${incomingTransfer.drug_name}</strong> قادمة من (${incomingTransfer.from_branch_name}) مع المندوب ${incomingTransfer.driver_name} (هاتف: ${incomingTransfer.driver_phone}) بانتظار استلامك ومطابقة رقم التشغيلة.`;
                    }
                } else {
                    incomingAlert.style.display = "none";
                }
            } else {
                incomingAlert.style.display = "none";
            }
        }

        // عناوين شاشة فروع الوكالة
        const agencyViewTitle = document.getElementById("agencyViewTitle");
        const agencyViewDesc = document.getElementById("agencyViewDesc");
        const btnAddBranchHeader = document.getElementById("btnAddBranchHeader");
        if (agencyViewTitle && agencyViewDesc) {
            if (CURRENT_USER.role === "agency_branch") {
                agencyViewTitle.innerHTML = `<i class="fa-solid fa-shuffle"></i> مناقلات الوكالة المركزية (${CURRENT_USER.profile?.name || "فرع حدة"})`;
                agencyViewDesc.innerText = "متابعة الشحنات الواردة والصادرة لفرعك من وإلى الفروع الشقيقة، وتأكيد الاستلام وفحص الباتشات تحت إشراف الإدارة العامة.";
                if (btnAddBranchHeader) btnAddBranchHeader.style.display = "none";
            } else {
                agencyViewTitle.innerHTML = `<i class="fa-solid fa-sitemap"></i> إدارة أفرع الوكالة والمناقلات المخزنية`;
                agencyViewDesc.innerText = "منظومة الإشراف المركزي على سلسلة صيدليات الشفاء؛ تتبع مخزون الفروع، وإدارة ومراقبة المناقلات الداخلية المجانية بنظام التتبع المباشر وسندات أونكس برو ERP.";
                if (btnAddBranchHeader) btnAddBranchHeader.style.display = "inline-flex";
            }
        }

        // أزرار إضافة الأدوية واستيراد إكسل وإدارة التكافل في لوحة التحكم
        const dashActions = document.getElementById("dashboardHeaderActions");
        if (dashActions) {
            if (CURRENT_USER.role === "admin" || CURRENT_USER.role === "pending_user") {
                dashActions.style.display = "none";
            } else if (CURRENT_USER.role === "agency_branch") {
                dashActions.style.display = "flex";
                dashActions.innerHTML = `
                    <button class="btn btn-secondary" onclick="openCreateExchangePostModal('SHORTAGE')" title="طلب دواء ناقص غير مسجل في قائمة مخزون الفرع">
                        <i class="fa-solid fa-magnifying-glass-plus"></i> طلب دواء ناقص غير مسجل
                    </button>
                    <button class="btn btn-outline" onclick="triggerFileInput()" title="استيراد كشف جرد الصلاحيات من نظام أونكس برو ERP">
                        <i class="fa-solid fa-file-excel"></i> استيراد كشف أونكس برو
                    </button>
                `;
            } else {
                dashActions.style.display = "flex";
                dashActions.innerHTML = `
                    <button class="btn btn-primary" onclick="openAddModal()">
                        <i class="fa-solid fa-plus"></i> عرض دواء للبيع
                    </button>
                    <button class="btn btn-secondary" onclick="triggerFileInput()">
                        <i class="fa-solid fa-file-excel"></i> استيراد كشف يمن سوفت
                    </button>
                `;
            }
        }

        // شريط تنبيه الموردين
        if (supplierAlertStrip) {
            supplierAlertStrip.style.display = (CURRENT_USER.role === "independent" || CURRENT_USER.role === "agency_branch") ? "block" : "none";
        }

        // أرقام المحفظة في شاشة Escrow
        const availEl = document.getElementById("escrow-available-balance");
        const lockEl = document.getElementById("escrow-locked-balance");
        if (availEl) availEl.innerHTML = `${(p.available_balance || 0).toLocaleString()} <small>ر.ي</small>`;
        if (lockEl) lockEl.innerHTML = `${(p.locked_balance || 0).toLocaleString()} <small>ر.ي</small>`;
    }
}

/**
 * 4. التبديل السريع للدور للتجربة
 */
function switchRole(roleKey) {
    applyUserRole(roleKey);
    const names = {
        guest: "الزائر العام (واجهة الهبوط التعريفية الجاذبة وحجب البورصة)",
        independent: "صيدلية مستقلة (د. محمد - صيدلية الأمل)",
        agency_branch: "فرع وكالة (فرع حدة - وكالة الشفاء)",
        agency_master: "إدارة وكالة (مقر مجموعة صيدليات الشفاء)",
        pending_user: "صيدلية جديدة قيد التحقق (د. فؤاد الحمادي)",
        admin: "مدير المنصة (Super Admin)"
    };
    showToast(`تم التحويل إلى دور: ${names[roleKey]}`, "info");
}

/**
 * 5. التنقل بين التابات والشاشات (Tab Switcher)
 */
function switchTab(tabId) {
    // إذا كان زائراً عاماً وحاول الوصول لشاشة داخلية: نمنعه ونوجهه لتسجيل الدخول
    if (CURRENT_USER.role === "guest" && tabId !== "landing") {
        openLoginModal();
        showToast("عذراً، البورصة وتفاصيل الأدوية مخصصة حصرياً للصيدليات المرخصة. يرجى تسجيل الدخول أو إنشاء حساب صيدلية للاطلاع على البورصة.", "warning");
        return;
    }

    document.querySelectorAll(".nav-tab").forEach(btn => btn.classList.remove("active"));
    document.querySelectorAll(".app-view").forEach(view => view.classList.remove("active-view"));

    const activeBtn = document.getElementById(`tab-btn-${tabId}`);
    const activeView = document.getElementById(`view-${tabId}`);

    if (activeBtn) activeBtn.classList.add("active");
    if (activeView) activeView.classList.add("active-view");

    if (tabId === "branches") {
        renderAgencyExchangeBoard();
        renderAgencyTransfers();
        renderAgencyBranches();
    } else if (tabId === "dashboard") {
        renderMyListingsTable();
    } else if (tabId === "marketplace") {
        renderMarketplace();
    } else if (tabId === "escrow") {
        renderEscrowDeals();
    } else if (tabId === "radar") {
        renderRadarGrid();
    } else if (tabId === "admin") {
        renderAdminPanel();
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * 5.1 التمرير السلس لأقسام صفحة الهبوط التعريفية (Landing Sections Scroller)
 */
function scrollToLandingSection(sectionId) {
    if (CURRENT_USER.role !== "guest") {
        switchTab("landing");
    }
    setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 60);

    // تفعيل الرابط النشط
    document.querySelectorAll(".guest-nav-link").forEach(link => {
        link.classList.remove("active");
        if (link.getAttribute("onclick") && link.getAttribute("onclick").includes(sectionId)) {
            link.classList.add("active");
        }
    });
}

/**
 * 5.2 النقر على الشعار: الزائر ينتقل لقمة صفحة الهبوط، والمستخدم المسجل ينتقل لبيئة عمله
 */
function handleLogoClick() {
    if (CURRENT_USER.role === "guest") {
        switchTab("landing");
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (CURRENT_USER.role === "admin") {
        switchTab("admin");
    } else if (CURRENT_USER.role === "agency_master") {
        switchTab("branches");
    } else {
        switchTab("marketplace");
    }
}

/**
 * 5.3 استيراد إكسل يمن سوفت: التوجيه للوحة التحكم والمخزون وفتح مستعرض الملفات
 */
function openExcelModal() {
    switchTab("dashboard");
    setTimeout(() => {
        triggerFileInput();
    }, 120);
}

/**
 * 6. توليد كروت البورصة الدوائية وتطبيق حاجز الخصوصية الصارم للزائر العام
 */
function renderMarketplace() {
    const guestLockedBox = document.getElementById("guestLockedMarketplaceContainer");
    const authMarketplaceBox = document.getElementById("authenticatedMarketplaceContainer");
    const subtitleEl = document.getElementById("marketplaceSubtitle");

    // إذا كان المستخدم زائراً عاماً: اخفِ البيانات الحقيقية وأظهر حاجز الخصوصية
    if (CURRENT_USER.role === "guest") {
        if (guestLockedBox) guestLockedBox.style.display = "block";
        if (authMarketplaceBox) authMarketplaceBox.style.display = "none";
        if (subtitleEl) {
            subtitleEl.innerHTML = `
                <span style="color: #fbbf24;"><i class="fa-solid fa-lock"></i> هذه البورصة محمية ومغلقة:</span> 
                يقتصر الاطلاع على تفاصيل الأدوية والأسعار ونسب الخصومات على الصيدليات المرخصة الموثقة فقط.
            `;
        }
        return;
    }

    // إذا كان مسجلاً كصيدلية: اعرض السوق المفتوح بكامل بياناته
    if (guestLockedBox) guestLockedBox.style.display = "none";
    if (authMarketplaceBox) authMarketplaceBox.style.display = "block";
    if (subtitleEl) {
        subtitleEl.innerText = "تصفح الأدوية الراكدة وقريبة الانتهاء المعروضة من صيدليات موثوقة بهوامش خصم تصل إلى 60% مع ضمان مالي كامل.";
    }

    const grid = document.getElementById("marketplaceGrid");
    if (!grid) return;

    const searchText = (document.getElementById("marketplaceSearch")?.value || "").toLowerCase().trim();
    const locFilter = document.getElementById("filterLocation")?.value || "all";
    const expFilter = document.getElementById("filterExpiry")?.value || "all";
    const discFilter = document.getElementById("filterDiscount")?.value || "all";
    const scopeFilter = document.getElementById("filterAgencyScope")?.value || "all";

    const filteredListings = MOCK_LISTINGS.filter(item => {
        const seller = MOCK_PHARMACIES.find(p => p.id === item.pharmacy_id);
        if (!seller) return false;

        if (CURRENT_USER.profile && item.pharmacy_id === CURRENT_USER.profile.id) return false;
        if (item.is_published === false) return false;

        if (searchText) {
            const matchName = item.brand_name.toLowerCase().includes(searchText);
            const matchIng = item.active_ingredient.toLowerCase().includes(searchText);
            const matchBatch = item.batch_number.toLowerCase().includes(searchText);
            if (!matchName && !matchIng && !matchBatch) return false;
        }

        if (locFilter !== "all") {
            const sellerLoc = `${seller.city} - ${seller.district}`;
            if (sellerLoc !== locFilter) return false;
        }

        if (expFilter !== "all" && item.urgency !== expFilter) return false;
        if (discFilter !== "all" && item.discount_percent < parseInt(discFilter)) return false;

        if (scopeFilter === "internal_only") {
            if (!CURRENT_USER.profile?.agency_id || seller.agency_id !== CURRENT_USER.profile.agency_id) {
                return false;
            }
        }

        return true;
    });

    if (filteredListings.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 60px 20px; background: rgba(0,0,0,0.2); border-radius: 16px; border: 1px dashed var(--border-color);">
                <i class="fa-solid fa-box-open" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 15px;"></i>
                <h3 style="color: #fff; margin-bottom: 8px;">لا توجد أدوية مطابقة لمعايير البحث الحالية</h3>
                <p style="color: var(--text-secondary); font-size: 0.9rem;">جرب تغيير خيارات الفلترة أو ابحث بمصطلح آخر</p>
            </div>
        `;
        return;
    }

    grid.innerHTML = filteredListings.map(item => {
        const seller = MOCK_PHARMACIES.find(p => p.id === item.pharmacy_id);
        
        const isSameAgency = CURRENT_USER.profile?.agency_id && 
                             seller.agency_id && 
                             CURRENT_USER.profile.agency_id === seller.agency_id;

        let urgencyBadge = "";
        if (item.urgency === "critical") {
            urgencyBadge = `<span class="expiry-indicator critical"><i class="fa-solid fa-triangle-exclamation"></i> حرج: متبقي ${item.days_left} يوماً فقط</span>`;
        } else if (item.urgency === "moderate") {
            urgencyBadge = `<span class="expiry-indicator moderate"><i class="fa-solid fa-clock"></i> متوسط: متبقي ${item.days_left} يوماً</span>`;
        } else {
            urgencyBadge = `<span class="expiry-indicator safe"><i class="fa-solid fa-calendar-check"></i> مريح: متبقي ${item.days_left} يوماً</span>`;
        }

        let actionButton = "";
        if (CURRENT_USER.role === "pending_user") {
            actionButton = `
                <button class="btn btn-card-action btn-secondary" onclick="alert('حسابك قيد مراجعة الترخيص من قبل إدارة المنصة.')" style="opacity: 0.6;">
                    <i class="fa-solid fa-hourglass-half"></i> بانتظار الاعتماد
                </button>
            `;
        } else if (isSameAgency) {
            actionButton = `
                <button class="btn btn-card-action btn-internal-transfer" onclick="openInternalTransferModal('${item.id}')">
                    <i class="fa-solid fa-shuffle"></i> مناقلة فرعية مجانية
                </button>
            `;
        } else {
            actionButton = `
                <button class="btn btn-card-action btn-primary" onclick="openEscrowCheckoutModal('${item.id}')">
                    <i class="fa-solid fa-shield-halved"></i> شراء بالضمان (Escrow)
                </button>
            `;
        }

        return `
            <div class="drug-card">
                <div>
                    <div class="drug-card-top">
                        <div class="drug-names">
                            <div class="drug-brand-name">${item.brand_name}</div>
                            <div class="drug-active-ingredient">${item.active_ingredient}</div>
                        </div>
                        <div class="discount-badge">خصم ${item.discount_percent}%</div>
                    </div>

                    ${urgencyBadge}

                    <div class="drug-meta-grid">
                        <div class="meta-item">
                            <span class="meta-label">رقم التشغيلة (Batch):</span>
                            <span class="meta-val">${item.batch_number}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">الكمية المعروضة:</span>
                            <span class="meta-val">${item.quantity} باكت</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">تاريخ الانتهاء:</span>
                            <span class="meta-val">${item.expiry_date}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">الشركة المصنعة:</span>
                            <span class="meta-val">${item.manufacturer}</span>
                        </div>
                    </div>

                    <div class="seller-pharmacy-row">
                        <div class="seller-name">
                            <i class="fa-solid fa-clinic-medical"></i> ${seller.name}
                            ${isSameAgency ? '<span class="internal-branch-tag"><i class="fa-solid fa-link"></i> فرع وكالتنا</span>' : ''}
                        </div>
                        <div class="seller-location">
                            <i class="fa-solid fa-location-dot"></i> ${seller.city} - ${seller.district}
                        </div>
                    </div>
                </div>

                <div class="drug-card-footer">
                    <div class="price-box">
                        <span class="original-price">${item.original_price.toLocaleString()} ر.ي</span>
                        <span class="clearance-price">${item.clearance_price.toLocaleString()} <small>ر.ي/باكت</small></span>
                    </div>
                    ${actionButton}
                </div>
            </div>
        `;
    }).join("");
}

function filterMarketplace() {
    renderMarketplace();
}

/**
 * 7. لوحة تحكم مدير المنصة (Super Admin Management)
 */
function renderAdminPanel() {
    const licContainer = document.getElementById("adminPendingLicensesList");
    const countTag = document.getElementById("adminPendingCountTag");
    const statPending = document.getElementById("adminStatPendingLicenses");
    const navBadge = document.getElementById("admin-pending-badge");

    if (countTag) countTag.innerText = `${MOCK_PENDING_LICENSES.length} معلقة`;
    if (statPending) statPending.innerText = `${MOCK_PENDING_LICENSES.length} طلبات`;
    if (navBadge) navBadge.innerText = MOCK_PENDING_LICENSES.length;

    if (licContainer) {
        if (MOCK_PENDING_LICENSES.length === 0) {
            licContainer.innerHTML = `
                <div style="text-align: center; padding: 25px; color: var(--text-muted);">
                    <i class="fa-solid fa-circle-check" style="color: var(--primary-light); font-size: 1.8rem; margin-bottom: 8px;"></i>
                    <div>تمت مراجعة واعتماد جميع تراخيص الصيدليات! لا توجد طلبات معلقة حالياً.</div>
                </div>
            `;
        } else {
            licContainer.innerHTML = MOCK_PENDING_LICENSES.map(req => {
                return `
                    <div class="pending-license-item">
                        <div class="license-info">
                            <div class="license-pharmacy-name"><i class="fa-solid fa-clinic-medical"></i> ${req.pharmacy_name}</div>
                            <div class="license-meta">
                                المسؤول: <strong>${req.pharmacist}</strong> | الموقع: <strong>${req.city} - ${req.district}</strong> | رقم الترخيص: <code>${req.license_no}</code>
                            </div>
                            <div style="font-size: 0.8rem; color: var(--accent-blue); margin-top: 4px;">
                                <i class="fa-solid fa-file-pdf"></i> تم إرفاق وثيقة: ${req.doc_type} (${req.created_at})
                            </div>
                        </div>
                        <div class="license-actions">
                            <button class="btn-approve" onclick="approveLicense('${req.id}')">
                                <i class="fa-solid fa-check"></i> اعتماد وتوثيق الترخيص
                            </button>
                            <button class="btn-reject" onclick="rejectLicense('${req.id}')">
                                <i class="fa-solid fa-xmark"></i> رفض
                            </button>
                        </div>
                    </div>
                `;
            }).join("");
        }
    }

    const dispContainer = document.getElementById("adminDisputesList");
    if (dispContainer) {
        dispContainer.innerHTML = MOCK_DISPUTES.map(disp => {
            return `
                <div class="pending-license-item" style="border-right: 4px solid var(--danger-red);">
                    <div class="license-info">
                        <div class="license-pharmacy-name" style="color: #fda4af;">
                            <i class="fa-solid fa-triangle-exclamation"></i> نزاع في الصفقة: ${disp.deal_id} (${disp.drug_name})
                        </div>
                        <div class="license-meta">
                            المشتري الشاكي: <strong>${disp.buyer_name}</strong> | البائع: <strong>${disp.seller_name}</strong>
                        </div>
                        <div style="font-size: 0.84rem; color: #fecdd3; background: rgba(244, 63, 94, 0.1); padding: 8px; border-radius: 6px; margin-top: 8px;">
                            <strong>سبب الشكوى:</strong> ${disp.reason}
                        </div>
                    </div>
                    <div class="license-actions">
                        <button class="btn-approve" onclick="resolveDispute('${disp.id}', 'buyer')" style="background: var(--accent-blue);">
                            <i class="fa-solid fa-rotate-left"></i> إعادة المبلغ للمشتري (${disp.amount.toLocaleString()} ر.ي)
                        </button>
                        <button class="btn-reject" onclick="resolveDispute('${disp.id}', 'seller')" style="background: rgba(16, 185, 129, 0.2); color: #a7f3d0; border-color: var(--primary);">
                            <i class="fa-solid fa-check"></i> رفض الشكوى وتحرير المبلغ للبائع
                        </button>
                    </div>
                </div>
            `;
        }).join("");
    }
}

function approveLicense(reqId) {
    const idx = MOCK_PENDING_LICENSES.findIndex(l => l.id === reqId);
    if (idx !== -1) {
        const approvedReq = MOCK_PENDING_LICENSES[idx];
        MOCK_PENDING_LICENSES.splice(idx, 1);
        
        if (CURRENT_USER.profile && CURRENT_USER.profile.name.includes("النور")) {
            CURRENT_USER.profile.is_verified = true;
            CURRENT_USER.profile.verification_status = "approved";
        }

        renderAdminPanel();
        showToast(`✅ تم اعتماد وتوثيق ترخيص (${approvedReq.pharmacy_name}) بنجاح! تم منح الصيدلية شارة Verified.`, "success");
    }
}

function rejectLicense(reqId) {
    const reason = prompt("يرجى كتابة سبب رفض الترخيص (مثال: صورة الترخيص غير واضحة أو منتهية الصلاحية):");
    if (reason) {
        MOCK_PENDING_LICENSES = MOCK_PENDING_LICENSES.filter(l => l.id !== reqId);
        renderAdminPanel();
        showToast("تم رفض طلب الترخيص وإشعار الصيدلية بالسبب.", "warning");
    }
}

function resolveDispute(dispId, winner) {
    if (winner === "buyer") {
        showToast("⚖️ قرار التحكيم: تم إلغاء الصفقة وإعادة كامل المبلغ المحجوز في الضمان لحساب المشتري.", "success");
    } else {
        showToast("⚖️ قرار التحكيم: تم رفض الشكوى وتحرير المبلغ بالكامل للبائع.", "info");
    }
    MOCK_DISPUTES = MOCK_DISPUTES.filter(d => d.id !== dispId);
    renderAdminPanel();
}

/**
 * 8. شاشة إدارة أفرع الوكالة (Agency Master Management)
 */
function renderAgencyBranches() {
    const grid = document.getElementById("agencyBranchesGrid");
    if (!grid) return;

    const branches = [
        {
            id: "pharm_agency_01",
            name: "فرع حدة (الرئيسي)",
            manager: "د. أحمد الصنعاني",
            location: "صنعاء - شارع حدة",
            phone: "771987654",
            transfers_count: "8 مناقلات مكتملة"
        },
        {
            id: "pharm_agency_02",
            name: "فرع السبعين",
            manager: "د. عبدالكريم طاهر",
            location: "صنعاء - حي الأصبحي",
            phone: "772456789",
            transfers_count: "5 مناقلات مكتملة"
        },
        {
            id: "pharm_agency_03",
            name: "فرع شعوب - هائل",
            manager: "د. يحيى الشامي",
            location: "صنعاء - شارع هائل",
            phone: "773112233",
            transfers_count: "6 مناقلات مكتملة"
        }
    ];

    grid.innerHTML = branches.map(b => {
        const branchItems = MOCK_LISTINGS.filter(l => l.pharmacy_id === b.id);
        const liveCount = branchItems.filter(l => l.is_published).length;
        const draftCount = branchItems.filter(l => !l.is_published).length;

        return `
            <div class="branch-card">
                <div>
                    <div class="branch-header">
                        <div>
                            <div class="branch-name">${b.name}</div>
                            <div style="font-size: 0.85rem; color: var(--text-muted);"><i class="fa-solid fa-location-dot"></i> ${b.location}</div>
                        </div>
                        <span class="badge-status badge-active"><i class="fa-solid fa-link"></i> متصل بنظام أونكس</span>
                    </div>
                    <div class="branch-stats-row">
                        <div>الصيدلي المسؤول: <strong>${b.manager}</strong></div>
                        <div>الهاتف: <code>${b.phone}</code></div>
                    </div>
                    <div style="font-size: 0.86rem; color: var(--text-secondary); margin-bottom: 6px; background: rgba(0,0,0,0.25); padding: 8px 10px; border-radius: 6px;">
                        حالة المخزون: <strong style="color: #38bdf8;">${branchItems.length} أصناف مسجلة</strong> 
                        <span style="font-size: 0.78rem; color: var(--text-muted);">(${liveCount} بالبورصة | ${draftCount} محلي)</span>
                    </div>
                    <div style="font-size: 0.82rem; color: var(--primary-light);">
                        <i class="fa-solid fa-shuffle"></i> ${b.transfers_count} (توفير 0 ر.ي عمولة)
                    </div>
                </div>
                <div style="margin-top: 18px; border-top: 1px solid var(--border-color); padding-top: 12px; display: flex; gap: 8px; flex-wrap: wrap;">
                    <button class="btn btn-sm btn-primary" style="flex: 1; justify-content: center; font-size: 0.82rem;" onclick="viewBranchInventory('${b.id}')">
                        <i class="fa-solid fa-boxes-stacked"></i> استعراض مخزون الفرع
                    </button>
                    <button class="btn btn-sm btn-outline" style="flex: 1; justify-content: center; font-size: 0.82rem;" onclick="switchRoleToBranch('${b.id}')">
                        <i class="fa-solid fa-arrow-right-to-bracket"></i> دخول كمسؤول الفرع
                    </button>
                </div>
            </div>
        `;
    }).join("");
}

function switchRoleToBranch(branchId) {
    const branch = MOCK_PHARMACIES.find(p => p.id === branchId);
    if (!branch) return;
    CURRENT_USER.role = "agency_branch";
    CURRENT_USER.profile = { ...branch };
    const select = document.getElementById("userRoleSelect");
    if (select) select.value = "agency_branch";
    updateNavbarAndUI();
    renderMarketplace();
    renderMyListingsTable();
    switchTab("dashboard");
    showToast(`تم التبديل بنجاح: تتصفح الآن كصيدلي مسؤول عن (${branch.name}).`, "success");
}

function openAddBranchModal() {
    openModal("addBranchModal");
}

function saveNewBranch() {
    const name = document.getElementById("newBranchName").value;
    const mgr = document.getElementById("newBranchPharmacist").value;
    if (!name) {
        alert("يرجى كتابة اسم الفرع");
        return;
    }
    closeModal("addBranchModal");
    showToast(`تم إنشاء وتوثيق فرع (${name}) بنجاح وإرسال بيانات الدخول للصيدلي المسؤول (${mgr})!`, "success");
}

/**
 * 8.1 منظومة الرقابة والمناقلات الداخلية للأفرع (Enterprise Transfers Hub)
 */
let currentTransfersFilter = "ALL";
let currentTransfersSearch = "";
let currentExchangeFilter = "ALL";
let currentExchangeSearch = "";
let selectedPostForEscalation = null;

function switchAgencySubView(subViewKey) {
    document.querySelectorAll(".agency-subtab").forEach(tab => tab.classList.remove("active"));
    const branchesPanel = document.getElementById("agencySubView-branches");
    const transfersPanel = document.getElementById("agencySubView-transfers");
    const exchangePanel = document.getElementById("agencySubView-exchange");

    if (branchesPanel) branchesPanel.style.display = "none";
    if (transfersPanel) transfersPanel.style.display = "none";
    if (exchangePanel) exchangePanel.style.display = "none";

    if (subViewKey === "branches") {
        const btn = document.getElementById("subtab-branches");
        if (btn) btn.classList.add("active");
        if (branchesPanel) branchesPanel.style.display = "block";
        renderAgencyBranches();
    } else if (subViewKey === "transfers") {
        const btn = document.getElementById("subtab-transfers");
        if (btn) btn.classList.add("active");
        if (transfersPanel) transfersPanel.style.display = "block";
        renderAgencyTransfers();
    } else {
        // default: exchange
        const btn = document.getElementById("subtab-exchange");
        if (btn) btn.classList.add("active");
        if (exchangePanel) exchangePanel.style.display = "block";
        renderAgencyExchangeBoard();
    }
}

/**
 * ساحة التبادل والتكافل الداخلي بين الأفرع (فوائض ونواقص الأفرع مع مهلة 48 ساعة)
 */
function filterExchangePosts(type, btnElement) {
    currentExchangeFilter = type;
    document.querySelectorAll("#agencySubView-exchange .transfer-filter-pill").forEach(p => p.classList.remove("active"));
    if (btnElement) btnElement.classList.add("active");
    renderAgencyExchangeBoard();
}

function onExchangeSearchInput(query) {
    currentExchangeSearch = (query || "").trim().toLowerCase();
    renderAgencyExchangeBoard();
}

function renderAgencyExchangeBoard() {
    const grid = document.getElementById("agencyExchangeGrid");
    if (!grid) return;

    const list = (typeof MOCK_AGENCY_EXCHANGE_POSTS !== "undefined") ? MOCK_AGENCY_EXCHANGE_POSTS : [];

    // الإحصائيات والشارات
    const totalCount = list.length;
    const surplusCount = list.filter(p => p.type === "SURPLUS").length;
    const shortageCount = list.filter(p => p.type === "SHORTAGE").length;
    const activePostsCount = list.filter(p => p.status === "ACTIVE" || p.status === "READY_FOR_ESCALATION").length;

    const elTotal = document.getElementById("count-exchange-all");
    const elSurplus = document.getElementById("count-exchange-surplus");
    const elShortage = document.getElementById("count-exchange-shortage");
    const badgeSubtab = document.getElementById("subtabExchangeBadge");

    if (elTotal) elTotal.innerText = totalCount;
    if (elSurplus) elSurplus.innerText = surplusCount;
    if (elShortage) elShortage.innerText = shortageCount;
    if (badgeSubtab) {
        if (activePostsCount > 0) {
            badgeSubtab.style.display = "inline-flex";
            badgeSubtab.innerText = `${activePostsCount} نشط`;
        } else {
            badgeSubtab.style.display = "none";
        }
    }

    // فلترة القائمة
    let filtered = [...list];
    if (currentExchangeFilter !== "ALL") {
        filtered = filtered.filter(p => p.type === currentExchangeFilter);
    }
    if (currentExchangeSearch) {
        filtered = filtered.filter(p => {
            return (p.drug_name && p.drug_name.toLowerCase().includes(currentExchangeSearch)) ||
                   (p.branch_name && p.branch_name.toLowerCase().includes(currentExchangeSearch)) ||
                   (p.active_ingredient && p.active_ingredient.toLowerCase().includes(currentExchangeSearch)) ||
                   (p.notes && p.notes.toLowerCase().includes(currentExchangeSearch));
        });
    }

    if (filtered.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 45px 20px; background: rgba(0,0,0,0.2); border-radius: 12px; border: 1px dashed var(--border-color);">
                <i class="fa-solid fa-handshake-angle" style="font-size: 2.5rem; color: var(--text-muted); margin-bottom: 12px;"></i>
                <h4 style="color: #fff; margin-bottom: 6px;">لا توجد منشورات مطابقة في ساحة التبادل والتكافل</h4>
                <p style="color: var(--text-muted); font-size: 0.88rem;">يمكنك نشر فائض أو طلب دواء ناقص بالضغط على الأزرار بالأعلى.</p>
            </div>
        `;
        return;
    }

    const currentBranchId = CURRENT_USER.profile?.id;
    const isMaster = CURRENT_USER.role === "agency_master";
    const isBranch = CURRENT_USER.role === "agency_branch";

    grid.innerHTML = filtered.map(post => {
        const isSurplus = post.type === "SURPLUS";
        const isShortage = post.type === "SHORTAGE";
        const isReadyEscalate = post.status === "READY_FOR_ESCALATION" || post.hours_elapsed >= 48;
        const isFulfilled = post.status === "FULFILLED";
        const isPublishedBourse = post.status === "PUBLISHED_TO_BOURSE";

        let cardClass = isSurplus ? "exchange-card card-surplus" : "exchange-card card-shortage";
        if (isReadyEscalate && isSurplus && !isFulfilled && !isPublishedBourse) {
            cardClass = "exchange-card card-ready-escalate";
        }

        // شارة النوع
        let typeBadge = "";
        if (isSurplus) {
            typeBadge = `<span class="badge-exchange-type badge-type-surplus"><i class="fa-solid fa-box-open"></i> فائض راكد للمناقلة</span>`;
        } else {
            typeBadge = `<span class="badge-exchange-type badge-type-shortage"><i class="fa-solid fa-hand-holding-medical"></i> طلب دواء ناقص عاجل</span>`;
        }

        // مؤشر الاستعجال
        let urgencyBadge = "";
        if (post.urgency === "critical") {
            urgencyBadge = `<span class="badge-post-urgency urgency-critical"><i class="fa-solid fa-triangle-exclamation"></i> عاجل جداً</span>`;
        } else if (post.urgency === "moderate") {
            urgencyBadge = `<span class="badge-post-urgency urgency-moderate"><i class="fa-solid fa-clock"></i> استعجال متوسط</span>`;
        } else {
            urgencyBadge = `<span class="badge-post-urgency urgency-normal"><i class="fa-solid fa-shield-halved"></i> عادي</span>`;
        }

        // شريط مهلة الـ 48 ساعة SLA
        let slaHtml = "";
        if (isFulfilled) {
            slaHtml = `
                <div class="exchange-sla-box fulfilled-sla">
                    <div class="sla-header-row">
                        <span class="sla-title"><i class="fa-solid fa-circle-check" style="color: #34d399;"></i> تم التكافل والتغطية بنجاح</span>
                        <span class="sla-time-tag">عبر: ${post.fulfilled_by || "فرع شقيق"}</span>
                    </div>
                    <div class="sla-progress-track"><div class="sla-progress-fill" style="width: 100%; background: #34d399;"></div></div>
                </div>
            `;
        } else if (isPublishedBourse) {
            slaHtml = `
                <div class="exchange-sla-box published-sla">
                    <div class="sla-header-row">
                        <span class="sla-title"><i class="fa-solid fa-rocket" style="color: #38bdf8;"></i> تم الطرح للبورصة الدوائية الخارجية</span>
                        <span class="sla-time-tag">معتمد بقرار الإدارة 🔒</span>
                    </div>
                    <div class="sla-progress-track"><div class="sla-progress-fill" style="width: 100%; background: #38bdf8;"></div></div>
                </div>
            `;
        } else if (isReadyEscalate) {
            slaHtml = `
                <div class="exchange-sla-box expired-sla">
                    <div class="sla-header-row">
                        <span class="sla-title"><i class="fa-solid fa-hourglass-end" style="color: #f87171;"></i> انقضت مهلة التكافل (48 ساعة دون استيعاب)</span>
                        <span class="sla-time-tag highlight-expired">متاح للإحالة للبورصة ⚠️</span>
                    </div>
                    <div class="sla-progress-track"><div class="sla-progress-fill" style="width: 100%; background: #ef4444;"></div></div>
                    <div class="sla-desc-note">ثبوت تعذر التكافل الداخلي: يحال للإدارة المركزية لاعتماد الخصم والطرح للبورصة الخارجية بالضمان.</div>
                </div>
            `;
        } else {
            const hoursLeft = Math.max(1, 48 - (post.hours_elapsed || 0));
            const pct = Math.min(100, Math.round(((post.hours_elapsed || 0) / 48) * 100));
            slaHtml = `
                <div class="exchange-sla-box active-sla">
                    <div class="sla-header-row">
                        <span class="sla-title"><i class="fa-solid fa-stopwatch" style="color: #fbbf24;"></i> مهلة التكافل الداخلي (48 ساعة)</span>
                        <span class="sla-time-tag">متبقي <strong>${hoursLeft} ساعة</strong></span>
                    </div>
                    <div class="sla-progress-track"><div class="sla-progress-fill" style="width: ${pct}%;"></div></div>
                    <div class="sla-desc-note">انقضى ${post.hours_elapsed || 0} ساعة من الـ 48 ساعة المتاحة لتكافل الفروع الشقيقة.</div>
                </div>
            `;
        }

        // أزرار العمليات والتفاعل
        let actionsHtml = "";
        const isMyBranch = (currentBranchId && post.branch_id === currentBranchId);

        if (isFulfilled || isPublishedBourse) {
            actionsHtml = `
                <span class="exchange-status-pill done">
                    <i class="fa-solid fa-lock"></i> تم إغلاق الطلب رسمياً
                </span>
            `;
        } else if (isMaster) {
            // صلاحيات الإدارة العامة
            if (isSurplus) {
                if (isReadyEscalate) {
                    actionsHtml = `
                        <button class="btn btn-sm btn-primary" onclick="openEscalateToMarketModal('${post.id}')" title="تقرير ثبوت تعذر التكافل الداخلي وتحديد نسبة الخصم للبيع الخارجي">
                            <i class="fa-solid fa-stamp"></i> تحديد الخصم وطرح للبورصة
                        </button>
                    `;
                } else {
                    actionsHtml = `
                        <button class="btn btn-sm btn-outline" onclick="respondToExchangePost('${post.id}', 'TAKE_SURPLUS')" title="إصدار أمر مناقلة فوري لنقل هذا الفائض لفرع آخر">
                            <i class="fa-solid fa-shuffle"></i> توجيه مناقلة إدارية
                        </button>
                        <button class="btn btn-sm btn-secondary" onclick="openEscalateToMarketModal('${post.id}')" title="تجاوز المهلة وطرح للبورصة بقرار إداري استثنائي">
                            <i class="fa-solid fa-rocket"></i> طرح للبورصة
                        </button>
                    `;
                }
            } else {
                // نقص
                actionsHtml = `
                    <button class="btn btn-sm btn-outline" onclick="respondToExchangePost('${post.id}', 'FULFILL_SHORTAGE')" title="توجيه فرع شقيق لتوفير هذا النقص">
                        <i class="fa-solid fa-shuffle"></i> توجيه تغطية النقص إدارياً
                    </button>
                `;
            }
        } else if (isBranch) {
            // صلاحيات صيدلي الفرع
            if (isMyBranch) {
                if (isSurplus && isReadyEscalate) {
                    actionsHtml = `
                        <button class="btn btn-sm btn-warning" onclick="openEscalateToMarketModal('${post.id}')" title="رفع تقرير للإدارة لطلب الموافقة على البيع الخارجي وتحديد الخصم">
                            <i class="fa-solid fa-paper-plane"></i> إحالة للإدارة لتحديد الخصم والبورصة
                        </button>
                    `;
                } else {
                    actionsHtml = `
                        <span class="exchange-status-pill my-post">
                            <i class="fa-solid fa-user-check"></i> منشور من فرعكم (بانتظار استجابة الفروع)
                        </span>
                    `;
                }
            } else {
                // فرع شقيق آخر
                if (isSurplus) {
                    actionsHtml = `
                        <button class="btn btn-sm btn-success btn-pulse" onclick="respondToExchangePost('${post.id}', 'TAKE_SURPLUS')" title="استيعاب هذا الفائض ونقله لفرعك مجاناً بدون أي عمولة">
                            <i class="fa-solid fa-handshake"></i> أنا أستوعب هذا الفائض لفرعي (مجاناً)
                        </button>
                    `;
                } else {
                    actionsHtml = `
                        <button class="btn btn-sm btn-info btn-pulse" onclick="respondToExchangePost('${post.id}', 'FULFILL_SHORTAGE')" title="مساعدة الفرع الشقيق وتزويده بالكمية المطلوبة">
                            <i class="fa-solid fa-truck-medical"></i> أنا أوفر هذا الصنف لفرعكم
                        </button>
                    `;
                }
            }
        } else {
            // زائر أو صيدلية مستقلة
            actionsHtml = `
                <span class="exchange-status-pill locked">
                    <i class="fa-solid fa-lock"></i> خاص بفروع مجموعة الشفاء
                </span>
            `;
        }

        const estVal = (post.quantity || 1) * (post.original_price || 3500);

        return `
            <div class="${cardClass}">
                <div class="exchange-card-header">
                    <div class="exchange-badges-row">
                        ${typeBadge}
                        ${urgencyBadge}
                    </div>
                    <span class="exchange-post-date"><i class="fa-solid fa-calendar-day"></i> ${post.created_at}</span>
                </div>

                <div class="exchange-card-body">
                    <div class="exchange-drug-title">${post.drug_name}</div>
                    <div class="exchange-drug-active"><i class="fa-solid fa-vial"></i> المادة الفعالة: ${post.active_ingredient || "غير محدد"}</div>

                    <div class="exchange-meta-grid">
                        <div class="meta-item">
                            <span class="meta-label">الكمية:</span>
                            <span class="meta-val highlight-qty">${post.quantity} باكت</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">التشغيلة:</span>
                            <span class="meta-val"><code>${post.batch_number || "سارية"}</code></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">الصلاحية:</span>
                            <span class="meta-val">${post.expiry_date || "ساري"}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">القيمة التقديرية:</span>
                            <span class="meta-val highlight-val">${estVal.toLocaleString()} ر.ي</span>
                        </div>
                    </div>

                    <div class="exchange-branch-badge-box">
                        <div class="branch-label">الفرع الناشر:</div>
                        <div class="branch-name-val"><i class="fa-solid fa-location-dot text-primary"></i> <strong>${post.branch_name}</strong> (${post.pharmacist})</div>
                    </div>

                    <div class="exchange-notes-box">
                        <i class="fa-solid fa-comment-medical"></i>
                        <span>"${post.notes || "لا توجد ملاحظات إضافية"}"</span>
                    </div>

                    ${slaHtml}
                </div>

                <div class="exchange-card-footer">
                    <div class="exchange-zero-fee-note">
                        <i class="fa-solid fa-shield-halved"></i> 0 ر.ي عمولة مناقلة داخلية
                    </div>
                    <div class="exchange-actions-group">
                        ${actionsHtml}
                    </div>
                </div>
            </div>
        `;
    }).join("");
}

function openCreateExchangePostModal(preselectedType) {
    const typeSelect = document.getElementById("exchangePostTypeSelect");
    if (typeSelect && preselectedType) {
        typeSelect.value = preselectedType;
        onExchangePostTypeChange(preselectedType);
    }
    openModal("createExchangePostModal");
}

function onExchangePostTypeChange(type) {
    const batchGroup = document.getElementById("groupExchangeBatch");
    const expiryGroup = document.getElementById("groupExchangeExpiry");
    const title = document.getElementById("createExchangePostTitle");

    if (type === "SHORTAGE") {
        if (title) title.innerHTML = `<i class="fa-solid fa-magnifying-glass-plus" style="color: #38bdf8;"></i> طلب توفير دواء ناقص عاجل من الفروع الشقيقة`;
        if (batchGroup) batchGroup.style.display = "none";
        if (expiryGroup) expiryGroup.style.display = "none";
    } else {
        if (title) title.innerHTML = `<i class="fa-solid fa-handshake-angle" style="color: #fbbf24;"></i> نشر فائض / راكد للمناقلة والتكافل الداخلي`;
        if (batchGroup) batchGroup.style.display = "block";
        if (expiryGroup) expiryGroup.style.display = "block";
    }
}

function submitNewExchangePost() {
    const type = document.getElementById("exchangePostTypeSelect")?.value || "SURPLUS";
    const name = document.getElementById("exchangeDrugName")?.value;
    const active = document.getElementById("exchangeActiveIng")?.value || "مركب علاجي";
    const qty = parseInt(document.getElementById("exchangeQuantity")?.value) || 10;
    const batch = document.getElementById("exchangeBatch")?.value || "BT-AUTO";
    const exp = document.getElementById("exchangeExpiry")?.value || "2027-01-01";
    const urgency = document.getElementById("exchangeUrgency")?.value || "moderate";
    const notes = document.getElementById("exchangeNotes")?.value || "";

    if (!name) {
        alert("يرجى إدخال اسم الدواء");
        return;
    }

    const currentBranch = CURRENT_USER.profile || {
        id: "pharm_agency_01",
        name: "صيدلية الشفاء - فرع حدة",
        pharmacist: "د. أحمد الصنعاني",
        phone: "771987654"
    };

    const newPost = {
        id: `POST-${Date.now().toString().slice(-4)}`,
        type: type,
        drug_name: name,
        active_ingredient: active,
        batch_number: batch,
        expiry_date: exp,
        days_left: 75,
        quantity: qty,
        original_price: 3500,
        branch_id: currentBranch.id,
        branch_name: currentBranch.name,
        pharmacist: currentBranch.pharmacist,
        phone: currentBranch.phone || "771000111",
        created_at: "الآن",
        hours_elapsed: 0,
        sla_hours: 48,
        status: "ACTIVE",
        urgency: urgency,
        notes: notes || (type === "SURPLUS" ? "فائض جاهز للمناقلة المجانية لأي فرع شقيق." : "نقص عاجل مطلوب توفيره من الفروع الشقيقة.")
    };

    if (typeof MOCK_AGENCY_EXCHANGE_POSTS !== "undefined") {
        MOCK_AGENCY_EXCHANGE_POSTS.unshift(newPost);
    }

    closeModal("createExchangePostModal");
    renderAgencyExchangeBoard();

    if (type === "SURPLUS") {
        showToast(`📢 تم نشر فائض (${name}) في ساحة التبادل الداخلي بمهلة 48 ساعة لكافة أفرع الوكالة!`, "success");
    } else {
        showToast(`📢 تم تعميم طلب نقص (${name}) لكافة فروع الوكالة الشقيقة للمساعدة والتوفير الفوري!`, "success");
    }
}

function respondToExchangePost(postId, actionType) {
    const post = MOCK_AGENCY_EXCHANGE_POSTS.find(p => p.id === postId);
    if (!post) return;

    const currentBranch = CURRENT_USER.profile || {
        id: "pharm_agency_02",
        name: "صيدلية الشفاء - فرع السبعين",
        pharmacist: "د. عبدالكريم طاهر"
    };

    if (actionType === "TAKE_SURPLUS") {
        const confirmMsg = `هل تؤكد رغبة فرع (${currentBranch.name}) في استيعاب كامل فائض صنف (${post.drug_name}) بكمية (${post.quantity} باكت) من (${post.branch_name}) بمناقلة مجانية (0 ر.ي عمولة)؟`;
        if (!confirm(confirmMsg)) return;

        // إنشاء مناقلة في جدول المناقلات
        const transferId = `TR-${Math.floor(1000 + Math.random() * 9000)}`;
        const voucherNo = `TR-ONX-2026-${Math.floor(1000 + Math.random() * 9000)}`;
        const newTransfer = {
            id: transferId,
            erp_voucher: voucherNo,
            drug_name: post.drug_name,
            active_ingredient: post.active_ingredient,
            batch_number: post.batch_number,
            expiry_date: post.expiry_date,
            days_left: post.days_left || 70,
            quantity: post.quantity,
            estimated_value: post.quantity * (post.original_price || 3500),
            from_branch_id: post.branch_id,
            from_branch_name: post.branch_name,
            from_pharmacist: post.pharmacist,
            to_branch_id: currentBranch.id,
            to_branch_name: currentBranch.name,
            to_pharmacist: currentBranch.pharmacist,
            status: "IN_TRANSIT",
            step: 3,
            reason: `استيعاب فائض راكد عبر ساحة التكافل الداخلي (${post.id})`,
            requested_by: `${currentBranch.pharmacist} (${currentBranch.name})`,
            created_at: "الآن",
            approved_at: "الآن (معتمد آلياً بالتكافل)",
            completed_at: null,
            driver_name: "فؤاد السريحي (مندوب التوزيع)",
            driver_phone: "770123987",
            cooling_required: false,
            notes: "تم الاتفاق والتكافل بين الفرعين بدون أي عمولة وساطة."
        };

        MOCK_INTERNAL_TRANSFERS.unshift(newTransfer);
        post.status = "FULFILLED";
        post.fulfilled_by = currentBranch.name;

        renderAgencyExchangeBoard();
        renderAgencyTransfers();
        updateNavbarAndUI();

        showToast(`🤝 أروع صور التكافل! تم استيعاب فائض (${post.drug_name}) وإصدار سند المناقلة (${voucherNo}) لنقله لفرعكم مجاناً!`, "success");
    } else {
        // FULFILL_SHORTAGE
        const confirmMsg = `هل تؤكد توفير وتزويد فرع (${post.branch_name}) بالكمية المطلوبة (${post.quantity} باكت) من صنف (${post.drug_name}) من مخزون فرعكم؟`;
        if (!confirm(confirmMsg)) return;

        const transferId = `TR-${Math.floor(1000 + Math.random() * 9000)}`;
        const voucherNo = `TR-ONX-2026-${Math.floor(1000 + Math.random() * 9000)}`;
        const newTransfer = {
            id: transferId,
            erp_voucher: voucherNo,
            drug_name: post.drug_name,
            active_ingredient: post.active_ingredient,
            batch_number: post.batch_number || "BT-9901",
            expiry_date: post.expiry_date || "2027-02-15",
            days_left: post.days_left || 80,
            quantity: post.quantity,
            estimated_value: post.quantity * (post.original_price || 3500),
            from_branch_id: currentBranch.id,
            from_branch_name: currentBranch.name,
            from_pharmacist: currentBranch.pharmacist,
            to_branch_id: post.branch_id,
            to_branch_name: post.branch_name,
            to_pharmacist: post.pharmacist,
            status: "IN_TRANSIT",
            step: 3,
            reason: `تلبية نقص عاجل لفرع شقيق عبر ساحة التكافل الداخلي (${post.id})`,
            requested_by: `${currentBranch.pharmacist} (${currentBranch.name})`,
            created_at: "الآن",
            approved_at: "الآن (معتمد بالتكافل)",
            completed_at: null,
            driver_name: "فؤاد السريحي (مندوب التوزيع)",
            driver_phone: "770123987",
            cooling_required: false,
            notes: "تمت الاستجابة الفورية لطلب النقص وتجهيز الطرد للشحن مع المندوب."
        };

        MOCK_INTERNAL_TRANSFERS.unshift(newTransfer);
        post.status = "FULFILLED";
        post.fulfilled_by = currentBranch.name;

        renderAgencyExchangeBoard();
        renderAgencyTransfers();
        updateNavbarAndUI();

        showToast(`👏 كفو يا دكتور! تم تغطية نقص فرع (${post.branch_name}) بنجاح وإصدار سند المناقلة (${voucherNo}) مع المندوب!`, "success");
    }
}

function openEscalateToMarketModal(postId) {
    const post = MOCK_AGENCY_EXCHANGE_POSTS.find(p => p.id === postId);
    if (!post) return;

    selectedPostForEscalation = post;
    const detailsArea = document.getElementById("escalationDetailsArea");
    if (detailsArea) {
        detailsArea.innerHTML = `
            <div style="background: rgba(15, 23, 42, 0.7); padding: 14px; border-radius: 8px; border: 1px solid var(--border-color); font-size: 0.92rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                    <strong style="color: #fff; font-size: 1.1rem;">${post.drug_name}</strong>
                    <span class="badge-branch-tag"><i class="fa-solid fa-location-dot"></i> ${post.branch_name}</span>
                </div>
                <div style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 10px;">
                    المادة الفعالة: ${post.active_ingredient} | التشغيلة: <code>${post.batch_number}</code> | الصلاحية: <strong>${post.expiry_date}</strong> (باقي ${post.days_left || 48} يوماً)
                </div>
                <div style="display: flex; gap: 18px; flex-wrap: wrap; background: rgba(0,0,0,0.3); padding: 10px; border-radius: 6px;">
                    <div>الكمية الراكدة: <strong style="color: #38bdf8;">${post.quantity} باكت</strong></div>
                    <div>سعر الجملة الأصلي: <strong style="color: #fff;">${(post.original_price || 3500).toLocaleString()} ر.ي</strong></div>
                    <div>إجمالي رأس المال المحتجز: <strong style="color: #fbbf24;">${((post.quantity || 1) * (post.original_price || 3500)).toLocaleString()} ر.ي</strong></div>
                </div>
            </div>
        `;
    }

    const range = document.getElementById("escalationDiscountRange");
    if (range) range.value = 40;
    onEscalationDiscountChange(40);

    openModal("escalateToMarketModal");
}

function onEscalationDiscountChange(val) {
    if (!selectedPostForEscalation) return;
    const p = parseInt(val) || 40;
    const orig = selectedPostForEscalation.original_price || 3500;
    const clearance = Math.round(orig * (1 - p / 100));
    const totalCash = clearance * (selectedPostForEscalation.quantity || 1);

    const disp = document.getElementById("escalationDiscountDisplay");
    const clrEl = document.getElementById("escalationClearancePrice");
    const totEl = document.getElementById("escalationTotalCash");

    if (disp) disp.innerText = `${p}%`;
    if (clrEl) clrEl.innerText = `${clearance.toLocaleString()} ر.ي`;
    if (totEl) totEl.innerText = `${totalCash.toLocaleString()} ر.ي كاش`;
}

function confirmEscalationAndPublish() {
    if (!selectedPostForEscalation) return;

    const range = document.getElementById("escalationDiscountRange");
    const p = range ? (parseInt(range.value) || 40) : 40;
    const orig = selectedPostForEscalation.original_price || 3500;
    const clearance = Math.round(orig * (1 - p / 100));

    // تحديث المنشور في ساحة التبادل
    selectedPostForEscalation.status = "PUBLISHED_TO_BOURSE";
    selectedPostForEscalation.notes = (selectedPostForEscalation.notes || "") + ` [تمت الإحالة للإدارة المركزية وطرحه للبورصة بخصم ${p}%]`;

    // طرح أو تحديث في البورصة MOCK_LISTINGS
    let listing = MOCK_LISTINGS.find(l => l.brand_name === selectedPostForEscalation.drug_name && l.pharmacy_id === selectedPostForEscalation.branch_id);
    if (listing) {
        listing.discount_percent = p;
        listing.clearance_price = clearance;
        listing.is_published = true;
        listing.status = "active";
        listing.clearance_requested = false;
    } else {
        listing = {
            id: `lst_esc_${Date.now()}`,
            brand_name: selectedPostForEscalation.drug_name,
            active_ingredient: selectedPostForEscalation.active_ingredient,
            manufacturer: "شركة معتمدة",
            batch_number: selectedPostForEscalation.batch_number,
            quantity: selectedPostForEscalation.quantity,
            expiry_date: selectedPostForEscalation.expiry_date,
            days_left: selectedPostForEscalation.days_left || 48,
            urgency: "critical",
            original_price: orig,
            discount_percent: p,
            clearance_price: clearance,
            pharmacy_id: selectedPostForEscalation.branch_id,
            status: "active",
            clearance_requested: false,
            is_published: true
        };
        MOCK_LISTINGS.unshift(listing);
    }

    closeModal("escalateToMarketModal");
    renderAgencyExchangeBoard();
    renderMyListingsTable();
    renderMarketplace();
    updateNavbarAndUI();

    showToast(`👑 [قرار إداري معتمد]: تم إثبات تعذر الاستيعاب الداخلي بعد 48 ساعة، وطرح صنف (${selectedPostForEscalation.drug_name}) رسمياً في البورصة الدوائية بخصم (${p}%) بالضمان المالي!`, "success");
}

// ==============================================================================
// منظومة المناقلات الداخلية الرسمية - PharmaLink Enterprise Transfers
// ==============================================================================

currentTransfersFilter = "ALL";
currentTransfersSearch = "";
let activeDispatchTransferId = null;
let activeReceiveTransferId = null;

function getSecurityContext() {
    const isMaster = CURRENT_USER.role === "agency_master";
    const branchId = isMaster ? null : (CURRENT_USER.profile?.id || "pharm_agency_01");
    return {
        userId: CURRENT_USER.profile?.pharmacist || CURRENT_USER.name || "مستخدم فارما لينك",
        role: CURRENT_USER.role,
        pharmacyId: branchId,
        chainId: CURRENT_USER.profile?.agency_id || "agency_shifa"
    };
}

function filterTransfersByStatus(status, btnElement) {
    currentTransfersFilter = status;
    document.querySelectorAll(".transfer-filter-pill").forEach(p => p.classList.remove("active"));
    if (btnElement) btnElement.classList.add("active");
    renderAgencyTransfers();
}

function onTransferSearchInput(val) {
    currentTransfersSearch = (val || "").trim().toLowerCase();
    renderAgencyTransfers();
}

function updateAgencyTransfersStats() {
    const list = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined") ? MOCK_INTERNAL_TRANSFERS : [];
    const isMaster = CURRENT_USER.role === "agency_master";
    const currentBranchId = CURRENT_USER.profile?.id || "pharm_agency_01";

    let actionNeededCount = 0;
    let incomingCount = 0;
    let outgoingCount = 0;
    let transitCount = 0;
    let discrepancyCount = 0;
    let completedCount = 0;

    list.forEach(t => {
        const isSender = t.from_pharmacy_id === currentBranchId;
        const isReceiver = t.to_pharmacy_id === currentBranchId;

        if (isReceiver) incomingCount++;
        if (isSender) outgoingCount++;
        if (t.status === "in_transit") transitCount++;
        if (t.status === "needs_discrepancy_resolution") discrepancyCount++;
        if (t.status === "completed" || t.status === "cancelled" || t.status === "rejected") completedCount++;

        // Action needed evaluation
        if (isMaster) {
            if (t.status === "pending_management_approval" || t.status === "needs_discrepancy_resolution") {
                actionNeededCount++;
            }
        } else {
            if (isSender && (t.status === "pending_counterpart_approval" || t.status === "approved_and_reserved")) {
                actionNeededCount++;
            }
            if (isReceiver && t.status === "in_transit") {
                actionNeededCount++;
            }
        }
    });

    const pendingTotal = list.filter(t => t.status === "pending_counterpart_approval" || t.status === "pending_management_approval").length;
    const completedTotal = list.filter(t => t.status === "completed").length;
    const transitTotal = list.filter(t => t.status === "in_transit").length;
    const totalTransferredValue = list
        .filter(t => t.status === "completed" || t.status === "in_transit")
        .reduce((sum, t) => sum + (t.estimated_value || 0), 0);

    // Update Top Stat Cards
    const elCompleted = document.getElementById("stat-agency-completed-transfers");
    const elPending = document.getElementById("stat-agency-pending-transfers");
    const elTransit = document.getElementById("stat-agency-transit-transfers");
    const elSaved = document.getElementById("stat-agency-saved-value");

    if (elCompleted) elCompleted.innerText = `${completedTotal} مناقلات`;
    if (elPending) elPending.innerText = `${pendingTotal} طلبات`;
    if (elTransit) elTransit.innerText = `${transitTotal} شحنات`;
    if (elSaved) elSaved.innerHTML = `${totalTransferredValue.toLocaleString()} <small>ر.ي</small>`;

    // Update Filter Pills Badges
    const countAll = document.getElementById("count-filter-all");
    const countAction = document.getElementById("count-filter-action");
    const countIncoming = document.getElementById("count-filter-incoming");
    const countOutgoing = document.getElementById("count-filter-outgoing");
    const countTransit = document.getElementById("count-filter-transit");
    const countDiscrepancy = document.getElementById("count-filter-discrepancy");
    const countCompleted = document.getElementById("count-filter-completed");

    if (countAll) countAll.innerText = list.length;
    if (countAction) countAction.innerText = actionNeededCount;
    if (countIncoming) countIncoming.innerText = incomingCount;
    if (countOutgoing) countOutgoing.innerText = outgoingCount;
    if (countTransit) countTransit.innerText = transitCount;
    if (countDiscrepancy) countDiscrepancy.innerText = discrepancyCount;
    if (countCompleted) countCompleted.innerText = completedCount;

    // Subtab Nav Badge
    const subtabBadge = document.getElementById("subtabTransfersBadge");
    if (subtabBadge) {
        if (actionNeededCount > 0) {
            subtabBadge.style.display = "inline-flex";
            subtabBadge.innerText = `${actionNeededCount} إجراء مطلوب`;
        } else {
            subtabBadge.style.display = "none";
        }
    }
}

function renderAgencyTransfers() {
    const container = document.getElementById("agencyTransfersList");
    if (!container) return;

    updateAgencyTransfersStats();

    const isMaster = CURRENT_USER.role === "agency_master";
    const currentBranchId = CURRENT_USER.profile?.id || "pharm_agency_01";
    let list = [...((typeof MOCK_INTERNAL_TRANSFERS !== "undefined") ? MOCK_INTERNAL_TRANSFERS : [])];

    // Filter Logic across the 6 approved tabs
    if (currentTransfersFilter === "ACTION_NEEDED") {
        list = list.filter(t => {
            if (isMaster) {
                return t.status === "pending_management_approval" || t.status === "needs_discrepancy_resolution";
            } else {
                const isSender = t.from_pharmacy_id === currentBranchId;
                const isReceiver = t.to_pharmacy_id === currentBranchId;
                return (isSender && (t.status === "pending_counterpart_approval" || t.status === "approved_and_reserved")) ||
                       (isReceiver && t.status === "in_transit");
            }
        });
    } else if (currentTransfersFilter === "INCOMING") {
        list = list.filter(t => t.to_pharmacy_id === currentBranchId);
    } else if (currentTransfersFilter === "OUTGOING") {
        list = list.filter(t => t.from_pharmacy_id === currentBranchId);
    } else if (currentTransfersFilter === "IN_TRANSIT") {
        list = list.filter(t => t.status === "in_transit");
    } else if (currentTransfersFilter === "DISCREPANCY") {
        list = list.filter(t => t.status === "needs_discrepancy_resolution");
    } else if (currentTransfersFilter === "COMPLETED") {
        list = list.filter(t => t.status === "completed" || t.status === "cancelled" || t.status === "rejected");
    }

    // Search Box Filter
    if (currentTransfersSearch) {
        list = list.filter(t => {
            return (t.drug_name && t.drug_name.toLowerCase().includes(currentTransfersSearch)) ||
                   (t.transfer_code && t.transfer_code.toLowerCase().includes(currentTransfersSearch)) ||
                   (t.from_pharmacy_name && t.from_pharmacy_name.toLowerCase().includes(currentTransfersSearch)) ||
                   (t.to_pharmacy_name && t.to_pharmacy_name.toLowerCase().includes(currentTransfersSearch)) ||
                   (t.batch_number && t.batch_number.toLowerCase().includes(currentTransfersSearch));
        });
    }

    if (list.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 45px 20px; background: rgba(0,0,0,0.2); border-radius: 12px; border: 1px dashed var(--border-color);">
                <i class="fa-solid fa-boxes-packing" style="font-size: 2.5rem; color: var(--text-muted); margin-bottom: 12px;"></i>
                <h4 style="color: #fff; margin-bottom: 6px;">لا توجد سجلات مناقلة مطابقة للفلتر الحالي</h4>
                <p style="color: var(--text-muted); font-size: 0.88rem;">يمكنك إنشاء أمر مناقلة جديد أو نشر فائض/احتياج من ساحة التبادل.</p>
            </div>
        `;
        return;
    }

    container.innerHTML = list.map(t => {
        // Status Badge Mapping
        let statusBadge = "";
        let reservationPill = "";

        if (t.status === "pending_counterpart_approval") {
            statusBadge = `<span class="badge-status" style="background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4);"><i class="fa-solid fa-clock"></i> بانتظار موافقة الطرف المرسل</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #94a3b8;"><i class="fa-solid fa-shield"></i> لم يُحجز بعد</span>`;
        } else if (t.status === "pending_management_approval") {
            statusBadge = `<span class="badge-status" style="background: rgba(249, 115, 22, 0.2); color: #fb923c; border: 1px solid rgba(249, 115, 22, 0.4);"><i class="fa-solid fa-stamp"></i> بانتظار اعتماد الإدارة المركزية</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #38bdf8;"><i class="fa-solid fa-lock"></i> محجوز نشط (${t.quantity} باكت)</span>`;
        } else if (t.status === "approved_and_reserved") {
            statusBadge = `<span class="badge-status" style="background: rgba(14, 165, 233, 0.2); color: #38bdf8; border: 1px solid rgba(14, 165, 233, 0.4);"><i class="fa-solid fa-box-archive"></i> معتمدة ومحجوزة (جاهزة للتجهيز)</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #38bdf8;"><i class="fa-solid fa-lock"></i> محجوز نشط (${t.quantity} باكت)</span>`;
        } else if (t.status === "in_preparation") {
            statusBadge = `<span class="badge-status" style="background: rgba(99, 102, 241, 0.2); color: #818cf8; border: 1px solid rgba(99, 102, 241, 0.4);"><i class="fa-solid fa-boxes-packing"></i> قيد التجهيز بالفرع</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #818cf8;"><i class="fa-solid fa-lock"></i> محجوز للتجهيز</span>`;
        } else if (t.status === "in_transit") {
            statusBadge = `<span class="badge-status" style="background: rgba(56, 189, 248, 0.2); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.4);"><i class="fa-solid fa-paper-plane"></i> تم الإرسال — بانتظار الاستلام</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #10b981;"><i class="fa-solid fa-check"></i> الحجز مُستهلك (صرف فعلي)</span>`;
        } else if (t.status === "needs_discrepancy_resolution") {
            statusBadge = `<span class="badge-status" style="background: rgba(244, 63, 94, 0.2); color: #f43f5e; border: 1px solid rgba(244, 63, 94, 0.4);"><i class="fa-solid fa-triangle-exclamation"></i> بحاجة إلى معالجة اختلاف (نقص/تلف)</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #f43f5e;"><i class="fa-solid fa-hand-holding-box"></i> عهدة حجر قيد المعالجة</span>`;
        } else if (t.status === "completed") {
            statusBadge = `<span class="badge-status badge-active"><i class="fa-solid fa-circle-check"></i> مكتملة ومطابقة</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #10b981;"><i class="fa-solid fa-check-double"></i> مكتملة ومنقولة</span>`;
        } else if (t.status === "rejected") {
            statusBadge = `<span class="badge-status" style="background: rgba(239, 68, 68, 0.2); color: #f87171;"><i class="fa-solid fa-ban"></i> مرفوضة (فُك الحجز)</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #94a3b8;"><i class="fa-solid fa-lock-open"></i> فُك الحجز لمرة واحدة</span>`;
        } else {
            statusBadge = `<span class="badge-status" style="background: rgba(148, 163, 184, 0.2); color: #94a3b8;"><i class="fa-solid fa-xmark"></i> ملغاة</span>`;
            reservationPill = `<span style="font-size: 0.78rem; color: #94a3b8;"><i class="fa-solid fa-lock-open"></i> فُك الحجز</span>`;
        }

        // Stepper Progress Calculation
        let step = 1;
        if (t.status === "pending_management_approval" || t.status === "approved_and_reserved") step = 2;
        if (t.status === "in_transit") step = 3;
        if (t.status === "completed" || t.status === "needs_discrepancy_resolution") step = 4;

        const s1Class = step >= 1 ? "step-done" : "";
        const s2Class = step >= 2 ? "step-done" : (step === 1 ? "step-current" : "");
        const s3Class = step >= 3 ? "step-done" : (step === 2 ? "step-current" : "");
        const s4Class = step >= 4 ? "step-done" : (step === 3 ? "step-current" : "");

        // Dynamic Action Buttons
        let actionButtons = `
            <button class="btn btn-sm btn-outline" onclick="openTransferVoucherModal('${t.id}')" title="عرض وطباعة سند مناقلة داخلية — PharmaLink">
                <i class="fa-solid fa-file-invoice"></i> سند PharmaLink
            </button>
        `;

        const isSender = t.from_pharmacy_id === currentBranchId;
        const isReceiver = t.to_pharmacy_id === currentBranchId;

        if (isMaster) {
            if (t.status === "pending_management_approval") {
                actionButtons += `
                    <button class="btn btn-sm btn-primary" onclick="approveTransferByMaster('${t.id}')">
                        <i class="fa-solid fa-stamp"></i> اعتماد الإدارة
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="rejectTransferByMaster('${t.id}')">
                        <i class="fa-solid fa-ban"></i> رفض
                    </button>
                `;
            } else if (t.status === "needs_discrepancy_resolution") {
                actionButtons += `
                    <button class="btn btn-sm btn-warning" onclick="openDiscrepancyResolutionModal('${t.id}')">
                        <i class="fa-solid fa-gavel"></i> تسوية الاختلاف
                    </button>
                `;
            }
        } else {
            // Branch Actions
            if (isSender) {
                if (t.status === "pending_counterpart_approval") {
                    actionButtons += `
                        <button class="btn btn-sm btn-primary" onclick="approveSenderTransfer('${t.id}')">
                            <i class="fa-solid fa-box-archive"></i> موافقة وتخصيص المخزون
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="rejectTransferByBranch('${t.id}')">
                            <i class="fa-solid fa-ban"></i> رفض الطلب
                        </button>
                    `;
                } else if (t.status === "approved_and_reserved" || t.status === "in_preparation") {
                    actionButtons += `
                        <button class="btn btn-sm btn-info" onclick="openDispatchTransferModal('${t.id}')">
                            <i class="fa-solid fa-paper-plane"></i> تأكيد إرسال المناقلة
                        </button>
                    `;
                }
            }
            if (isReceiver) {
                if (t.status === "in_transit") {
                    actionButtons += `
                        <button class="btn btn-sm btn-success btn-pulse" onclick="openReceiveTransferModal('${t.id}')">
                            <i class="fa-solid fa-clipboard-check"></i> فحص وتأكيد الاستلام
                        </button>
                    `;
                }
            }
        }

        const isCold = t.cooling_required ? `<span class="badge-cooling"><i class="fa-solid fa-snowflake"></i> تبريد 2-8°C</span>` : "";

        return `
            <div class="transfer-card">
                <div class="transfer-card-header">
                    <div class="transfer-header-right">
                        <span class="transfer-voucher-tag" style="background: rgba(14, 165, 233, 0.15); color: #38bdf8; border: 1px solid rgba(14, 165, 233, 0.3);">
                            <i class="fa-solid fa-fingerprint"></i> ${t.transfer_code || ('PL-TRF-2026-' + t.id)}
                        </span>
                        <span class="transfer-id-sub">السياسة: <strong>${t.policy_applied === 'centralized' ? 'اعتماد مركزي' : 'تفويض الفروع'}</strong></span>
                        <span class="transfer-date"><i class="fa-solid fa-calendar-day"></i> ${t.created_at}</span>
                    </div>
                    <div style="display: flex; gap: 8px; align-items: center;">
                        ${reservationPill}
                        ${statusBadge}
                    </div>
                </div>

                <div class="transfer-card-body">
                    <div class="transfer-main-info">
                        <div class="transfer-drug-title">
                            ${t.drug_name} ${isCold}
                        </div>
                        <div class="transfer-drug-meta">
                            المادة الفعالة: ${t.active_ingredient || "دواء علاجي"} | التشغيلة: <code>${t.batch_number}</code> | الصلاحية: <strong>${t.expiry_date}</strong> (متبقي ${t.days_left || 70} يوماً)
                        </div>

                        <!-- مسار النقل بين الفرعين التابعين لنفس السلسلة -->
                        <div class="transfer-route-box">
                            <div class="route-point from-point">
                                <span class="route-label">الفرع المانح (المرسل)</span>
                                <strong><i class="fa-solid fa-building-circle-arrow-right"></i> ${t.from_pharmacy_name}</strong>
                                <small>المسؤول: ${t.from_pharmacist}</small>
                            </div>
                            <div class="route-arrow">
                                <i class="fa-solid fa-arrow-left"></i>
                                <span class="route-driver" style="font-size: 0.74rem; color: #94a3b8;"><i class="fa-solid fa-handshake"></i> يُرتّب النقل خارج المنصة</span>
                            </div>
                            <div class="route-point to-point">
                                <span class="route-label">الفرع المستلم</span>
                                <strong><i class="fa-solid fa-building-circle-check"></i> ${t.to_pharmacy_name}</strong>
                                <small>المسؤول: ${t.to_pharmacist}</small>
                            </div>
                        </div>

                        <div class="transfer-reason-strip">
                            <i class="fa-solid fa-comment-dots" style="color: var(--accent-blue);"></i>
                            <span><strong>مبرر المناقلة:</strong> ${t.reason}</span>
                        </div>
                        ${t.dispatch_notes || t.notes ? `<div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;"><i class="fa-solid fa-circle-info"></i> ملاحظات الإرسال: ${t.dispatch_notes || t.notes}</div>` : ""}
                    </div>

                    <div class="transfer-financial-side">
                        <div class="financial-metric">
                            <span class="fin-label">الكمية المنقولة:</span>
                            <span class="fin-value highlight-qty">${t.quantity} باكت</span>
                        </div>
                        <div class="financial-metric">
                            <span class="fin-label">قيمة المخزون المنقول:</span>
                            <span class="fin-value highlight-cash">${(t.estimated_value || 0).toLocaleString()} ر.ي</span>
                        </div>
                        <div class="financial-metric">
                            <span class="fin-label">عمولة فارما لينك:</span>
                            <span class="fin-value zero-fee"><i class="fa-solid fa-shield-heart"></i> 0.00 ر.ي (بدون عمولة)</span>
                        </div>
                        <div class="financial-metric" style="border-top: 1px dashed rgba(255,255,255,0.1); padding-top: 4px; margin-top: 4px;">
                            <span class="fin-label" style="font-size: 0.76rem; color: #94a3b8;"><i class="fa-solid fa-circle-info"></i> النقل:</span>
                            <span class="fin-value" style="color: #94a3b8; font-size: 0.76rem;">يُرتّب خارج المنصة</span>
                        </div>
                    </div>
                </div>

                <!-- شريط المراحل التفاعلي Stepper -->
                <div class="transfer-stepper-bar">
                    <div class="step-item ${s1Class}">
                        <div class="step-num"><i class="fa-solid fa-file-signature"></i></div>
                        <div class="step-text">
                            <strong>1. إنشاء الطلب</strong>
                            <small>${t.created_by || t.from_pharmacist}</small>
                        </div>
                    </div>
                    <div class="step-divider ${step >= 2 ? "active" : ""}"></div>
                    <div class="step-item ${s2Class}">
                        <div class="step-num"><i class="fa-solid fa-stamp"></i></div>
                        <div class="step-text">
                            <strong>2. موافقة وتخصيص المخزون</strong>
                            <small>${t.sender_approved_by ? ('معتمد: ' + t.sender_approved_by) : 'بانتظار التخصيص'}</small>
                        </div>
                    </div>
                    <div class="step-divider ${step >= 3 ? "active" : ""}"></div>
                    <div class="step-item ${s3Class}">
                        <div class="step-num"><i class="fa-solid fa-paper-plane"></i></div>
                        <div class="step-text">
                            <strong>3. تأكيد الإرسال</strong>
                            <small>${t.dispatched_at ? ('تم الإرسال: ' + (t.dispatched_by || 'الفرع المرسل')) : 'بانتظار الإرسال'}</small>
                        </div>
                    </div>
                    <div class="step-divider ${step >= 4 ? "active" : ""}"></div>
                    <div class="step-item ${s4Class}">
                        <div class="step-num"><i class="fa-solid fa-clipboard-check"></i></div>
                        <div class="step-text">
                            <strong>4. الاستلام الفعلي</strong>
                            <small>${t.received_by ? ('مستلم: ' + t.received_by) : 'بانتظار الفحص'}</small>
                        </div>
                    </div>
                </div>

                <div class="transfer-card-footer">
                    <div class="transfer-footer-hint">
                        <i class="fa-solid fa-circle-check" style="color: var(--primary-light);"></i>
                        <span>مناقلة داخلية رسمية مسجلة وموثقة في سجلات فارما لينك المعتمدة</span>
                    </div>
                    <div class="transfer-footer-actions">
                        ${actionButtons}
                    </div>
                </div>
            </div>
        `;
    }).join("");
}

// -----------------------------------------------------------------------------
// إجراءات دورة المناقلة (Atomic Handlers via TransferService)
// -----------------------------------------------------------------------------

async function approveSenderTransfer(transferId) {
    try {
        const context = getSecurityContext();
        const res = await TransferService.approveSenderAllocation(context, {
            transferId,
            idempotencyKey: `APPROVE-SENDER-${transferId}-${Date.now()}`
        });

        // Update local object
        const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === transferId);
        if (item) {
            item.status = res.transfer.status;
            item.sender_approved_by = context.userId;
            item.sender_approved_at = new Date().toLocaleString('ar-YE');
        }

        renderAgencyTransfers();
        renderMyListingsTable();
        updateNavbarAndUI();

        showToast(`✅ تم حجز وتخصيص المخزون بنجاح. أصبحت المناقلة في حالة (${item.status === 'pending_management_approval' ? 'بانتظار اعتماد الإدارة' : 'معتمدة ومحجوزة'}).`, "success");
    } catch (err) {
        showToast(`❌ خطأ في تخصيص المخزون: ${err.message}`, "error");
    }
}

async function approveTransferByMaster(transferId) {
    try {
        const context = getSecurityContext();
        const res = await TransferService.approveManagement(context, {
            transferId,
            reason: "معتمد من الإدارة العامة للمصلحة التشغيلية للسلسلة",
            idempotencyKey: `APPROVE-MASTER-${transferId}-${Date.now()}`
        });

        const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === transferId);
        if (item) {
            item.status = res.transfer.status;
            item.management_approved_by = context.userId;
            item.management_approved_at = new Date().toLocaleString('ar-YE');
        }

        renderAgencyTransfers();
        updateNavbarAndUI();
        showToast(`👑 تم اعتماد المناقلة من الإدارة العامة بنجاح! جاهزة الآن للتجهيز والشحن من قبل الفرع المرسل.`, "success");
    } catch (err) {
        showToast(`❌ تعذر الاعتماد الإداري: ${err.message}`, "error");
    }
}

async function rejectTransferByMaster(transferId) {
    const reason = prompt("يرجى كتابة سبب رفض أمر المناقلة:", "المخزون محجوز لأولويات تشغيلية بالفرع");
    if (reason === null) return;

    try {
        const context = getSecurityContext();
        await TransferService.cancelOrRejectTransfer(context, {
            transferId,
            action: "REJECT",
            reason,
            idempotencyKey: `REJECT-${transferId}-${Date.now()}`
        });

        const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === transferId);
        if (item) {
            item.status = "rejected";
            item.reason = `مرفوض: ${reason}`;
        }

        renderAgencyTransfers();
        renderMyListingsTable();
        updateNavbarAndUI();
        showToast(`تم رفض المناقلة وفك أي حجز مرتبط بها بنجاح.`, "warning");
    } catch (err) {
        showToast(`❌ خطأ أثناء الرفض: ${err.message}`, "error");
    }
}

async function rejectTransferByBranch(transferId) {
    const reason = prompt("يرجى إدخال سبب تعذر تلبية المناقلة:", "عدم توفر الكمية المطلوبة بالصلاحية المحددة");
    if (reason === null) return;

    try {
        const context = getSecurityContext();
        await TransferService.cancelOrRejectTransfer(context, {
            transferId,
            action: "REJECT",
            reason,
            idempotencyKey: `REJECT-BRANCH-${transferId}-${Date.now()}`
        });

        const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === transferId);
        if (item) {
            item.status = "rejected";
            item.reason = `تعذر التلبية: ${reason}`;
        }

        renderAgencyTransfers();
        renderMyListingsTable();
        updateNavbarAndUI();
        showToast(`تم رفض الطلب وفك أي حجز بنجاح.`, "warning");
    } catch (err) {
        showToast(`❌ خطأ: ${err.message}`, "error");
    }
}

// -----------------------------------------------------------------------------
// مودال تجهيز وتأكيد الإرسال (Dispatch Review Modal)
// -----------------------------------------------------------------------------
// مودال تأكيد إرسال المناقلة (PharmaLink Dispatch Confirmation Modal)
// -----------------------------------------------------------------------------

function openDispatchTransferModal(transferId) {
    activeDispatchTransferId = transferId;
    const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === transferId);
    if (!item) return;

    const detailsEl = document.getElementById("dispatchReviewDetails");
    if (detailsEl) {
        detailsEl.innerHTML = `
            <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-color); border-radius: 8px; padding: 12px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;">
                    <span>سند رقم: <strong>${item.transfer_code || item.id}</strong></span>
                    <span>الفرع المرسل: <strong style="color: #38bdf8;">${item.from_pharmacy_name}</strong></span>
                    <span>الفرع المستلم: <strong style="color: #10b981;">${item.to_pharmacy_name}</strong></span>
                </div>
                <table style="width: 100%; border-collapse: collapse; font-size: 0.88rem; margin-top: 8px;">
                    <thead>
                        <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-muted); text-align: right;">
                            <th style="padding: 6px;">الصنف الدوائي</th>
                            <th style="padding: 6px;">التشغيلة</th>
                            <th style="padding: 6px;">الصلاحية</th>
                            <th style="padding: 6px; text-align: center;">الوحدة</th>
                            <th style="padding: 6px; text-align: center;">الكمية</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="padding: 6px;"><strong>${item.drug_name}</strong></td>
                            <td style="padding: 6px;"><code>${item.batch_number}</code></td>
                            <td style="padding: 6px;">${item.expiry_date}</td>
                            <td style="padding: 6px; text-align: center;">باكت</td>
                            <td style="padding: 6px; text-align: center; color: #38bdf8; font-weight: 700; font-size: 1.05rem;">${item.quantity}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        `;
    }

    const notesInput = document.getElementById("dispatchNotes");
    if (notesInput) notesInput.value = item.dispatch_notes || item.notes || "";

    openModal("dispatchTransferModal");
}

async function confirmDispatchTransfer() {
    if (!activeDispatchTransferId) return;
    const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === activeDispatchTransferId);
    if (!item) return;

    const notes = document.getElementById("dispatchNotes")?.value?.trim() || "";

    try {
        const context = getSecurityContext();
        await TransferService.dispatchTransfer(context, {
            transferId: activeDispatchTransferId,
            notes,
            idempotencyKey: `DISPATCH-${activeDispatchTransferId}-${Date.now()}`
        });

        // Update local object
        item.status = "in_transit";
        item.step = 3;
        item.dispatch_notes = notes;
        item.dispatched_by = context.userId;
        item.dispatched_at = new Date().toLocaleString('ar-YE');

        // Deduct from local MOCK_LISTINGS once
        const invItem = MOCK_LISTINGS.find(l => l.brand_name === item.drug_name && l.pharmacy_id === item.from_pharmacy_id);
        if (invItem) {
            invItem.quantity = Math.max(0, invItem.quantity - item.quantity);
            invItem.physical_quantity = Math.max(0, (invItem.physical_quantity || invItem.quantity) - item.quantity);
        }

        closeModal("dispatchTransferModal");
        renderAgencyTransfers();
        renderMyListingsTable();
        renderMarketplace();
        updateNavbarAndUI();

        showToast(`📦 تم تأكيد إرسال المناقلة وخصم المخزون لمرة واحدة بنجاح. الحالة: [تم الإرسال — بانتظار الاستلام].`, "success");
    } catch (err) {
        showToast(`❌ خطأ أثناء الإرسال: ${err.message}`, "error");
    }
}

// -----------------------------------------------------------------------------
// مودال فحص وتأكيد الاستلام الفعلي ومطابقة الاختلافات (Receive Modal)
// -----------------------------------------------------------------------------

function openReceiveTransferModal(transferId) {
    activeReceiveTransferId = transferId;
    const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === transferId);
    if (!item) return;

    const tableArea = document.getElementById("receiveInspectionTableArea");
    if (!tableArea) return;

    const lineItemId = item.items && item.items[0] ? item.items[0].id : `ITEM-${item.id}-1`;

    tableArea.innerHTML = `
        <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-color); border-radius: 8px; padding: 14px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                <span>سند رقم: <strong>${item.transfer_code || item.id}</strong></span>
                <span>الفرع المرسل: <strong>${item.from_pharmacy_name}</strong></span>
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 0.9rem;">
                <thead>
                    <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-muted); text-align: right;">
                        <th style="padding: 8px;">الصنف والتشغيلة</th>
                        <th style="padding: 8px; text-align: center;">المرسل</th>
                        <th style="padding: 8px; text-align: center;">المقبول السليم</th>
                        <th style="padding: 8px; text-align: center;">تالف / مرفوض</th>
                        <th style="padding: 8px; text-align: center;">ناقص / عجز</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="padding: 8px;">
                            <strong>${item.drug_name}</strong>
                            <div style="font-size: 0.78rem; color: #94a3b8;">تشغيلة: <code>${item.batch_number}</code> | انتهاء: ${item.expiry_date}</div>
                        </td>
                        <td style="padding: 8px; text-align: center; font-weight: 700; color: #38bdf8;" id="sentQtyDisplay">
                            ${item.quantity} باكت
                        </td>
                        <td style="padding: 8px; text-align: center;">
                            <input type="number" id="recAcceptedQty" class="form-control" style="width: 80px; text-align: center; display: inline-block; font-weight: 700; color: #10b981;" value="${item.quantity}" min="0" max="${item.quantity}" oninput="onReceiptQtyChange(${item.quantity})">
                        </td>
                        <td style="padding: 8px; text-align: center;">
                            <input type="number" id="recRejectedQty" class="form-control" style="width: 80px; text-align: center; display: inline-block; font-weight: 700; color: #f43f5e;" value="0" min="0" max="${item.quantity}" oninput="onReceiptQtyChange(${item.quantity})">
                        </td>
                        <td style="padding: 8px; text-align: center;">
                            <input type="number" id="recMissingQty" class="form-control" style="width: 80px; text-align: center; display: inline-block; font-weight: 700; color: #fbbf24;" value="0" min="0" max="${item.quantity}" oninput="onReceiptQtyChange(${item.quantity})">
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    `;

    onReceiptQtyChange(item.quantity);
    openModal("receiveTransferModal");
}

function onReceiptQtyChange(sentTotal) {
    const acc = parseInt(document.getElementById("recAcceptedQty")?.value || 0, 10);
    const rej = parseInt(document.getElementById("recRejectedQty")?.value || 0, 10);
    const mis = parseInt(document.getElementById("recMissingQty")?.value || 0, 10);
    const sum = acc + rej + mis;

    const ind = document.getElementById("receiptBalanceIndicator");
    const discSection = document.getElementById("receiptDiscrepancySection");
    const groupRej = document.getElementById("groupRejectReason");
    const groupMis = document.getElementById("groupMissingReason");
    const btnConfirm = document.getElementById("btnConfirmReceipt");

    if (rej > 0 || mis > 0) {
        if (discSection) discSection.style.display = "block";
        if (groupRej) groupRej.style.display = rej > 0 ? "block" : "none";
        if (groupMis) groupMis.style.display = mis > 0 ? "block" : "none";
    } else {
        if (discSection) discSection.style.display = "none";
    }

    if (sum === sentTotal) {
        if (ind) {
            ind.innerHTML = `<span style="color: #10b981;"><i class="fa-solid fa-check-circle"></i> الكميات متوازنة تماماً (الإجمالي: ${sum} = المرسل ${sentTotal})</span>`;
        }
        if (btnConfirm) btnConfirm.disabled = false;
    } else {
        if (ind) {
            ind.innerHTML = `<span style="color: #f43f5e;"><i class="fa-solid fa-circle-xmark"></i> خطأ في التوازن: مجموع الفحص (${sum}) لا يساوي المرسل (${sentTotal})</span>`;
        }
        if (btnConfirm) btnConfirm.disabled = true;
    }
}

async function confirmReceiveTransfer() {
    if (!activeReceiveTransferId) return;
    const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === activeReceiveTransferId);
    if (!item) return;

    const acc = parseInt(document.getElementById("recAcceptedQty")?.value || 0, 10);
    const rej = parseInt(document.getElementById("recRejectedQty")?.value || 0, 10);
    const mis = parseInt(document.getElementById("recMissingQty")?.value || 0, 10);

    if (acc + rej + mis !== item.quantity) {
        showToast("خطأ: يجب أن يتطابق مجموع المقبول والمرفوض والناقص مع الكمية المرسلة!", "error");
        return;
    }

    const lineItemId = item.items && item.items[0] ? item.items[0].id : `ITEM-${item.id}-1`;
    const rejectReason = document.getElementById("recRejectReasonSelect")?.value || "";
    const missingReason = document.getElementById("recMissingReasonSelect")?.value || "";
    const notes = document.getElementById("recDiscrepancyNotes")?.value || "";

    try {
        const context = getSecurityContext();
        const res = await TransferService.receiveTransfer(context, {
            transferId: activeReceiveTransferId,
            receiptLines: [
                {
                    itemId: lineItemId,
                    accepted: acc,
                    rejected: rej,
                    missing: mis,
                    rejectReason,
                    missingReason,
                    notes
                }
            ],
            idempotencyKey: `RECEIVE-${activeReceiveTransferId}-${Date.now()}`
        });

        // Update local object
        item.status = res.transfer.status;
        item.step = 4;
        item.received_by = context.userId;
        item.received_at = new Date().toLocaleString('ar-YE');

        // Add accepted quantity to receiver's inventory
        if (acc > 0) {
            const destListing = MOCK_LISTINGS.find(l => l.brand_name === item.drug_name && l.pharmacy_id === item.to_pharmacy_id);
            if (destListing) {
                destListing.quantity += acc;
                destListing.physical_quantity = (destListing.physical_quantity || 0) + acc;
            } else {
                MOCK_LISTINGS.unshift({
                    id: `lst_tr_${Date.now()}`,
                    brand_name: item.drug_name,
                    active_ingredient: item.active_ingredient,
                    manufacturer: "شركة معتمدة",
                    batch_number: item.batch_number,
                    quantity: acc,
                    physical_quantity: acc,
                    quarantine_quantity: rej,
                    expiry_date: item.expiry_date,
                    days_left: item.days_left || 70,
                    urgency: "moderate",
                    original_price: Math.round((item.estimated_value || 3000) / (item.quantity || 1)),
                    discount_percent: 35,
                    clearance_price: Math.round(((item.estimated_value || 3000) / (item.quantity || 1)) * 0.65),
                    pharmacy_id: item.to_pharmacy_id,
                    status: "draft",
                    clearance_requested: false,
                    is_published: false
                });
            }
        }

        closeModal("receiveTransferModal");
        renderAgencyTransfers();
        renderMyListingsTable();
        renderMarketplace();
        updateNavbarAndUI();

        if (res.hasDiscrepancy) {
            showToast(`⚠️ تم تأكيد الاستلام وتسجيل (${acc} باكت مقبول)، وحجر (${rej} باكت تالف)، وفتح ملف تحقيق بالناقص (${mis} باكت).`, "warning");
        } else {
            showToast(`🎉 تم تأكيد استلام الشحنة مطابقة 100% وإغلاق المناقلة بنجاح!`, "success");
        }
    } catch (err) {
        showToast(`❌ خطأ أثناء الاستلام: ${err.message}`, "error");
    }
}

// -----------------------------------------------------------------------------
// مستند المناقلة المعتمد: «سند مناقلة داخلية — PharmaLink»
// -----------------------------------------------------------------------------

function openTransferVoucherModal(transferId) {
    const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === transferId);
    if (!item) return;

    const printArea = document.getElementById("transferVoucherPrintArea");
    if (!printArea) return;

    const unitPrice = Math.round((item.estimated_value || 0) / (item.quantity || 1));
    const transferCode = item.transfer_code || ('PL-TRF-2026-' + item.id);

    let statusDisplay = "مسودة";
    if (t_status_is_approved(item.status)) statusDisplay = "معتمد ومحجوز داخل PharmaLink";
    if (item.status === "in_transit") statusDisplay = "تم الإرسال — بانتظار الاستلام";
    if (item.status === "needs_discrepancy_resolution") statusDisplay = "مستلم جزئياً مع اختلاف قيد المعالجة";
    if (item.status === "completed") statusDisplay = "مكتمل ومطابق رسمياً";

    printArea.innerHTML = `
        <div class="official-voucher-document">
            <div class="doc-header">
                <div class="doc-logo-side">
                    <div class="doc-company-title" style="color: #0284c7; font-size: 1.3rem; font-weight: 800;">سند مناقلة داخلية — PharmaLink</div>
                    <div class="doc-company-sub" style="font-weight: 700; color: #1e293b;">مجموعة صيدليات الشفاء التخصصية (سلسلة صيدلانية معتمدة)</div>
                    <div style="font-size: 0.8rem; color: #64748b; margin-top: 2px;">نظام إدارة ومناقلات المخزون الدوائي الموحد | منصة فارما لينك B2B</div>
                </div>
                <div class="doc-barcode-side">
                    <div class="barcode-graphic" style="letter-spacing: 3px; font-family: monospace;">|||||| |||| |||||||| ||||| |||||||</div>
                    <div class="barcode-number" style="font-weight: 800; font-size: 0.95rem; color: #0f172a;">${transferCode}</div>
                    <div style="font-size: 0.78rem; color: #475569; margin-top: 4px;">رقم المعاملة: <strong>${item.id}</strong></div>
                </div>
            </div>

            <div class="doc-title-bar" style="background: #0f172a; color: #fff; padding: 8px 14px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center; margin: 15px 0;">
                <span style="font-weight: 700;">سند مناقلة داخلية رسمية بين الفروع (PharmaLink Internal Transfer)</span>
                <span class="doc-status-stamp" style="background: #0284c7; color: #fff; padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 700;">${statusDisplay}</span>
            </div>

            <div class="doc-info-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; background: #f8fafc; padding: 12px; border-radius: 6px; border: 1px solid #e2e8f0; font-size: 0.88rem;">
                <div class="doc-info-cell">
                    <span class="doc-label" style="color: #64748b;">تاريخ وتوقيت الإصدار:</span>
                    <span class="doc-val" style="font-weight: 700;">${item.created_at}</span>
                </div>
                <div class="doc-info-cell">
                    <span class="doc-label" style="color: #64748b;">سياسة الاعتماد المطبقة:</span>
                    <span class="doc-val" style="font-weight: 700;">${item.policy_applied === 'centralized' ? 'اعتماد مركزي من الإدارة' : 'تفويض الفروع المباشر'}</span>
                </div>
                <div class="doc-info-cell">
                    <span class="doc-label" style="color: #64748b;">الفرع المرسل (المحول منه):</span>
                    <span class="doc-val"><strong>${item.from_pharmacy_name}</strong> (${item.from_pharmacist})</span>
                </div>
                <div class="doc-info-cell">
                    <span class="doc-label" style="color: #64748b;">الفرع المستلم (المحول إليه):</span>
                    <span class="doc-val"><strong>${item.to_pharmacy_name}</strong> (${item.to_pharmacist})</span>
                </div>
                <div class="doc-info-cell">
                    <span class="doc-label" style="color: #64748b;">ترتيبات النقل:</span>
                    <span class="doc-val" style="color: #475569;">يُرتّب النقل بين الفرعين خارج المنصة</span>
                </div>
                <div class="doc-info-cell">
                    <span class="doc-label" style="color: #64748b;">اشتراطات التخزين:</span>
                    <span class="doc-val">${item.cooling_required ? '⚠️ يحفظ مبرداً (2-8 درجات مئوية)' : 'حفظ بدرجة حرارة الغرفة دون 25° مئوية'}</span>
                </div>
            </div>

            <table class="doc-items-table" style="width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 0.88rem;">
                <thead>
                    <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1; text-align: right;">
                        <th style="padding: 8px;">م</th>
                        <th style="padding: 8px;">الصنف التجاري والعلمي</th>
                        <th style="padding: 8px;">رقم التشغيلة</th>
                        <th style="padding: 8px;">الصلاحية</th>
                        <th style="padding: 8px;">الوحدة</th>
                        <th style="padding: 8px;">الكمية</th>
                        <th style="padding: 8px;">سعر التكلفة</th>
                        <th style="padding: 8px;">الإجمالي</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid #e2e8f0;">
                        <td style="padding: 8px;">1</td>
                        <td style="padding: 8px;">
                            <strong>${item.drug_name}</strong>
                            <div style="font-size: 0.78rem; color: #64748b;">${item.active_ingredient}</div>
                        </td>
                        <td style="padding: 8px;"><code>${item.batch_number}</code></td>
                        <td style="padding: 8px;"><strong>${item.expiry_date}</strong></td>
                        <td style="padding: 8px;">باكت</td>
                        <td style="padding: 8px;"><strong style="color: #0284c7; font-size: 1.05rem;">${item.quantity}</strong></td>
                        <td style="padding: 8px;">${unitPrice.toLocaleString()} ر.ي</td>
                        <td style="padding: 8px;"><strong>${(item.estimated_value || 0).toLocaleString()} ر.ي</strong></td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr style="background: #f8fafc; border-top: 2px solid #cbd5e1;">
                        <td colspan="5" style="padding: 8px; font-weight: 700;">عمولة المنصة (فارما لينك):</td>
                        <td colspan="3" style="padding: 8px; color: #10b981; font-weight: 800;">0.00 ر.ي (مناقلة داخلية معفاة من العمولات)</td>
                    </tr>
                </tfoot>
            </table>

            <div class="doc-notes-box" style="margin-top: 15px; padding: 10px; background: #fffbeb; border: 1px solid #fde68a; border-radius: 6px; font-size: 0.85rem;">
                <strong>مبرر العملية والتعليمات:</strong> ${item.reason} ${item.dispatch_notes || item.notes ? `| ${item.dispatch_notes || item.notes}` : ''}
            </div>

            <div class="doc-signatures-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 20px; text-align: center; font-size: 0.82rem;">
                <div class="sig-box" style="border: 1px dashed #cbd5e1; padding: 10px; border-radius: 6px;">
                    <div style="font-weight: 700; color: #475569;">الفرع المرسل (تأكيد الإرسال)</div>
                    <div style="margin: 6px 0;">${item.from_pharmacist}</div>
                    <div style="color: #0284c7; font-size: 0.75rem;">${item.dispatched_at ? `إرسال: ${item.dispatched_at}` : (item.sender_approved_at ? `تخصيص: ${item.sender_approved_at}` : '[ بانتظار الإرسال ]')}</div>
                </div>
                <div class="sig-box" style="border: 1px dashed #cbd5e1; padding: 10px; border-radius: 6px;">
                    <div style="font-weight: 700; color: #475569;">الإدارة العامة للسلسلة</div>
                    <div style="margin: 6px 0;">د. عبدالكريم طاهر</div>
                    <div style="color: #10b981; font-size: 0.75rem;">${item.management_approved_at ? `معتمد: ${item.management_approved_at}` : (item.policy_applied === 'centralized' ? '[ بانتظار الإدارة ]' : '[ مفوض للفروع ]')}</div>
                </div>
                <div class="sig-box" style="border: 1px dashed #cbd5e1; padding: 10px; border-radius: 6px;">
                    <div style="font-weight: 700; color: #475569;">الفرع المستلم (تأكيد الاستلام)</div>
                    <div style="margin: 6px 0;">${item.to_pharmacist}</div>
                    <div style="color: #10b981; font-size: 0.75rem;">${item.received_at ? `استلام: ${item.received_at}` : '[ بانتظار الفحص الفعلي ]'}</div>
                </div>
            </div>

            <div class="doc-footer-statement" style="margin-top: 15px; font-size: 0.75rem; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 8px;">
                وثيقة مناقلة داخلية صادرة من نظام PharmaLink. يُرتّب النقل وتكاليفه بين الفرعين خارج المنصة. المناقلات بين الفروع معفاة تماماً من عمولة المنصة (0 ر.ي). يُضاف المرجع الخارجي عند التكامل المحاسبي الفعلي فقط.
            </div>
        </div>
    `;

    openModal("transferVoucherModal");
}

function t_status_is_approved(st) {
    return st === 'approved_and_reserved' || st === 'in_preparation' || st === 'in_transit' || st === 'completed' || st === 'needs_discrepancy_resolution';
}

function printTransferVoucher() {
    window.print();
}

function openDiscrepancyResolutionModal(transferId) {
    const item = MOCK_INTERNAL_TRANSFERS.find(t => t.id === transferId);
    if (!item) return;
    alert(`ملف تسوية الاختلاف للمناقلة (${item.transfer_code || item.id}):\nيوجد عجز/تلف مسجل في عهدة الحجر الصحي بالفرع المستلم.\nيمكن للإدارة المركزية اعتماد تسوية العجز المخزني أو إرجاع التالف للمرسل.`);
}


function printTransferVoucher() {
    window.print();
}

function openCreateDirectTransferModal() {
    const select = document.getElementById("directTransferDrugSelect");
    if (select) {
        select.innerHTML = MOCK_LISTINGS.map(l => {
            const branch = MOCK_PHARMACIES.find(p => p.id === l.pharmacy_id);
            const bName = branch ? branch.name : "الفرع";
            return `<option value="${l.id}" data-qty="${l.quantity}" data-branch="${l.pharmacy_id}" data-name="${l.brand_name}">${l.brand_name} - متوفر: ${l.quantity} باكت (${bName})</option>`;
        }).join("");

        if (MOCK_LISTINGS.length > 0) {
            onDirectTransferDrugSelect(MOCK_LISTINGS[0].id);
        }
    }

    const titleEl = document.getElementById("createTransferModalTitle");
    if (titleEl) {
        if (CURRENT_USER.role === "agency_master") {
            titleEl.innerHTML = `<i class="fa-solid fa-crown" style="color: #fbbf24;"></i> أمر مناقلة مركزية فورية (قرار الإدارة العامة)`;
        } else {
            titleEl.innerHTML = `<i class="fa-solid fa-paper-plane" style="color: #38bdf8;"></i> طلب مناقلة مخزنية جديدة للفرع`;
        }
    }

    openModal("createDirectTransferModal");
}

function onDirectTransferDrugSelect(listingId) {
    const item = MOCK_LISTINGS.find(l => l.id === listingId);
    if (!item) return;

    const qtyInput = document.getElementById("directTransferQty");
    const hint = document.getElementById("directTransferAvailableHint");
    const srcSelect = document.getElementById("directTransferSourceBranch");

    if (qtyInput) {
        qtyInput.value = Math.min(10, item.quantity);
        qtyInput.max = item.quantity;
    }
    if (hint) {
        hint.innerText = `الكمية المتوفرة بالفرع: ${item.quantity} باكت | التشغيلة: ${item.batch_number}`;
    }
    if (srcSelect && item.pharmacy_id) {
        srcSelect.value = item.pharmacy_id;
    }
}

function onDirectTransferSourceBranchChange() {
    const src = document.getElementById("directTransferSourceBranch")?.value;
    const tgt = document.getElementById("directTransferTargetBranch");
    if (tgt && tgt.value === src) {
        for (let i = 0; i < tgt.options.length; i++) {
            if (tgt.options[i].value !== src) {
                tgt.selectedIndex = i;
                break;
            }
        }
    }
}

async function submitDirectTransferOrder() {
    const drugSelect = document.getElementById("directTransferDrugSelect");
    const listingId = drugSelect ? drugSelect.value : null;
    const item = MOCK_LISTINGS.find(l => l.id === listingId);
    if (!item) {
        showToast("يرجى اختيار الصنف الدوائي", "warning");
        return;
    }

    const available = getCalculatedAvailableStock(item.id);
    const qty = parseInt(document.getElementById("directTransferQty")?.value) || 1;
    if (qty <= 0 || qty > available) {
        showToast(`الكمية المطلوبة (${qty}) غير متوفرة. الرصيد المتاح الحالي: (${available} باكت)`, "warning");
        return;
    }

    const srcBranchId = document.getElementById("directTransferSourceBranch")?.value || item.pharmacy_id;
    const tgtBranchId = document.getElementById("directTransferTargetBranch")?.value;

    if (srcBranchId === tgtBranchId) {
        showToast("لا يمكن أن يكون الفرع المانح هو نفسه الفرع المستلم!", "error");
        return;
    }

    const reason = document.getElementById("directTransferReasonSelect")?.value || "مناقلة داخلية لتغطية الاحتياج وتدوير المخزون";
    const notes = document.getElementById("directTransferDriverNotes")?.value || "";

    const srcBranch = MOCK_PHARMACIES.find(p => p.id === srcBranchId);
    const tgtBranch = MOCK_PHARMACIES.find(p => p.id === tgtBranchId);

    const isMaster = CURRENT_USER.role === "agency_master";
    const context = getSecurityContext();

    try {
        const res = await TransferService.createTransferRequest(context, {
            fromPharmacyId: srcBranchId,
            toPharmacyId: tgtBranchId,
            items: [{ inventoryItemId: item.id, quantity: qty }],
            reason,
            policyApplied: "centralized",
            idempotencyKey: `CREATE-DIRECT-${Date.now()}`
        });

        const newTransfer = res.transfer;
        newTransfer.from_pharmacy_name = srcBranch ? srcBranch.name : "الفرع المرسل";
        newTransfer.from_pharmacist = srcBranch ? srcBranch.pharmacist : "مسؤول الفرع";
        newTransfer.to_pharmacy_name = tgtBranch ? tgtBranch.name : "الفرع المستلم";
        newTransfer.to_pharmacist = tgtBranch ? tgtBranch.pharmacist : "مسؤول الفرع";
        newTransfer.drug_name = item.brand_name;
        newTransfer.active_ingredient = item.active_ingredient;
        newTransfer.batch_number = item.batch_number;
        newTransfer.expiry_date = item.expiry_date;
        newTransfer.quantity = qty;
        newTransfer.estimated_value = qty * (item.original_price || 3000);
        newTransfer.notes = notes;

        // If master creates it, it has management approval recorded
        if (isMaster) {
            newTransfer.management_approved_by = context.userId;
            newTransfer.management_approved_at = new Date().toLocaleString('ar-YE');
            newTransfer.status = "pending_counterpart_approval"; // Still needs sender acknowledgement
        }

        MOCK_INTERNAL_TRANSFERS.unshift(newTransfer);

        closeModal("createDirectTransferModal");
        renderAgencyTransfers();
        renderMyListingsTable();
        renderMarketplace();
        updateNavbarAndUI();

        if (isMaster) {
            showToast(`👑 [أمر إداري]: تم إصدار أمر المناقلة (${newTransfer.transfer_code})؛ وبانتظار إقرار الفرع المرسل (${srcBranch.name}) بالتوفر قبل التجهيز.`, "success");
        } else {
            showToast(`📤 تم رفع طلب المناقلة (${newTransfer.transfer_code}) بنجاح. لا يُحجز المخزون إلا بعد موافقة الطرف وتخصيصه.`, "info");
        }
    } catch (err) {
        showToast(`❌ خطأ: ${err.message}`, "error");
    }
}


/**
 * 9. تسجيل الدخول وإنشاء الحساب
 */
function openLoginModal() {
    openModal("loginModal");
}

function openRegisterModal() {
    openModal("registerModal");
}

function handleLoginSubmit() {
    closeModal("loginModal");
    applyUserRole("independent");
    showToast("مرحباً بك يا دكتور! تم تسجيل الدخول لصيدليتك بنجاح.", "success");
}

function quickLoginAs(roleKey) {
    closeModal("loginModal");
    applyUserRole(roleKey);
    const names = {
        independent: "صيدلية الأمل الحديثة (مستقلة)",
        agency_branch: "صيدلية الشفاء - فرع حدة (فرع وكالة)",
        agency_master: "إدارة مجموعة الشفاء (مقر الوكالة)",
        admin: "مدير المنصة (Super Admin)"
    };
    showToast(`تم تسجيل الدخول السريع بنجاح كـ: ${names[roleKey]}`, "success");
}

function logoutUser() {
    applyUserRole("guest");
    showToast("تم تسجيل الخروج بنجاح. أهلاً بك في الصفحة العامة لترياق B2B.", "info");
}

function toggleRegAgencyFields() {
    // يمكن تخصيص حقول إضافية للوكالات
}

function handleLicenseFileChange(e) {
    const file = e.target.files[0];
    if (file) {
        document.getElementById("licenseFileName").innerHTML = `<i class="fa-solid fa-file-check" style="color: var(--primary-light);"></i> تم اختيار: ${file.name}`;
    }
}

function handleRegisterSubmit() {
    const name = document.getElementById("regPharmacyName").value;
    const pharmacist = document.getElementById("regPharmacistName").value;
    const city = document.getElementById("regCity").value;
    const district = document.getElementById("regDistrict").value;

    if (!name || !pharmacist) {
        alert("يرجى كتابة اسم الصيدلية واسم الصيدلي المسؤول");
        return;
    }

    closeModal("registerModal");

    MOCK_PENDING_LICENSES.unshift({
        id: `lic_req_${Date.now()}`,
        pharmacy_name: name,
        pharmacist: pharmacist,
        city: city,
        district: district,
        license_no: `LIC-${Math.floor(10000 + Math.random() * 90000)}`,
        created_at: "الآن",
        doc_type: "صورة ترخيص مزاولة مهنة",
        status: "pending"
    });

    applyUserRole("pending_user");
    showToast("✨ تم إرسال طلب تسجيل صيدليتك ووثيقة الترخيص بنجاح! حسابك الآن قيد مراجعة الإدارة.", "success");
}

/**
 * 10. تفاصيل الشراء بالضمان والمناقلات
 */
function openEscrowCheckoutModal(listingId) {
    const item = MOCK_LISTINGS.find(l => l.id === listingId);
    if (!item) return;

    selectedListingForDeal = item;
    const seller = MOCK_PHARMACIES.find(p => p.id === item.pharmacy_id);

    const summaryEl = document.getElementById("checkoutDealSummary");
    summaryEl.innerHTML = `
        <div style="background: rgba(0,0,0,0.3); padding: 14px; border-radius: 8px; margin-bottom: 14px;">
            <div style="font-weight: 700; font-size: 1.1rem; color: #fff;">${item.brand_name}</div>
            <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 8px;">المادة الفعالة: ${item.active_ingredient} | تشغيلة: ${item.batch_number}</div>
            <div style="display: flex; justify-content: space-between; font-size: 0.88rem;">
                <span>الصيدلية البائعة: <strong>${seller.name} (${seller.city} - ${seller.district})</strong></span>
                <span>السعر بعد الخصم: <strong style="color: var(--primary-light);">${item.clearance_price.toLocaleString()} ر.ي / باكت</strong></span>
            </div>
        </div>
    `;

    document.getElementById("orderQuantity").value = Math.min(10, item.quantity);
    document.getElementById("orderQuantity").max = item.quantity;
    recalcCheckoutTotal();

    openModal("escrowCheckoutModal");
}

function recalcCheckoutTotal() {
    if (!selectedListingForDeal) return;
    const qty = parseInt(document.getElementById("orderQuantity").value) || 1;
    const subtotal = qty * selectedListingForDeal.clearance_price;
    const fee = Math.round(subtotal * 0.015);
    const grandTotal = subtotal + fee;

    document.getElementById("checkoutSubtotal").innerText = `${subtotal.toLocaleString()} ر.ي`;
    document.getElementById("checkoutFee").innerText = `${fee.toLocaleString()} ر.ي`;
    document.getElementById("checkoutGrandTotal").innerText = `${grandTotal.toLocaleString()} ر.ي`;
}

function confirmEscrowOrder() {
    if (!selectedListingForDeal) return;
    const qty = parseInt(document.getElementById("orderQuantity").value) || 1;
    const subtotal = qty * selectedListingForDeal.clearance_price;
    const fee = Math.round(subtotal * 0.015);
    const total = subtotal + fee;
    const seller = MOCK_PHARMACIES.find(p => p.id === selectedListingForDeal.pharmacy_id);

    const newDeal = {
        id: `DEAL-${Math.floor(1000 + Math.random() * 9000)}`,
        drug_name: `${selectedListingForDeal.brand_name} (${qty} باكت)`,
        seller_pharmacy: seller.name,
        buyer_pharmacy: CURRENT_USER.profile.name,
        amount: subtotal,
        escrow_fee: fee,
        payment_method: "محفظة ترياق الداخلية (حجز ضمان)",
        status: "IN_ESCROW",
        status_text: "المبلغ محجوز بالضمان - بانتظار الشحن والتسليم",
        step: 2,
        created_at: "الآن"
    };

    MOCK_ESCROW_DEALS.unshift(newDeal);

    CURRENT_USER.profile.locked_balance = (CURRENT_USER.profile.locked_balance || 0) + total;
    if (CURRENT_USER.profile.available_balance >= total) {
        CURRENT_USER.profile.available_balance -= total;
    }

    closeModal("escrowCheckoutModal");
    updateNavbarAndUI();
    renderEscrowDeals();
    showToast(`تم حجز مبلغ (${total.toLocaleString()} ر.ي) في حساب الضمان بأمان! وتم إشعار البائع لتجهيز الشحنة.`, "success");
    switchTab("escrow");
}

// ==========================================
// إدارة القائمة المنبثقة لإجراءات الصنف والتكافل للفرع
// ==========================================
// ==========================================
// إدارة القائمة المنبثقة لإجراءات الصنف الموحدة المنظمة (5 تبويبات تخصصية)
// ==========================================
let selectedBranchModalListing = null;
let currentBranchModalTab = "SURPLUS";

function openBranchItemActionModal(listingId) {
    const item = MOCK_LISTINGS.find(l => l.id === listingId);
    if (!item) {
        showToast("لم يتم العثور على الصنف في المخزون", "error");
        return;
    }

    selectedBranchModalListing = item;
    const physicalStock = (typeof item.physical_quantity !== 'undefined') ? item.physical_quantity : item.quantity;
    const activeReserved = (typeof MOCK_INVENTORY_RESERVATIONS !== 'undefined' ? MOCK_INVENTORY_RESERVATIONS : [])
        .filter(r => r.inventory_item_id === item.id && r.status === 'active')
        .reduce((sum, r) => sum + r.reserved_quantity, 0);
    const availableStock = Math.max(0, physicalStock - activeReserved);

    // 1. بناء كرت تفاصيل الدواء المختار والأرصدة والأهلية في رأس النافذة
    const infoCard = document.getElementById("branchModalDrugInfoCard");
    if (infoCard) {
        const { diffDays, label } = calcDaysLeftAndLabel(item.expiry_date);
        const daysColor = (diffDays <= 60) ? "#f87171" : (diffDays <= 90 ? "#fbbf24" : "#34d399");

        let eligibilityNotice = "";
        if (availableStock === 0) {
            eligibilityNotice = `
                <div style="background: rgba(248, 113, 113, 0.12); border: 1px solid rgba(248, 113, 113, 0.35); border-radius: 6px; padding: 6px 12px; margin-top: 10px; font-size: 0.8rem; color: #fca5a5;">
                    <i class="fa-solid fa-ban"></i> <strong>تنبيه الأهلية:</strong> الرصيد المتاح حالياً 0 (الكمية محجوزة بالكامل لعمليات جارية). لا يمكن تخصيص أي كميات إضافية.
                </div>
            `;
        } else if (diffDays <= 0) {
            eligibilityNotice = `
                <div style="background: rgba(248, 113, 113, 0.12); border: 1px solid rgba(248, 113, 113, 0.35); border-radius: 6px; padding: 6px 12px; margin-top: 10px; font-size: 0.8rem; color: #fca5a5;">
                    <i class="fa-solid fa-triangle-exclamation"></i> <strong>صنف منتهي الصلاحية:</strong> لا يُسمح بتداوله أو مناقلته، متاح فقط لطلب تسوية إتلاف رسمي.
                </div>
            `;
        }

        infoCard.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 10px; margin-bottom: 12px;">
                <div>
                    <h3 style="margin: 0; color: #fff; font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                        <i class="fa-solid fa-pills" style="color: #38bdf8;"></i> ${item.brand_name}
                    </h3>
                    <div style="font-size: 0.84rem; color: #94a3b8; margin-top: 3px;">
                        المادة الفعالة: <strong style="color: #cbd5e1;">${item.active_ingredient || "غير محدد"}</strong>
                        ${item.strength ? ` • <span style="color: #38bdf8;">${item.strength}</span>` : ''}
                        ${item.form ? ` • <span>${item.form}</span>` : ''}
                        ${item.package_size ? ` • <span>(${item.package_size})</span>` : ''}
                    </div>
                </div>
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <span style="background: rgba(56, 189, 248, 0.12); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 4px 10px; border-radius: 8px; font-size: 0.8rem; font-weight: 700;">
                        الموجود: ${physicalStock} ${item.unit || 'باكت'}
                    </span>
                    <span style="background: rgba(248, 113, 113, 0.12); color: #f87171; border: 1px solid rgba(248, 113, 113, 0.3); padding: 4px 10px; border-radius: 8px; font-size: 0.8rem; font-weight: 700;">
                        المحجوز: ${activeReserved} ${item.unit || 'باكت'}
                    </span>
                    <span style="background: rgba(52, 211, 153, 0.15); color: #34d399; border: 1px solid rgba(52, 211, 153, 0.35); padding: 4px 10px; border-radius: 8px; font-size: 0.8rem; font-weight: 800;">
                        المتاح: ${availableStock} ${item.unit || 'باكت'}
                    </span>
                </div>
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; background: rgba(0, 0, 0, 0.3); padding: 10px 14px; border-radius: var(--radius-sm); border: 1px dashed rgba(255, 255, 255, 0.12); font-size: 0.82rem;">
                <div>
                    <span style="color: #64748b; display: block; font-size: 0.74rem;">رقم التشغيلة (Batch):</span>
                    <code style="color: #f1f5f9; font-weight: 700;">${item.batch_number}</code>
                </div>
                <div>
                    <span style="color: #64748b; display: block; font-size: 0.74rem;">تاريخ الانتهاء:</span>
                    <strong style="color: #f1f5f9;">${item.expiry_date}</strong>
                </div>
                <div>
                    <span style="color: #64748b; display: block; font-size: 0.74rem;">المهلة المتبقية:</span>
                    <strong style="color: ${daysColor};">${label}</strong>
                </div>
                <div>
                    <span style="color: #64748b; display: block; font-size: 0.74rem;">سعر التكلفة المرجعي:</span>
                    <strong style="color: #38bdf8;">${item.original_price ? item.original_price.toLocaleString() + ' ر.ي' : 'غير محدد'}</strong>
                </div>
            </div>
            ${eligibilityNotice}
        `;
    }

    // تعبئة بيانات تبويب 1: الفائض الداخلي
    setupSurplusTab(item, availableStock);

    // تعبئة بيانات تبويب 2: المناقلة المباشرة
    setupTransferTab(item, availableStock);

    // تعبئة بيانات تبويب 3: البيع الخارجي
    setupExternalSaleTab(item, availableStock);

    // تعبئة بيانات تبويب 4: سجل الحركة
    renderItemMovementLedger(item.id);

    // تعبئة بيانات تبويب 5: التسوية المخزنية
    setupAdjustmentTab(item, physicalStock);

    // فتح تبويب الفائض افتراضياً
    switchBranchModalTab("SURPLUS");

    openModal("branchItemActionModal");
}

function switchBranchModalTab(tabKey) {
    currentBranchModalTab = tabKey;
    const tabs = ["SURPLUS", "TRANSFER", "EXTERNAL_SALE", "LEDGER", "ADJUSTMENT"];
    tabs.forEach(t => {
        const btn = document.getElementById("btnTabAction-" + t);
        const pane = document.getElementById("paneAction-" + t);
        if (btn) btn.classList.toggle("active", t === tabKey);
        if (pane) pane.classList.toggle("active", t === tabKey);
    });
}

function setupSurplusTab(item, availableStock) {
    const surplusNotice = document.getElementById("surplusStatusNotice");
    const qtyInput = document.getElementById("surplusModalQty");
    const hintQty = document.getElementById("hintSurplusQty");
    const submitBtn = document.getElementById("btnSubmitSurplusAction");

    const activePost = (typeof MOCK_AGENCY_EXCHANGE_POSTS !== "undefined" ? MOCK_AGENCY_EXCHANGE_POSTS : [])
        .find(p => p.status === "OPEN" && p.type === "SURPLUS" && p.branch_id === item.pharmacy_id && (p.batch_number === item.batch_number || p.drug_name === item.brand_name));

    if (activePost) {
        if (surplusNotice) {
            surplusNotice.innerHTML = `
                <div style="background: rgba(251, 191, 36, 0.12); border: 1px solid rgba(251, 191, 36, 0.35); border-radius: 8px; padding: 10px 14px; font-size: 0.84rem; color: #fde68a; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                    <div>
                        <i class="fa-solid fa-bullhorn"></i> يوجد إعلان فائض نشط حالياً لهذا البند: <strong>${activePost.quantity} ${item.unit || 'باكت'}</strong> معروضة بساحة التكافل.
                    </div>
                    <button class="btn btn-sm btn-outline-warning" onclick="closeSurplusPost('${activePost.id}')" style="font-size: 0.78rem;">
                        <i class="fa-solid fa-xmark"></i> إغلاق الإعلان
                    </button>
                </div>
            `;
        }
        if (qtyInput) {
            qtyInput.value = activePost.quantity;
            qtyInput.max = availableStock;
        }
        if (submitBtn) {
            submitBtn.innerHTML = `<i class="fa-solid fa-pen-to-square"></i> تحديث كمية الفائض المعلن`;
        }
    } else {
        if (surplusNotice) surplusNotice.innerHTML = "";
        if (qtyInput) {
            qtyInput.value = availableStock > 0 ? Math.min(10, availableStock) : 0;
            qtyInput.max = availableStock;
        }
        if (submitBtn) {
            submitBtn.innerHTML = `<i class="fa-solid fa-box-open"></i> نشر فائض داخلي`;
        }
    }

    if (hintQty) {
        hintQty.innerText = `الحد الأقصى المتاح للتخصيص حالياً: ${availableStock} ${item.unit || 'باكت'}. (لا تتجاوز المتاح)`;
    }
}

function submitSurplusAction() {
    if (!selectedBranchModalListing) return;
    const item = selectedBranchModalListing;
    const physicalStock = (typeof item.physical_quantity !== 'undefined') ? item.physical_quantity : item.quantity;
    const activeReserved = (typeof MOCK_INVENTORY_RESERVATIONS !== 'undefined' ? MOCK_INVENTORY_RESERVATIONS : [])
        .filter(r => r.inventory_item_id === item.id && r.status === 'active')
        .reduce((sum, r) => sum + r.reserved_quantity, 0);
    const availableStock = Math.max(0, physicalStock - activeReserved);

    const qtyInput = document.getElementById("surplusModalQty");
    const qty = parseInt(qtyInput?.value || "0");
    if (isNaN(qty) || qty <= 0) {
        showToast("يرجى إدخال كمية صحيحة أكبر من صفر", "warning");
        return;
    }
    if (qty > availableStock) {
        showToast(`الكمية المطلوبة (${qty}) تتجاوز الرصيد المتاح للتخصيص (${availableStock})!`, "warning");
        return;
    }

    const durationHours = parseInt(document.getElementById("surplusModalDuration")?.value || "48");
    const notes = document.getElementById("surplusModalNotes")?.value.trim() || "";
    const branchName = CURRENT_USER?.profile?.name || "صيدلية الشفاء - فرع حدة";
    const branchId = CURRENT_USER?.profile?.id || item.pharmacy_id;

    // فحص ما إذا كان هناك إعلان نشط مسبقاً لتعديله (إعلان نشط واحد للبند)
    let existingPost = (typeof MOCK_AGENCY_EXCHANGE_POSTS !== "undefined" ? MOCK_AGENCY_EXCHANGE_POSTS : [])
        .find(p => p.status === "OPEN" && p.type === "SURPLUS" && p.branch_id === branchId && (p.batch_number === item.batch_number || p.drug_name === item.brand_name));

    const now = new Date();
    const expiresAt = new Date(now.getTime() + durationHours * 3600 * 1000);

    if (existingPost) {
        existingPost.quantity = qty;
        existingPost.reason = notes || existingPost.reason;
        existingPost.expires_at = expiresAt.toISOString();
        showToast(`تم تحديث كمية إعلان الفائض لصنف (${item.brand_name}) إلى ${qty} ${item.unit || 'باكت'}.`, "success");
    } else {
        const newPost = {
            id: "post_exch_" + Date.now(),
            type: "SURPLUS",
            branch_id: branchId,
            branch_name: branchName,
            drug_name: item.brand_name,
            active_ingredient: item.active_ingredient,
            batch_number: item.batch_number,
            quantity: qty,
            unit: item.unit || "باكت",
            expiry_date: item.expiry_date,
            original_price: item.original_price,
            urgency: "normal",
            reason: notes || `فائض راكد معروض للمناقلة والتكافل الداخلي لجميع فروع السلسلة.`,
            sla_hours: durationHours,
            created_at: now.toISOString(),
            expires_at: expiresAt.toISOString(),
            status: "OPEN",
            interested_branches: []
        };
        MOCK_AGENCY_EXCHANGE_POSTS.unshift(newPost);
        showToast(`🎉 تم نشر صنف (${item.brand_name}) بساحة التكافل الداخلي بنجاح (المخزون متاح ولم يُحجز لحين التخصيص).`, "success");
    }

    closeModal("branchItemActionModal");
    renderMyListingsTable();
    if (typeof renderAgencyExchangeBoard === "function") renderAgencyExchangeBoard();
}

function closeSurplusPost(postId) {
    const post = (typeof MOCK_AGENCY_EXCHANGE_POSTS !== "undefined" ? MOCK_AGENCY_EXCHANGE_POSTS : []).find(p => p.id === postId);
    if (!post) return;
    post.status = "CLOSED";
    showToast(`تم إغلاق إعلان الفائض لدواء (${post.drug_name}). لا يؤثر الإغلاق على أي مناقلات جارية.`, "info");
    closeModal("branchItemActionModal");
    renderMyListingsTable();
    if (typeof renderAgencyExchangeBoard === "function") renderAgencyExchangeBoard();
}

function setupTransferTab(item, availableStock) {
    const branchSelect = document.getElementById("transferModalTargetBranch");
    if (branchSelect) {
        const agencyId = CURRENT_USER?.profile?.agency_id || "agency_shifa";
        const sisterBranches = MOCK_PHARMACIES.filter(p => p.agency_id === agencyId && p.id !== item.pharmacy_id);
        if (sisterBranches.length > 0) {
            branchSelect.innerHTML = sisterBranches.map(b => `
                <option value="${b.id}">${b.name} (${b.district || b.city || ''})</option>
            `).join("");
        } else {
            branchSelect.innerHTML = `<option value="">لا توجد فروع شقيقة أخرى بالسلسلة</option>`;
        }
    }

    const qtyInput = document.getElementById("transferModalQty");
    const hintQty = document.getElementById("hintTransferQty");
    if (qtyInput) {
        qtyInput.value = availableStock > 0 ? Math.min(5, availableStock) : 0;
        qtyInput.max = availableStock;
    }
    if (hintQty) {
        hintQty.innerText = `الحد الأقصى المتاح للتخصيص حالياً: ${availableStock} ${item.unit || 'باكت'}.`;
    }

    updateTransferSummary();
}

function updateTransferSummary() {
    const summaryCard = document.getElementById("transferSummaryCard");
    if (!summaryCard || !selectedBranchModalListing) return;

    const item = selectedBranchModalListing;
    const branchSelect = document.getElementById("transferModalTargetBranch");
    const targetBranchName = branchSelect?.options[branchSelect.selectedIndex]?.text || "فرع شقيق";
    const qty = parseInt(document.getElementById("transferModalQty")?.value || "1");

    summaryCard.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
            <span><i class="fa-solid fa-arrow-right-arrow-left"></i> مسار المناقلة: <strong>فرعك (${CURRENT_USER?.profile?.name || 'حدة'})</strong> &larr; <strong>${targetBranchName}</strong></span>
            <span>الكمية: <strong style="color: #fff;">${qty} ${item.unit || 'باكت'}</strong></span>
            <span>التشغيلة: <code>${item.batch_number}</code></span>
        </div>
        <div style="font-size: 0.76rem; color: #6ee7b7; margin-top: 6px;">
            <i class="fa-solid fa-circle-check"></i> يتبع دورة العمل المعتمدة: يتم إنشاء طلب المناقلة وحجزه بالفرع دون خصم المخزون حتى تأكيد الإرسال الفعلي.
        </div>
    `;
}

async function submitDirectTransferAction() {
    if (!selectedBranchModalListing) return;
    const item = selectedBranchModalListing;
    const physicalStock = (typeof item.physical_quantity !== 'undefined') ? item.physical_quantity : item.quantity;
    const activeReserved = (typeof MOCK_INVENTORY_RESERVATIONS !== 'undefined' ? MOCK_INVENTORY_RESERVATIONS : [])
        .filter(r => r.inventory_item_id === item.id && r.status === 'active')
        .reduce((sum, r) => sum + r.reserved_quantity, 0);
    const availableStock = Math.max(0, physicalStock - activeReserved);

    const targetBranchSelect = document.getElementById("transferModalTargetBranch");
    const targetBranchId = targetBranchSelect?.value;
    if (!targetBranchId) {
        showToast("يرجى اختيار الفرع الشقيق المستلم للمناقلة", "warning");
        return;
    }

    const qty = parseInt(document.getElementById("transferModalQty")?.value || "0");
    if (isNaN(qty) || qty <= 0) {
        showToast("يرجى إدخال كمية صحيحة أكبر من صفر", "warning");
        return;
    }
    if (qty > availableStock) {
        showToast(`الكمية المراد مناقلتها (${qty}) تتجاوز الرصيد المتاح (${availableStock})!`, "warning");
        return;
    }

    const reason = document.getElementById("transferModalReason")?.value.trim() || "";
    const submitBtn = document.getElementById("btnSubmitTransferAction");
    if (submitBtn) submitBtn.disabled = true;

    try {
        if (typeof TransferService !== "undefined" && TransferService.createTransferRequest) {
            const context = {
                userId: CURRENT_USER?.profile?.id || "pharm_agency_01",
                role: CURRENT_USER?.role || "agency_branch",
                pharmacyId: CURRENT_USER?.profile?.id || item.pharmacy_id,
                chainId: CURRENT_USER?.profile?.agency_id || "agency_shifa"
            };
            const payload = {
                fromPharmacyId: item.pharmacy_id,
                toPharmacyId: targetBranchId,
                reason: reason || "مناقلة داخلية مباشرة لتغطية الاحتياج وتدوير المخزون",
                items: [
                    {
                        inventoryItemId: item.id,
                        quantity: qty,
                        quantityRequested: qty,
                        unitSnapshot: item.unit || "باكت"
                    }
                ]
            };

            const result = await TransferService.createTransferRequest(context, payload);

            closeModal("branchItemActionModal");
            showToast(`🚚 تم إنشاء طلب المناقلة رقم (${result.transfer.transfer_code}) بنجاح وإحالته للموافقة والتخصيص!`, "success");
        } else {
            // fallback إذا لم يكن TransferService متاحاً
            closeModal("branchItemActionModal");
            showToast("تم إنشاء طلب المناقلة بنجاح وفق دورة الموافقات.", "success");
        }

        renderMyListingsTable();
        if (typeof renderAgencyTransfers === "function") renderAgencyTransfers();
    } catch (err) {
        showToast("فشل إنشاء طلب المناقلة: " + err.message, "error");
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
}

function setupExternalSaleTab(item, availableStock) {
    const noticeEl = document.getElementById("externalSaleStatusNotice");
    const qtyInput = document.getElementById("externalSaleModalQty");
    const hintQty = document.getElementById("hintExternalSaleQty");
    const submitBtn = document.getElementById("btnSubmitExternalSaleAction");

    if (item.clearance_requested && !item.is_published) {
        if (noticeEl) {
            noticeEl.innerHTML = `
                <div style="background: rgba(248, 113, 113, 0.12); border: 1px solid rgba(248, 113, 113, 0.35); border-radius: 8px; padding: 10px 14px; font-size: 0.84rem; color: #fca5a5; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
                    <div>
                        <i class="fa-solid fa-clock"></i> تم رفع طلب بيع خارجي بانتظار تسعير الإدارة العامة للكمية: <strong>${item.clearance_request_qty || item.quantity} ${item.unit || 'باكت'}</strong>.
                    </div>
                    <button class="btn btn-sm btn-outline-danger" onclick="cancelClearanceRequest('${item.id}')" style="font-size: 0.78rem;">
                        <i class="fa-solid fa-rotate-left"></i> سحب طلب الاعتماد
                    </button>
                </div>
            `;
        }
        if (submitBtn) submitBtn.style.display = "none";
    } else {
        if (noticeEl) noticeEl.innerHTML = "";
        if (submitBtn) submitBtn.style.display = "inline-flex";
    }

    if (qtyInput) {
        qtyInput.value = availableStock > 0 ? Math.min(10, availableStock) : 0;
        qtyInput.max = availableStock;
    }
    if (hintQty) {
        hintQty.innerText = `الحد الأقصى المتاح للتخصيص حالياً: ${availableStock} ${item.unit || 'باكت'}. (لا يتم خصم أو حجز الكمية لمجرد الطلب)`;
    }
}

function submitExternalSaleAction() {
    if (!selectedBranchModalListing) return;
    const item = selectedBranchModalListing;
    const physicalStock = (typeof item.physical_quantity !== 'undefined') ? item.physical_quantity : item.quantity;
    const activeReserved = (typeof MOCK_INVENTORY_RESERVATIONS !== 'undefined' ? MOCK_INVENTORY_RESERVATIONS : [])
        .filter(r => r.inventory_item_id === item.id && r.status === 'active')
        .reduce((sum, r) => sum + r.reserved_quantity, 0);
    const availableStock = Math.max(0, physicalStock - activeReserved);

    const qty = parseInt(document.getElementById("externalSaleModalQty")?.value || "0");
    if (isNaN(qty) || qty <= 0) {
        showToast("يرجى إدخال كمية صحيحة أكبر من صفر", "warning");
        return;
    }
    if (qty > availableStock) {
        showToast(`الكمية المطلوبة (${qty}) تتجاوز الرصيد المتاح (${availableStock})!`, "warning");
        return;
    }

    const priority = document.getElementById("externalSalePriority")?.value || "NORMAL";
    const notes = document.getElementById("externalSaleNotes")?.value.trim() || "";

    item.clearance_requested = true;
    item.clearance_request_qty = qty;
    item.clearance_request_priority = priority;
    item.clearance_request_notes = notes;
    item.clearance_request_date = new Date().toISOString();

    closeModal("branchItemActionModal");
    showToast(`📤 تم إرسال طلب اعتماد البيع الخارجي لصنف (${item.brand_name}) للإدارة العامة بنجاح (بانتظار تحديد نسبة الخصم).`, "success");
    renderMyListingsTable();
}

function cancelClearanceRequest(itemId) {
    const item = MOCK_LISTINGS.find(x => x.id === itemId);
    if (!item) return;

    item.clearance_requested = false;
    delete item.clearance_request_qty;
    delete item.clearance_request_priority;
    delete item.clearance_request_notes;

    showToast(`تم سحب طلب البيع الخارجي لصنف (${item.brand_name}) وإعادته كمخزون محلي بالفرع.`, "info");
    closeModal("branchItemActionModal");
    renderMyListingsTable();
}

function renderItemMovementLedger(itemId) {
    const ledgerContainer = document.getElementById("branchModalLedgerContent");
    if (!ledgerContainer) return;

    const item = MOCK_LISTINGS.find(l => l.id === itemId);
    if (!item) return;

    const reservations = (typeof MOCK_INVENTORY_RESERVATIONS !== 'undefined' ? MOCK_INVENTORY_RESERVATIONS : [])
        .filter(r => r.inventory_item_id === itemId);

    const movements = (typeof MOCK_INVENTORY_MOVEMENTS !== 'undefined' ? MOCK_INVENTORY_MOVEMENTS : [])
        .filter(m => m.inventory_item_id === itemId);

    let rowsHtml = `
        <div style="background: rgba(15, 23, 42, 0.7); border: 1px solid var(--border-color); border-radius: 8px; padding: 12px 14px; margin-bottom: 12px;">
            <div style="font-weight: 700; color: #38bdf8; margin-bottom: 6px;"><i class="fa-solid fa-list-check"></i> سجل الحجوزات النشطة والسابقة</div>
            ${reservations.length > 0 ? reservations.map(r => `
                <div style="display: flex; justify-content: space-between; font-size: 0.8rem; padding: 6px 0; border-bottom: 1px dashed rgba(255,255,255,0.08);">
                    <span><i class="fa-solid fa-ticket"></i> حجز رقم: <strong>${r.id}</strong> (أمر: ${r.transfer_id || 'عام'})</span>
                    <span>الكمية: <strong>${r.reserved_quantity}</strong> ${item.unit || 'باكت'}</span>
                    <span>الحالة: <span class="badge ${r.status === 'active' ? 'badge-warning' : 'badge-safe'}">${r.status === 'active' ? 'نشط' : r.status}</span></span>
                </div>
            `).join("") : '<div style="color: var(--text-muted); font-size: 0.8rem;">لا توجد حجوزات مسجلة على هذه التشغيلة.</div>'}
        </div>

        <div style="background: rgba(15, 23, 42, 0.7); border: 1px solid var(--border-color); border-radius: 8px; padding: 12px 14px;">
            <div style="font-weight: 700; color: #34d399; margin-bottom: 6px;"><i class="fa-solid fa-dolly"></i> سجل الحركات المخزنية والتسويات</div>
            ${movements.length > 0 ? movements.map(m => `
                <div style="display: flex; justify-content: space-between; font-size: 0.8rem; padding: 6px 0; border-bottom: 1px dashed rgba(255,255,255,0.08);">
                    <span>${m.movement_type === 'IN' ? '➕ توريد / تسوية زائدة' : '➖ صرف / تسوية نقص'}: <strong>${m.quantity}</strong> ${item.unit || 'باكت'}</span>
                    <span>السبب: ${m.reason || 'عملية جرد'}</span>
                    <span style="color: #94a3b8;">${new Date(m.created_at).toLocaleDateString('ar-YE')}</span>
                </div>
            `).join("") : '<div style="color: var(--text-muted); font-size: 0.8rem;">لا توجد تسويات سابقة. الرصيد الأولي مطابق لجرد أونكس برو.</div>'}
        </div>
    `;

    ledgerContainer.innerHTML = rowsHtml;
}

function setupAdjustmentTab(item, physicalStock) {
    const qtyInput = document.getElementById("adjQuantity");
    if (qtyInput) {
        qtyInput.value = 1;
        qtyInput.max = physicalStock;
    }
}

function submitInventoryAdjustmentAction() {
    if (!selectedBranchModalListing) return;
    const item = selectedBranchModalListing;
    const adjType = document.getElementById("adjTypeSelect")?.value || "DAMAGE";
    const qty = parseInt(document.getElementById("adjQuantity")?.value || "1");
    const reason = document.getElementById("adjReason")?.value.trim() || "";

    if (isNaN(qty) || qty <= 0) {
        showToast("يرجى إدخال كمية صحيحة للتسوية", "warning");
        return;
    }

    if (typeof item.physical_quantity === "undefined") {
        item.physical_quantity = item.quantity;
    }

    if (adjType === "SURPLUS_FOUND") {
        item.physical_quantity += qty;
        item.quantity += qty;
    } else {
        if (qty > item.physical_quantity) {
            showToast(`الكمية المراد تسويتها (${qty}) أكبر من الرصيد الفعلي الموجود (${item.physical_quantity})!`, "warning");
            return;
        }
        item.physical_quantity -= qty;
        item.quantity = Math.max(0, item.quantity - qty);
    }

    if (typeof MOCK_INVENTORY_MOVEMENTS !== "undefined") {
        MOCK_INVENTORY_MOVEMENTS.unshift({
            id: "mov_" + Date.now(),
            inventory_item_id: item.id,
            movement_type: adjType === "SURPLUS_FOUND" ? "IN" : "OUT",
            quantity: qty,
            reason: reason || ("طلب تسوية: " + adjType),
            created_at: new Date().toISOString()
        });
    }

    closeModal("branchItemActionModal");
    showToast(`تم تسجيل طلب التسوية المخزنية للصنف (${item.brand_name}) وتوثيقها في سجل الحركات الدائم.`, "success");
    renderMyListingsTable();
}

// ==========================================
// نافذة طلب احتياج مستقل للفرع (Need Request)
// ==========================================
function openNeedRequestModal(prefillDrugName) {
    const nameInput = document.getElementById("needDrugName");
    const qtyInput = document.getElementById("needQuantity");
    const notesInput = document.getElementById("needNotes");

    if (nameInput) nameInput.value = prefillDrugName || "";
    if (qtyInput) qtyInput.value = 10;
    if (notesInput) notesInput.value = "";

    openModal("needRequestModal");
}

function submitNeedRequest() {
    const drugName = document.getElementById("needDrugName")?.value.trim();
    if (!drugName) {
        showToast("يرجى إدخال اسم الدواء المطلوب", "warning");
        return;
    }

    const qty = parseInt(document.getElementById("needQuantity")?.value || "1");
    if (isNaN(qty) || qty <= 0) {
        showToast("يرجى إدخال كمية صحيحة", "warning");
        return;
    }

    const activeIng = document.getElementById("needActiveIng")?.value.trim() || "";
    const unit = document.getElementById("needUnit")?.value || "باكت";
    const urgency = document.getElementById("needUrgency")?.value || "moderate";
    const notes = document.getElementById("needNotes")?.value.trim() || "";
    const branchName = CURRENT_USER?.profile?.name || "صيدلية الشفاء - فرع حدة";
    const branchId = CURRENT_USER?.profile?.id || "pharm_agency_01";

    const newNeedPost = {
        id: "post_exch_need_" + Date.now(),
        type: "SHORTAGE",
        branch_id: branchId,
        branch_name: branchName,
        drug_name: drugName,
        active_ingredient: activeIng,
        batch_number: "حسب المتوفر",
        quantity: qty,
        unit: unit,
        expiry_date: "صلاحية مريحة",
        original_price: 0,
        urgency: urgency,
        reason: notes || `نداء نقص واحتياج عاجل لتغطية طلبات الروشتات في ${branchName}.`,
        sla_hours: 48,
        created_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
        status: "OPEN",
        interested_branches: []
    };

    if (typeof MOCK_AGENCY_EXCHANGE_POSTS !== "undefined") {
        MOCK_AGENCY_EXCHANGE_POSTS.unshift(newNeedPost);
    }

    closeModal("needRequestModal");
    showToast(`📢 تم بث طلب الاحتياج لدواء (${drugName}) بالساحة الداخلية بنجاح دون إضافة أي مخزون وهمي.`, "success");
    if (typeof renderAgencyExchangeBoard === "function") renderAgencyExchangeBoard();
}

// ==========================================
// نافذة استيراد المخزون وفحص الفروق والتعليق
// ==========================================
function openImportInventoryModal() {
    const previewTbody = document.getElementById("importPreviewTbody");
    const alertEl = document.getElementById("importValidationAlert");
    if (!previewTbody) return;

    // عينة بنود استيراد للمعاينة
    const sampleImportItems = [
        { brand_name: "كلكسان Clexane 40mg", batch_number: "CX-88310", unit: "باكت", expiry_date: "2027-01-15", import_qty: 25, current_qty: 25, itemId: "lst_shifa_hadda_01" },
        { brand_name: "نيكسيوم Nexium 40mg", batch_number: "NX-77140", unit: "باكت", expiry_date: "2026-12-20", import_qty: 30, current_qty: 30, itemId: "lst_shifa_hadda_04" },
        { brand_name: "بانادول إكسترا Panadol Extra", batch_number: "PD-99210", unit: "باكت", expiry_date: "2027-03-20", import_qty: 45, current_qty: 45, itemId: "lst_shifa_hadda_03" },
        { brand_name: "فنتولين بخاخ Ventolin Inhaler", batch_number: "VT-10920", unit: "باكت", expiry_date: "2027-04-15", import_qty: 20, current_qty: 20, itemId: "lst_shifa_hadda_05" }
    ];

    let suspendedCount = 0;
    let validCount = 0;

    previewTbody.innerHTML = sampleImportItems.map(row => {
        // فحص ما إذا كان البند مرتبطاً بحجوزات نشطة
        const activeRes = (typeof MOCK_INVENTORY_RESERVATIONS !== "undefined" ? MOCK_INVENTORY_RESERVATIONS : [])
            .filter(r => r.inventory_item_id === row.itemId && r.status === "active")
            .reduce((sum, r) => sum + r.reserved_quantity, 0);

        let statusBadge = "";
        if (activeRes > 0) {
            suspendedCount++;
            statusBadge = `<span class="badge badge-warning" title="مرتبط بحجز مناقلة قائم (${activeRes} باكت)"><i class="fa-solid fa-triangle-exclamation"></i> معلق للمراجعة (حجز نشط: ${activeRes})</span>`;
        } else {
            validCount++;
            statusBadge = `<span class="badge badge-safe"><i class="fa-solid fa-check"></i> مطابق وسليم</span>`;
        }

        return `
            <tr>
                <td><strong>${row.brand_name}</strong></td>
                <td><code>${row.batch_number}</code></td>
                <td>${row.unit}</td>
                <td>${row.expiry_date}</td>
                <td><strong>${row.import_qty}</strong></td>
                <td>${row.current_qty}</td>
                <td>${statusBadge}</td>
            </tr>
        `;
    }).join("");

    if (alertEl) {
        alertEl.innerHTML = `
            <div style="background: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 8px; padding: 10px 14px; font-size: 0.84rem; color: #e2e8f0;">
                <i class="fa-solid fa-shield-check" style="color: #38bdf8;"></i> نتائج فحص كشف الاستيراد: 
                <strong>${validCount} بنود سليمة</strong>، و 
                <strong style="color: #fbbf24;">${suspendedCount} بند معلق للمراجعة</strong> لوجود حجوزات نشطة لحماية العمليات الجارية.
            </div>
        `;
    }

    openModal("importInventoryModal");
}

function confirmImportBatch() {
    const timeNow = new Date().toLocaleTimeString("ar-YE", { hour: "2-digit", minute: "2-digit" });
    const metaSync = document.getElementById("metaLastSyncTime");
    if (metaSync) metaSync.innerText = "اليوم " + timeNow;

    closeModal("importInventoryModal");
    showToast(`✅ تم اعتماد دفعة الاستيراد بنجاح! تم تحديث الأرصدة السليمة وتعليق البنود المرتبطة بحجوزات للمراجعة.`, "success");
    renderMyListingsTable();
}

function openPostToExchangeFromListing(listingId) {
    const item = MOCK_LISTINGS.find(l => l.id === listingId);
    if (!item) return;

    openCreateExchangePostModal('SURPLUS');

    const drugNameInput = document.getElementById("exchangeDrugName");
    const activeInput = document.getElementById("exchangeActiveIng");
    const qtyInput = document.getElementById("exchangeQuantity");
    const batchInput = document.getElementById("exchangeBatch");
    const expInput = document.getElementById("exchangeExpiry");
    const notesInput = document.getElementById("exchangeNotes");

    if (drugNameInput) drugNameInput.value = item.brand_name;
    if (activeInput) activeInput.value = item.active_ingredient;
    if (qtyInput) {
        qtyInput.value = item.quantity;
        qtyInput.max = item.quantity;
    }
    if (batchInput) batchInput.value = item.batch_number;
    if (expInput) expInput.value = item.expiry_date;
    if (notesInput) notesInput.value = `الصنف راكد في فرعنا (${CURRENT_USER.profile?.name || "فرع حدة"})، متاح للمناقلة الفورية لأي فرع شقيق يحتاجه مجاناً بنظام التكافل (0 ر.ي عمولة).`;
}

function openInternalTransferModal(listingId) {
    const item = MOCK_LISTINGS.find(l => l.id === listingId);
    if (!item) return;

    selectedListingForDeal = item;
    const isAgencyMaster = CURRENT_USER.role === "agency_master";
    const sourceBranch = MOCK_PHARMACIES.find(p => p.id === item.pharmacy_id);
    const sourceName = sourceBranch ? sourceBranch.name : (CURRENT_USER.profile ? CURRENT_USER.profile.name : "الفرع المانح");

    const modalTitle = document.getElementById("transferModalTitle");
    const confirmBtn = document.getElementById("btnConfirmTransfer");
    const detailsEl = document.getElementById("internalTransferDetails");

    // استخراج الفروع الشقيقة الأخرى لنفس الوكالة
    const agencyId = CURRENT_USER.profile ? (CURRENT_USER.profile.agency_id || "agency_shifa") : "agency_shifa";
    const otherBranches = MOCK_PHARMACIES.filter(p => p.agency_id === agencyId && p.id !== item.pharmacy_id);

    const optionsHtml = otherBranches.map(b => {
        return `<option value="${b.id}">${b.name} (${b.district})</option>`;
    }).join("");

    if (modalTitle) {
        modalTitle.innerHTML = isAgencyMaster
            ? `<i class="fa-solid fa-crown" style="color: #38bdf8;"></i> أمر مناقلة داخلية مركزية (بين فروع السلسلة)`
            : `<i class="fa-solid fa-shuffle" style="color: #38bdf8;"></i> طلب مناقلة مخزنية مباشرة لفرع شقيق`;
    }
    if (confirmBtn) {
        confirmBtn.innerHTML = isAgencyMaster
            ? `<i class="fa-solid fa-check-double"></i> اعتماد وإصدار أمر المناقلة (مجاناً 0 ر.ي)`
            : `<i class="fa-solid fa-paper-plane"></i> إرسال طلب المناقلة للفرع الشقيق`;
    }

    detailsEl.innerHTML = `
        <div style="background: rgba(0,0,0,0.3); padding: 14px; border-radius: 8px; font-size: 0.92rem; border-right: 4px solid var(--accent-blue); margin-bottom: 14px;">
            <div style="font-weight: 700; font-size: 1.1rem; color: #fff; margin-bottom: 4px;">${item.brand_name}</div>
            <div style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 8px;">
                المادة الفعالة: ${item.active_ingredient} | تشغيلة: <code>${item.batch_number}</code> | الصلاحية: ${item.expiry_date}
            </div>
            <div style="display: flex; gap: 8px; align-items: center; margin-top: 6px; flex-wrap: wrap;">
                <span class="badge-branch-tag"><i class="fa-solid fa-location-dot"></i> الفرع الحالي الحائز للصنف: <strong>${sourceName}</strong></span>
                <span style="font-size: 0.82rem; color: #fbbf24;">(المتوفر بالفرع: ${item.quantity} باكت)</span>
            </div>
        </div>

        <div class="form-group">
            <label style="font-weight: 700; color: #fff;"><i class="fa-solid fa-code-branch"></i> حدد الفرع الشقيق المستلم (المراد نقل الصنف إليه):</label>
            <select id="transferDestinationSelect" class="form-control" style="background: rgba(15, 23, 42, 0.85); border: 1px solid var(--border-color); color: #fff; font-weight: 600;">
                ${optionsHtml}
            </select>
            <small style="color: var(--text-muted); display: block; margin-top: 5px;">
                <i class="fa-solid fa-circle-check" style="color: var(--primary-light);"></i> مناقلة داخلية مجانية (0 ر.ي عمولة) تُرحل مباشرة في نظام أونكس برو ERP مع المندوب فؤاد السريحي.
            </small>
        </div>

        <div style="margin-top: 10px; padding: 10px; background: rgba(56, 189, 248, 0.08); border: 1px dashed rgba(56, 189, 248, 0.3); border-radius: 6px; font-size: 0.82rem; display: flex; justify-content: space-between; align-items: center;">
            <span><i class="fa-solid fa-bullhorn" style="color: #38bdf8;"></i> أو اعرضه لجميع الفروع معاً:</span>
            <button type="button" class="btn btn-sm btn-outline" onclick="closeModal('internalTransferModal'); openPostToExchangeFromListing('${item.id}');">
                نشر بساحة التكافل (48س)
            </button>
        </div>
    `;

    const qtyInput = document.getElementById("transferQuantity");
    if (qtyInput) {
        qtyInput.value = Math.min(10, item.quantity);
        qtyInput.max = item.quantity;
    }
    openModal("internalTransferModal");
}

function confirmInternalTransfer() {
    if (!selectedListingForDeal) return;
    const qty = parseInt(document.getElementById("transferQuantity").value) || 1;
    if (qty <= 0) {
        alert("يرجى تحديد كمية صحيحة للمناقلة");
        return;
    }
    if (qty > selectedListingForDeal.quantity) {
        alert("الكمية المطلوبة أكبر من المتوفر بالفرع (" + selectedListingForDeal.quantity + " باكت)");
        return;
    }

    const isMaster = CURRENT_USER.role === "agency_master";
    const destSelect = document.getElementById("transferDestinationSelect");

    let fromBranchId = selectedListingForDeal.pharmacy_id;
    let sBranch = MOCK_PHARMACIES.find(p => p.id === fromBranchId);
    let fromBranchName = sBranch ? sBranch.name : "الفرع المانح";
    let fromPharmacist = sBranch ? sBranch.pharmacist : "مسؤول الفرع";

    let toBranchId = destSelect ? destSelect.value : "pharm_agency_02";
    if (toBranchId === fromBranchId) {
        const agencyId = CURRENT_USER.profile?.agency_id || "agency_shifa";
        const alt = MOCK_PHARMACIES.find(p => p.agency_id === agencyId && p.id !== fromBranchId);
        if (alt) toBranchId = alt.id;
    }

    const dBranch = MOCK_PHARMACIES.find(p => p.id === toBranchId);
    let toBranchName = dBranch ? dBranch.name : "الفرع الشقيق المستلم";
    let toPharmacist = dBranch ? dBranch.pharmacist : "مسؤول الفرع المستلم";

    const reason = document.getElementById("transferReasonSelectModal")?.value || "مناقلة داخلية مجانية بين فروع الوكالة";
    const notes = document.getElementById("transferNotes")?.value || "يرجى تسليم الشحنة مع مندوب الحركة الميداني.";

    const transferId = `TR-${Math.floor(1000 + Math.random() * 9000)}`;
    const voucherNo = `TR-ONX-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newTransfer = {
        id: transferId,
        erp_voucher: voucherNo,
        drug_name: selectedListingForDeal.brand_name,
        active_ingredient: selectedListingForDeal.active_ingredient,
        batch_number: selectedListingForDeal.batch_number,
        expiry_date: selectedListingForDeal.expiry_date,
        days_left: selectedListingForDeal.days_left || 70,
        quantity: qty,
        estimated_value: qty * (selectedListingForDeal.original_price || 3000),
        from_branch_id: fromBranchId,
        from_branch_name: fromBranchName,
        from_pharmacist: fromPharmacist,
        to_branch_id: toBranchId,
        to_branch_name: toBranchName,
        to_pharmacist: toPharmacist,
        status: isMaster ? "IN_TRANSIT" : "PENDING_APPROVAL",
        step: isMaster ? 3 : 1,
        reason: reason,
        requested_by: isMaster ? "الإدارة العامة (أمر نقل إداري مباشر)" : `${CURRENT_USER.profile?.pharmacist || "الصيدلي"} (${CURRENT_USER.profile?.name || "الفرع"})`,
        created_at: "الآن",
        approved_at: isMaster ? "الآن (معتمد)" : null,
        completed_at: null,
        driver_name: "فؤاد السريحي (مندوب التوزيع)",
        driver_phone: "770123987",
        cooling_required: false,
        notes: notes
    };

    if (typeof MOCK_INTERNAL_TRANSFERS !== "undefined") {
        MOCK_INTERNAL_TRANSFERS.unshift(newTransfer);
    }

    selectedListingForDeal.quantity -= qty;
    if (selectedListingForDeal.quantity <= 0) {
        selectedListingForDeal.status = "transferred";
        selectedListingForDeal.is_published = false;
    }

    closeModal("internalTransferModal");
    renderMyListingsTable();
    renderMarketplace();
    renderAgencyTransfers();
    updateNavbarAndUI();

    if (isMaster) {
        showToast("🔄 [أمر إداري]: تم إصدار أمر المناقلة (" + voucherNo + ") ونقل (" + qty + " باكت) من " + selectedListingForDeal.brand_name + " إلى " + toBranchName + " مجاناً 0 ر.ي", "success");
    } else {
        showToast("📤 تم رفع طلب مناقلة (" + qty + " باكت) من " + selectedListingForDeal.brand_name + " للإدارة العامة للمصادقة وتوجيه المندوب!", "success");
    }
}

let selectedMasterClearanceItem = null;

function openMasterDiscountModal(itemId) {
    const item = MOCK_LISTINGS.find(x => x.id === itemId);
    if (!item) return;

    selectedMasterClearanceItem = item;
    const branch = MOCK_PHARMACIES.find(p => p.id === item.pharmacy_id);
    const branchName = branch ? branch.name : "الفرع";

    const nameEl = document.getElementById("masterModalDrugName");
    const badgeEl = document.getElementById("masterModalBranchBadge");
    const qtyEl = document.getElementById("masterModalQty");
    const expEl = document.getElementById("masterModalExp");
    const origEl = document.getElementById("masterModalOrigPrice");

    if (nameEl) nameEl.innerText = item.brand_name;
    if (badgeEl) badgeEl.innerHTML = "<i class=\"fa-solid fa-location-dot\"></i> " + branchName;
    if (qtyEl) qtyEl.innerText = item.quantity;
    if (expEl) expEl.innerText = item.expiry_date;
    if (origEl) origEl.innerText = item.original_price.toLocaleString();

    let defDiscount = item.discount_percent || 35;
    if (item.days_left <= 60 && defDiscount < 40) defDiscount = 45;
    const rangeEl = document.getElementById("masterDiscountRange");
    if (rangeEl) rangeEl.value = defDiscount;

    onMasterDiscountRangeChange(defDiscount);
    openModal("masterSetDiscountModal");
}

function onMasterDiscountRangeChange(val) {
    if (!selectedMasterClearanceItem) return;
    const p = parseInt(val) || 35;
    const disp = document.getElementById("masterModalPercentDisplay");
    if (disp) disp.innerText = p + "%";

    const finalP = Math.round(selectedMasterClearanceItem.original_price * (1 - p / 100));
    const totalCash = finalP * selectedMasterClearanceItem.quantity;

    const fpEl = document.getElementById("masterModalFinalPrice");
    const tcEl = document.getElementById("masterModalTotalCash");
    if (fpEl) fpEl.innerText = finalP.toLocaleString() + " ر.ي";
    if (tcEl) tcEl.innerText = totalCash.toLocaleString() + " ر.ي كاش";
}

function confirmMasterDiscountAndPublish() {
    if (!selectedMasterClearanceItem) return;
    const rangeEl = document.getElementById("masterDiscountRange");
    const p = rangeEl ? (parseInt(rangeEl.value) || 35) : 35;

    selectedMasterClearanceItem.discount_percent = p;
    selectedMasterClearanceItem.clearance_price = Math.round(selectedMasterClearanceItem.original_price * (1 - p / 100));
    selectedMasterClearanceItem.is_published = true;
    selectedMasterClearanceItem.status = "active";
    selectedMasterClearanceItem.clearance_requested = false;

    closeModal("masterSetDiscountModal");
    renderMyListingsTable();
    renderMarketplace();

    const branch = MOCK_PHARMACIES.find(x => x.id === selectedMasterClearanceItem.pharmacy_id);
    const bName = branch ? branch.name : "الفرع";
    showToast("👑 [قرار إداري معتمد]: تم اعتماد خصم " + p + "% وطرح صنف " + selectedMasterClearanceItem.brand_name + " للبورصة الدوائية باسم (" + bName + "). سعر البيع: " + selectedMasterClearanceItem.clearance_price.toLocaleString() + " ر.ي", "success");
}

function convertMasterClearanceToTransfer() {
    if (!selectedMasterClearanceItem) return;
    const itemId = selectedMasterClearanceItem.id;
    closeModal("masterSetDiscountModal");
    openInternalTransferModal(itemId);
}

function requestAgencyClearance(itemId) {
    const item = MOCK_LISTINGS.find(x => x.id === itemId);
    if (!item) return;

    item.clearance_requested = true;
    item.status = "pending_clearance";
    renderMyListingsTable();
    showToast("📤 تم إحالة صنف \"" + item.brand_name + "\" بنجاح للإدارة المركزية لمراجعة إمكانية المناقلة أو تحديد نسبة الخصم والتسعير.", "info");
}

function cancelClearanceRequest(itemId) {
    const item = MOCK_LISTINGS.find(x => x.id === itemId);
    if (!item) return;

    item.clearance_requested = false;
    item.status = "draft";
    renderMyListingsTable();
    showToast("↩️ تم إلغاء طلب طرح صنف \"" + item.brand_name + "\" بالبورصة، وعاد كمخزون محلي بالفرع.", "warning");
}


// ==========================================
// إدارة فلاتر المخزون الثلاثية المستقلة والبحث والمؤشرات التشغيلية
// ==========================================
let currentInventoryExternalFilter = "ALL"; // 'ALL', 'NOT_PUBLISHED', 'PENDING_APPROVAL', 'PUBLISHED'
let currentInventoryInternalFilter = "ALL"; // 'ALL', 'SURPLUS_POSTED', 'HAS_RESERVATION'
let currentInventoryExpiryFilter = "ALL";   // 'ALL', 'NEAR_EXPIRY', 'EXPIRED'
let currentInventorySearchQuery = "";
let currentBranchFilter = "all";

function setExternalFilter(status) {
    currentInventoryExternalFilter = status;
    ["ALL", "NOT_PUBLISHED", "PENDING_APPROVAL", "PUBLISHED"].forEach(s => {
        const btn = document.getElementById("f-ext-" + s);
        if (btn) btn.classList.toggle("active", s === status);
    });
    renderMyListingsTable();
}

function setInternalFilter(status) {
    currentInventoryInternalFilter = status;
    ["ALL", "SURPLUS_POSTED", "HAS_RESERVATION"].forEach(s => {
        const btn = document.getElementById("f-int-" + s);
        if (btn) btn.classList.toggle("active", s === status);
    });
    renderMyListingsTable();
}

function setExpiryFilter(status) {
    currentInventoryExpiryFilter = status;
    ["ALL", "NEAR_EXPIRY", "EXPIRED"].forEach(s => {
        const btn = document.getElementById("f-exp-" + s);
        if (btn) btn.classList.toggle("active", s === status);
    });
    renderMyListingsTable();
}

function onInventorySearchInput(val) {
    currentInventorySearchQuery = (val || "").trim().toLowerCase();
    renderMyListingsTable();
}

function clearAllInventoryFilters() {
    currentInventoryExternalFilter = "ALL";
    currentInventoryInternalFilter = "ALL";
    currentInventoryExpiryFilter = "ALL";
    currentInventorySearchQuery = "";

    const searchInput = document.getElementById("inventorySearchInput");
    if (searchInput) searchInput.value = "";

    ["ALL", "NOT_PUBLISHED", "PENDING_APPROVAL", "PUBLISHED"].forEach(s => {
        const btn = document.getElementById("f-ext-" + s);
        if (btn) btn.classList.toggle("active", s === "ALL");
    });
    ["ALL", "SURPLUS_POSTED", "HAS_RESERVATION"].forEach(s => {
        const btn = document.getElementById("f-int-" + s);
        if (btn) btn.classList.toggle("active", s === "ALL");
    });
    ["ALL", "NEAR_EXPIRY", "EXPIRED"].forEach(s => {
        const btn = document.getElementById("f-exp-" + s);
        if (btn) btn.classList.toggle("active", s === "ALL");
    });

    // إزالة تحديد كروت المؤشرات
    document.querySelectorAll(".branch-op-card").forEach(c => c.classList.remove("active-filter"));

    renderMyListingsTable();
    showToast("تم مسح كافة فلاتر البحث وعرض كامل مخزون الفرع.", "info");
}

function applyQuickFilter(type) {
    document.querySelectorAll(".branch-op-card").forEach(c => c.classList.remove("active-filter"));

    if (type === "near_expiry") {
        const card = document.getElementById("cardNearExpiry");
        if (card) card.classList.add("active-filter");
        setExpiryFilter("NEAR_EXPIRY");
    } else if (type === "pending_b2b") {
        const card = document.getElementById("cardPendingApprovalB2B");
        if (card) card.classList.add("active-filter");
        setExternalFilter("PENDING_APPROVAL");
    }
}

function setBranchFilter(branchId) {
    currentBranchFilter = branchId;
    document.querySelectorAll(".agency-branch-pills .branch-pill-btn").forEach(btn => btn.classList.remove("active"));
    const activeBtn = document.getElementById("branch-pill-" + branchId);
    if (activeBtn) activeBtn.classList.add("active");
    renderMyListingsTable();
}

function calcDaysLeftAndLabel(expiryDateString) {
    if (!expiryDateString) return { diffDays: 999, label: "غير محدد", badgeClass: "badge-safe" };
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const exp = new Date(expiryDateString);
    exp.setHours(0, 0, 0, 0);
    const diffDays = Math.ceil((exp - today) / (1000 * 60 * 60 * 24));

    let label = "";
    let badgeClass = "";
    if (diffDays <= 0) {
        label = `منتهي الصلاحية (${Math.abs(diffDays)} يوم مضت)`;
        badgeClass = "badge-danger";
    } else if (diffDays <= 90) {
        label = `باقي ${diffDays} يوماً (قريب الانتهاء)`;
        badgeClass = "badge-warning";
    } else {
        label = `باقي ${diffDays} يوماً (آمن)`;
        badgeClass = "badge-safe";
    }
    return { diffDays, label, badgeClass };
}

function toggleRowDetails(itemId, btn) {
    const row = document.getElementById("details-row-" + itemId);
    if (!row) return;
    const isHidden = (row.style.display === "none");
    row.style.display = isHidden ? "table-row" : "none";
    if (btn) {
        btn.classList.toggle("expanded", isHidden);
    }
}

function toggleExcelImportSection() {
    const section = document.getElementById("excelHeroSection");
    const icon = document.getElementById("excelToggleIcon");
    if (!section) return;
    const isHidden = (section.style.display === "none");
    section.style.display = isHidden ? "block" : "none";
    if (icon) {
        icon.innerHTML = isHidden ? '<i class="fa-solid fa-chevron-up" style="color: #38bdf8;"></i>' : '<i class="fa-solid fa-chevron-down" style="color: #38bdf8;"></i>';
    }
}

function toggleDashboardHelp() {
    const body = document.getElementById("dashboardHelpBody");
    const icon = document.getElementById("helpToggleIcon");
    if (!body) return;
    const isHidden = (body.style.display === "none" || !body.style.display);
    body.style.display = isHidden ? "block" : "none";
    if (icon) {
        icon.innerHTML = isHidden ? '<i class="fa-solid fa-chevron-up" style="color: #38bdf8;"></i>' : '<i class="fa-solid fa-chevron-down" style="color: #38bdf8;"></i>';
    }
}

function navigateToBranchTransfers(subview) {
    switchTab("branches");
    setTimeout(() => {
        if (typeof switchAgencySubView === "function") {
            switchAgencySubView(subview === "discrepancies" ? "transfers" : "transfers");
        }
    }, 150);
}

// ==========================================
// تحديث بطاقات المؤشرات التشغيلية الخمس للفرع
// ==========================================
function renderBranchOperationalCards(branchItems) {
    const grid = document.getElementById("branchOperationalGrid");
    const legacyGrid = document.getElementById("legacyStatsGrid");
    if (!grid) return;

    const isBranch = CURRENT_USER.role === "agency_branch";
    grid.style.display = isBranch ? "grid" : "none";
    if (legacyGrid) legacyGrid.style.display = isBranch ? "none" : "grid";

    if (!isBranch) return;

    const currentBranchId = CURRENT_USER?.profile?.id || "pharm_agency_01";

    // 1. بنود قريبة الانتهاء (<= 90 يوم)
    const nearExpiryCount = branchItems.filter(item => {
        const { diffDays } = calcDaysLeftAndLabel(item.expiry_date);
        return diffDays > 0 && diffDays <= 90;
    }).length;
    const elNear = document.getElementById("valOpNearExpiry");
    if (elNear) elNear.innerText = nearExpiryCount;

    // 2. طلبات بيع خارجي بانتظار الاعتماد
    const pendingB2BCount = branchItems.filter(item => item.clearance_requested && !item.is_published).length;
    const elPending = document.getElementById("valOpPendingB2B");
    if (elPending) elPending.innerText = pendingB2BCount;

    // 3. مناقلات بانتظار إجراء من الفرع (تخصيص أو تجهيز وتأكيد إرسال)
    const transfersActionCount = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined" ? MOCK_INTERNAL_TRANSFERS : [])
        .filter(t => (t.from_branch_id === currentBranchId || t.from_pharmacy_id === currentBranchId) &&
            (t.status === "pending_sender_approval" || t.status === "approved_and_reserved" || t.status === "PENDING_APPROVAL")).length;
    const elAction = document.getElementById("valOpTransfersAction");
    if (elAction) elAction.innerText = transfersActionCount;

    // 4. مناقلات مرسلة بانتظار الاستلام (واردة قيد التسليم)
    const inTransitCount = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined" ? MOCK_INTERNAL_TRANSFERS : [])
        .filter(t => (t.to_branch_id === currentBranchId || t.to_pharmacy_id === currentBranchId) &&
            (t.status === "in_transit" || t.status === "IN_TRANSIT")).length;
    const elTransit = document.getElementById("valOpTransfersInTransit");
    if (elTransit) elTransit.innerText = inTransitCount;

    // 5. اختلافات مفتوحة
    const discrepanciesCount = (typeof MOCK_TRANSFER_DISCREPANCIES !== "undefined" ? MOCK_TRANSFER_DISCREPANCIES : [])
        .filter(d => (d.to_branch_id === currentBranchId || d.from_branch_id === currentBranchId || d.to_pharmacy_id === currentBranchId || d.from_pharmacy_id === currentBranchId) &&
            d.status === "OPEN").length;
    const elDisc = document.getElementById("valOpDiscrepancies");
    if (elDisc) elDisc.innerText = discrepanciesCount;
}

// ==========================================
// تحديث التنبيهات الإجرائية الخاصة بفرع الوكالة
// ==========================================
function renderBranchActionableAlerts(branchItems) {
    const alertsContainer = document.getElementById("branchActionableAlerts");
    if (!alertsContainer) return;

    if (CURRENT_USER.role !== "agency_branch") {
        alertsContainer.style.display = "none";
        return;
    }

    const currentBranchId = CURRENT_USER?.profile?.id || "pharm_agency_01";
    const alerts = [];

    // تنبيه 1: مناقلات معتمدة ومحجوزة تحتاج تجهيزاً وتأكيد إرسال
    const readyToDispatch = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined" ? MOCK_INTERNAL_TRANSFERS : [])
        .filter(t => (t.from_branch_id === currentBranchId || t.from_pharmacy_id === currentBranchId) && t.status === "approved_and_reserved");
    if (readyToDispatch.length > 0) {
        alerts.push({
            type: "alert-warning",
            icon: "fa-solid fa-box-archive",
            title: `يوجد ${readyToDispatch.length} مناقلة معتمدة ومحجوزة بانتظار التجهيز وتأكيد الإرسال`,
            desc: `المخزون محجوز بالفعل. يرجى مراجعة البنود والتشغيلات وتأكيد إرسال الشحنة لخصم الرصيد رسمياً.`,
            actionText: "تجهيز وتأكيد الإرسال",
            actionClick: "navigateToBranchTransfers('action')"
        });
    }

    // تنبيه 2: مناقلة واردة مرسلة تحتاج تأكيد استلام
    const incomingInTransit = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined" ? MOCK_INTERNAL_TRANSFERS : [])
        .filter(t => (t.to_branch_id === currentBranchId || t.to_pharmacy_id === currentBranchId) && (t.status === "in_transit" || t.status === "IN_TRANSIT"));
    if (incomingInTransit.length > 0) {
        const first = incomingInTransit[0];
        alerts.push({
            type: "alert-info",
            icon: "fa-solid fa-truck-ramp-box",
            title: `شحنة مناقلة واردة لفرعك قيد النقل والتسليم (${first.drug_name || 'أدوية'})`,
            desc: `قادمة من (${first.from_pharmacy_name || first.from_branch_name || 'فرع شقيق'}). يتفق الفرعان على وسيلة النقل خارج المنصة، وبانتظار استلامك ومطابقة التشغيلات لضبط المخزون.`,
            actionText: "معاينة وتأكيد الاستلام",
            actionClick: "navigateToBranchTransfers('in_transit')"
        });
    }

    // تنبيه 3: طلب تخصيص مخزون يحتاج موافقة الفرع
    const pendingAllocations = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined" ? MOCK_INTERNAL_TRANSFERS : [])
        .filter(t => (t.from_branch_id === currentBranchId || t.from_pharmacy_id === currentBranchId) && (t.status === "pending_sender_approval" || t.status === "PENDING_APPROVAL"));
    if (pendingAllocations.length > 0) {
        alerts.push({
            type: "alert-purple",
            icon: "fa-solid fa-hand-holding-medical",
            title: `يوجد ${pendingAllocations.length} طلب تخصيص مخزون يحتاج موافقة مسؤول الفرع`,
            desc: `فرع شقيق يطلب مناقلة كميات من رصيدك. يرجى مراجعة الطلب والموافقة على التخصيص أو الاعتذار.`,
            actionText: "مراجعة وتخصيص المخزون",
            actionClick: "navigateToBranchTransfers('action')"
        });
    }

    // تنبيه 4: اختلاف مفتوح يحتاج معالجة
    const openDiscrepancies = (typeof MOCK_TRANSFER_DISCREPANCIES !== "undefined" ? MOCK_TRANSFER_DISCREPANCIES : [])
        .filter(d => (d.to_branch_id === currentBranchId || d.from_branch_id === currentBranchId || d.to_pharmacy_id === currentBranchId || d.from_pharmacy_id === currentBranchId) && d.status === "OPEN");
    if (openDiscrepancies.length > 0) {
        alerts.push({
            type: "alert-danger",
            icon: "fa-solid fa-triangle-exclamation",
            title: `يوجد ${openDiscrepancies.length} اختلاف تسوية مفتوح (نقص / تلف) قيد المعالجة`,
            desc: `مسجل اختلاف على تشغيلة (${openDiscrepancies[0].item_name || 'بند مخزني'})، يتطلب المتابعة مع الإدارة لحسم التسوية المخزنية.`,
            actionText: "متابعة الاختلافات",
            actionClick: "navigateToBranchTransfers('discrepancies')"
        });
    }

    // تنبيه 5: موعد مرتجع مورد مسجل يقترب (يعتمد على سياسة المورد المسجلة ومستقل عن الصلاحية)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const nearSupplierDeadlines = branchItems.filter(item => {
        if (!item.supplier_deadline) return false;
        const d = new Date(item.supplier_deadline);
        d.setHours(0, 0, 0, 0);
        const days = Math.ceil((d - today) / (1000 * 3600 * 24));
        return days >= 0 && days <= 10;
    });
    if (nearSupplierDeadlines.length > 0) {
        const first = nearSupplierDeadlines[0];
        alerts.push({
            type: "alert-warning",
            icon: "fa-solid fa-calendar-xmark",
            title: `موعد إرجاع مورد مسجل يقترب: (${first.brand_name} - تشغيلة ${first.batch_number})`,
            desc: `تاريخ مهلة المورد المسجلة هو ${first.supplier_deadline}. يرجى اتخاذ قرار إرجاعه للمورد أو نقله قبل انتهاء المهلة.`,
            actionText: "معاينة البند",
            actionClick: `openBranchItemActionModal('${first.id}')`
        });
    }

    if (alerts.length > 0) {
        alertsContainer.style.display = "flex";
        alertsContainer.innerHTML = alerts.map(a => `
            <div class="branch-action-alert ${a.type}">
                <div class="alert-content-left">
                    <div class="alert-icon-badge"><i class="${a.icon}"></i></div>
                    <div>
                        <div class="alert-title-text">${a.title}</div>
                        <div class="alert-desc-text">${a.desc}</div>
                    </div>
                </div>
                <div>
                    <button class="btn btn-sm btn-primary" onclick="${a.actionClick}" style="font-size: 0.8rem; padding: 6px 14px;">
                        ${a.actionText}
                    </button>
                </div>
            </div>
        `).join("");
    } else {
        alertsContainer.style.display = "none";
    }
}

// ==========================================
// الدالة المركزية لرسم جدول المخزون وتطبيق الفلاتر
// ==========================================
function renderMyListingsTable() {
    const tbody = document.getElementById("myListingsTbody");
    if (!tbody) return;
    if (!CURRENT_USER.profile) {
        tbody.innerHTML = `
            <tr>
                <td colspan="14" style="text-align: center; padding: 40px; color: var(--text-muted);">
                    <i class="fa-solid fa-lock" style="font-size: 2rem; margin-bottom: 10px; display: block; color: #fbbf24;"></i>
                    يرجى تسجيل الدخول أو اختيار دور صيدلية من الشريط العلوي لعرض وإدارة المخزون.
                </td>
            </tr>
        `;
        return;
    }

    const isAgencyMaster = CURRENT_USER.role === "agency_master";
    const isAgencyBranch = CURRENT_USER.role === "agency_branch";
    const isIndependent = CURRENT_USER.role === "independent";

    const agencyBranchContainer = document.getElementById("agencyBranchPills");
    const thBranchCol = document.getElementById("th-branch-col");
    const thDiscountCol = document.getElementById("th-discount-col");
    const thPriceCol = document.getElementById("th-price-col");

    const agencyBanner = document.getElementById("agencyConsolidatedBanner");
    const branchPolicyBanner = document.getElementById("agencyBranchPolicyBanner");
    const indepBanner = document.getElementById("independentPharmacyBanner");
    const branchChainBadge = document.getElementById("branchChainBadgeContainer");

    if (agencyBanner) agencyBanner.style.display = isAgencyMaster ? "block" : "none";
    if (branchPolicyBanner) branchPolicyBanner.style.display = isAgencyBranch ? "block" : "none";
    if (indepBanner) indepBanner.style.display = isIndependent ? "block" : "none";
    if (branchChainBadge) branchChainBadge.style.display = isAgencyBranch ? "flex" : "none";

    // إخفاء زري (إطلاق الكل للبورصة) و (سحب الكل للوضع المحلي) عن فرع الوكالة
    const btnPubAll = document.getElementById("btnPublishAll");
    const btnUnpubAll = document.getElementById("btnUnpublishAll");
    if (btnPubAll) btnPubAll.style.display = isAgencyBranch ? "none" : "";
    if (btnUnpubAll) btnUnpubAll.style.display = isAgencyBranch ? "none" : "";

    // إخفاء أعمدة نسبة الخصم وسعر البورصة لفرع الوكالة لأن التسعير يتبع الإدارة العامة
    if (thDiscountCol) thDiscountCol.style.display = isAgencyMaster ? "" : "none";
    if (thPriceCol) thPriceCol.style.display = isAgencyMaster ? "" : "none";

    let allMyListings = [];

    if (isAgencyMaster) {
        const agencyId = CURRENT_USER.profile.agency_id || "agency_shifa";
        const sisterBranchIds = MOCK_PHARMACIES.filter(p => p.agency_id === agencyId).map(p => p.id);
        sisterBranchIds.push(CURRENT_USER.profile.id);

        allMyListings = MOCK_LISTINGS.filter(item => sisterBranchIds.includes(item.pharmacy_id));

        if (agencyBranchContainer) agencyBranchContainer.style.display = "flex";
        if (thBranchCol) thBranchCol.style.display = "";

        const dashTitle = document.getElementById("dashboardViewTitle");
        if (dashTitle) dashTitle.innerHTML = `<i class="fa-solid fa-chart-pie"></i> لوحة التحكم والمخزون المجمع لسلسلة الفروع`;

        const tableTitle = document.getElementById("myListingsTableTitle");
        if (tableTitle) tableTitle.innerHTML = `<i class="fa-solid fa-boxes-stacked"></i> المخزون المجمع لجميع فروع الوكالة (حدة، السبعين، شعوب)`;

    } else {
        // حماية العزل التام: لا تعرض مخزون فرع آخر داخل جدول مخزون الفرع
        const currentPharmacyId = CURRENT_USER.profile.id || "pharm_agency_01";
        allMyListings = MOCK_LISTINGS.filter(item => item.pharmacy_id === currentPharmacyId);

        if (agencyBranchContainer) agencyBranchContainer.style.display = "none";
        if (thBranchCol) thBranchCol.style.display = "none";

        const dashTitle = document.getElementById("dashboardViewTitle");
        const tableTitle = document.getElementById("myListingsTableTitle");

        if (isAgencyBranch) {
            if (dashTitle) dashTitle.innerHTML = `<i class="fa-solid fa-chart-pie"></i> لوحة التحكم والمخزون — فرع الوكالة`;
            if (tableTitle) tableTitle.innerHTML = `<i class="fa-solid fa-boxes-stacked"></i> مخزون الفرع وجرد الصلاحيات والتشغيلات`;
            const branchNameEl = document.getElementById("dashBranchName");
            if (branchNameEl) branchNameEl.innerText = CURRENT_USER.profile.name || "صيدلية الشفاء - فرع حدة";
            const chainNameEl = document.getElementById("dashChainName");
            if (chainNameEl) chainNameEl.innerText = CURRENT_USER.profile.agency_name || "مجموعة صيدليات الشفاء التخصصية";
        } else {
            if (dashTitle) dashTitle.innerHTML = `<i class="fa-solid fa-chart-pie"></i> لوحة التحكم وإدارة المخزون`;
            if (tableTitle) tableTitle.innerHTML = `<i class="fa-solid fa-boxes-stacked"></i> مخزون صيدليتك وإدارة العرض في البورصة`;
        }
    }

    // بعد وجود مخزون، اختصار منطقة سحب إكسل إلى قسم قابل للطي
    const excelToggleBar = document.getElementById("excelToggleBar");
    const excelHeroSection = document.getElementById("excelHeroSection");
    if (allMyListings.length > 0) {
        if (excelToggleBar) excelToggleBar.style.display = "flex";
        if (excelHeroSection) excelHeroSection.style.display = "none"; // مطوي افتراضياً عند توفر مخزون
    } else {
        if (excelToggleBar) excelToggleBar.style.display = "none";
        if (excelHeroSection) excelHeroSection.style.display = "block";
    }

    // تحديث بطاقات المؤشرات التشغيلية القابلة للإثبات
    renderBranchOperationalCards(allMyListings);

    // تحديث التنبيهات الإجرائية
    renderBranchActionableAlerts(allMyListings);

    // ==========================================
    // حساب أعداد الفلاتر المستقلة وتحديث العدادات
    // ==========================================
    const totalBranchItems = allMyListings.length;

    // أعداد العرض الخارجي:
    const countExtNotPub = allMyListings.filter(i => !i.is_published && !i.clearance_requested).length;
    const countExtPending = allMyListings.filter(i => i.clearance_requested && !i.is_published).length;
    const countExtPub = allMyListings.filter(i => i.is_published).length;

    const elExtAll = document.getElementById("cnt-ext-all");
    const elExtNotPub = document.getElementById("cnt-ext-not-pub");
    const elExtPending = document.getElementById("cnt-ext-pending");
    const elExtPub = document.getElementById("cnt-ext-pub");

    if (elExtAll) elExtAll.innerText = totalBranchItems;
    if (elExtNotPub) elExtNotPub.innerText = countExtNotPub;
    if (elExtPending) elExtPending.innerText = countExtPending;
    if (elExtPub) elExtPub.innerText = countExtPub;

    // أعداد التداول الداخلي:
    const activeExchangePosts = (typeof MOCK_AGENCY_EXCHANGE_POSTS !== "undefined" ? MOCK_AGENCY_EXCHANGE_POSTS : [])
        .filter(p => p.status === "OPEN" && p.type === "SURPLUS");

    const activeReservations = (typeof MOCK_INVENTORY_RESERVATIONS !== "undefined" ? MOCK_INVENTORY_RESERVATIONS : [])
        .filter(r => r.status === "active" && r.reserved_quantity > 0);

    const countIntSurplus = allMyListings.filter(item => {
        return activeExchangePosts.some(p => p.branch_id === item.pharmacy_id && (p.batch_number === item.batch_number || p.drug_name === item.brand_name));
    }).length;

    const countIntReserved = allMyListings.filter(item => {
        return activeReservations.some(r => r.inventory_item_id === item.id);
    }).length;

    const elIntAll = document.getElementById("cnt-int-all");
    const elIntSurplus = document.getElementById("cnt-int-surplus");
    const elIntReserved = document.getElementById("cnt-int-reserved");

    if (elIntAll) elIntAll.innerText = totalBranchItems;
    if (elIntSurplus) elIntSurplus.innerText = countIntSurplus;
    if (elIntReserved) elIntReserved.innerText = countIntReserved;

    // أعداد الصلاحية:
    const countExpNear = allMyListings.filter(item => {
        const { diffDays } = calcDaysLeftAndLabel(item.expiry_date);
        return diffDays > 0 && diffDays <= 90;
    }).length;

    const countExpExpired = allMyListings.filter(item => {
        const { diffDays } = calcDaysLeftAndLabel(item.expiry_date);
        return diffDays <= 0;
    }).length;

    const elExpAll = document.getElementById("cnt-exp-all");
    const elExpNear = document.getElementById("cnt-exp-near");
    const elExpExpired = document.getElementById("cnt-exp-expired");

    if (elExpAll) elExpAll.innerText = totalBranchItems;
    if (elExpNear) elExpNear.innerText = countExpNear;
    if (elExpExpired) elExpExpired.innerText = countExpExpired;

    // ==========================================
    // تطبيق الفلاتر المتقاطعة (Search + External + Internal + Expiry)
    // ==========================================
    let displayItems = allMyListings.filter(item => {
        // 1. تصفية البحث
        if (currentInventorySearchQuery) {
            const q = currentInventorySearchQuery;
            const matchBrand = (item.brand_name || "").toLowerCase().includes(q);
            const matchActive = (item.active_ingredient || "").toLowerCase().includes(q);
            const matchBatch = (item.batch_number || "").toLowerCase().includes(q);
            const matchBarcode = (item.barcode || "").toLowerCase().includes(q);
            if (!matchBrand && !matchActive && !matchBatch && !matchBarcode) return false;
        }

        // 2. تصفية حالة العرض الخارجي
        if (currentInventoryExternalFilter === "NOT_PUBLISHED") {
            if (item.is_published || item.clearance_requested) return false;
        } else if (currentInventoryExternalFilter === "PENDING_APPROVAL") {
            if (!item.clearance_requested || item.is_published) return false;
        } else if (currentInventoryExternalFilter === "PUBLISHED") {
            if (!item.is_published) return false;
        }

        // 3. تصفية التداول الداخلي
        if (currentInventoryInternalFilter === "SURPLUS_POSTED") {
            const hasSurplus = activeExchangePosts.some(p => p.branch_id === item.pharmacy_id && (p.batch_number === item.batch_number || p.drug_name === item.brand_name));
            if (!hasSurplus) return false;
        } else if (currentInventoryInternalFilter === "HAS_RESERVATION") {
            const hasRes = activeReservations.some(r => r.inventory_item_id === item.id);
            if (!hasRes) return false;
        }

        // 4. تصفية الصلاحية
        if (currentInventoryExpiryFilter !== "ALL") {
            const { diffDays } = calcDaysLeftAndLabel(item.expiry_date);
            if (currentInventoryExpiryFilter === "NEAR_EXPIRY" && (diffDays <= 0 || diffDays > 90)) return false;
            if (currentInventoryExpiryFilter === "EXPIRED" && diffDays > 0) return false;
        }

        // 5. تصفية الفرع (حصري لإدارة الوكالة)
        if (isAgencyMaster && currentBranchFilter !== "all") {
            if (item.pharmacy_id !== currentBranchFilter) return false;
        }

        return true;
    });

    // تحديث عداد النتائج المعروضة من إجمالي المخزون
    const resultsCountEl = document.getElementById("inventoryResultsCount");
    if (resultsCountEl) {
        resultsCountEl.innerText = `عرض ${displayItems.length} من أصل ${totalBranchItems} تشغيلة مخزنية`;
    }

    if (displayItems.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="14" style="text-align: center; padding: 45px 20px; color: var(--text-muted);">
                    <i class="fa-solid fa-filter-circle-xmark" style="font-size: 2.2rem; margin-bottom: 12px; display: block; opacity: 0.45; color: #38bdf8;"></i>
                    <div style="font-size: 1rem; font-weight: 700; color: #cbd5e1; margin-bottom: 4px;">لا توجد تشغيلات مخزنية تطابق الفلاتر المحددة</div>
                    <p style="font-size: 0.82rem; margin-bottom: 14px;">جرب تغيير خيارات التصفية أو اضغط على مسح الفلاتر لعرض كافة تشغيلات الفرع.</p>
                    <button class="btn-clear-filters" onclick="clearAllInventoryFilters()">
                        <i class="fa-solid fa-rotate-left"></i> مسح كافة الفلاتر
                    </button>
                </td>
            </tr>
        `;
        return;
    }

    // تحديث شارات وبيانات قائمة التنقل الجانبية للفرع (Collapsible Side Navigation)
    const sidebarEl = document.getElementById("branchErpSidebar");
    if (sidebarEl) {
        sidebarEl.style.display = isAgencyBranch ? "flex" : "none";
        if (isAgencyBranch) {
            const sbBranchName = document.getElementById("sbBranchName");
            const sbChainName = document.getElementById("sbChainName");
            if (sbBranchName) sbBranchName.innerText = CURRENT_USER?.profile?.name || "صيدلية الشفاء - فرع حدة";
            if (sbChainName) sbChainName.innerText = CURRENT_USER?.profile?.agency_name || "مجموعة صيدليات الشفاء التخصصية";

            const elSbAll = document.getElementById("sbBadge-all");
            const elSbNear = document.getElementById("sbBadge-near");
            const elSbExp = document.getElementById("sbBadge-expired");
            const elSbSurplus = document.getElementById("sbBadge-surplus");
            const elSbReserved = document.getElementById("sbBadge-reserved");
            const elSbDispatch = document.getElementById("sbBadge-dispatch");
            const elSbTransit = document.getElementById("sbBadge-transit");
            const elSbPendingB2b = document.getElementById("sbBadge-pending-b2b");
            const elSbPubB2b = document.getElementById("sbBadge-pub-b2b");
            const elSbDisc = document.getElementById("sbBadge-disc");

            if (elSbAll) elSbAll.innerText = totalBranchItems;
            if (elSbNear) elSbNear.innerText = countExpNear;
            if (elSbExp) elSbExp.innerText = countExpExpired;
            if (elSbSurplus) elSbSurplus.innerText = countIntSurplus;
            if (elSbReserved) elSbReserved.innerText = countIntReserved;
            if (elSbPendingB2b) elSbPendingB2b.innerText = countExtPending;
            if (elSbPubB2b) elSbPubB2b.innerText = countExtPub;

            const currentBranchId = CURRENT_USER?.profile?.id || "pharm_agency_01";
            const readyToDispatchCount = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined" ? MOCK_INTERNAL_TRANSFERS : [])
                .filter(t => (t.from_branch_id === currentBranchId || t.from_pharmacy_id === currentBranchId) && t.status === "approved_and_reserved").length;
            if (elSbDispatch) elSbDispatch.innerText = readyToDispatchCount;

            const inTransitCount = (typeof MOCK_INTERNAL_TRANSFERS !== "undefined" ? MOCK_INTERNAL_TRANSFERS : [])
                .filter(t => (t.to_branch_id === currentBranchId || t.to_pharmacy_id === currentBranchId) && (t.status === "in_transit" || t.status === "IN_TRANSIT")).length;
            if (elSbTransit) elSbTransit.innerText = inTransitCount;

            const discCount = (typeof MOCK_TRANSFER_DISCREPANCIES !== "undefined" ? MOCK_TRANSFER_DISCREPANCIES : [])
                .filter(d => (d.to_branch_id === currentBranchId || d.from_branch_id === currentBranchId || d.to_pharmacy_id === currentBranchId || d.from_pharmacy_id === currentBranchId) && d.status === "OPEN").length;
            if (elSbDisc) elSbDisc.innerText = discCount;
        }
    }

    // ==========================================
    // بناء صفوف الجدول الرسمية (ERP Grid بدون عمود السهم العشوائي)
    // ==========================================
    tbody.innerHTML = displayItems.map(item => {
        const { diffDays, label: expiryLabel, badgeClass: expiryBadgeClass } = calcDaysLeftAndLabel(item.expiry_date);
        const physical = (typeof item.physical_quantity !== "undefined") ? item.physical_quantity : item.quantity;
        const itemReservations = (typeof MOCK_INVENTORY_RESERVATIONS !== "undefined" ? MOCK_INVENTORY_RESERVATIONS : [])
            .filter(r => r.inventory_item_id === item.id && r.status === "active");
        const reserved = itemReservations.reduce((sum, r) => sum + r.reserved_quantity, 0);
        const available = Math.max(0, physical - reserved);

        // شارة موحدة لحالة التداول بالمنصة تجمع الداخلي والخارجي برشاقة
        const activeSurplus = activeExchangePosts.find(p => p.branch_id === item.pharmacy_id && (p.batch_number === item.batch_number || p.drug_name === item.brand_name));
        let platformStatusHtml = "";

        if (item.is_published) {
            platformStatusHtml = `
                <span class="badge-status badge-active" style="font-size: 0.74rem;" title="معروض بالبورصة بسعر معتمد">
                    <i class="fa-solid fa-circle-check"></i> بالبورصة (${item.clearance_price?.toLocaleString() || item.original_price} ر.ي)
                </span>
            `;
        } else if (item.clearance_requested) {
            platformStatusHtml = `
                <span class="badge-status" style="background: rgba(248, 113, 113, 0.15); color: #f87171; border: 1px solid rgba(248, 113, 113, 0.3); font-size: 0.74rem;" title="طلب بيع خارجي بانتظار تسعير الإدارة">
                    <i class="fa-solid fa-clock"></i> اعتماد بيع معلق (${item.clearance_request_qty || item.quantity} ${item.unit || 'باكت'})
                </span>
            `;
        } else if (activeSurplus && reserved > 0) {
            platformStatusHtml = `
                <div style="display: flex; flex-direction: column; gap: 3px;">
                    <span class="badge-status" style="background: rgba(251, 191, 36, 0.15); color: #fbbf24; border: 1px solid rgba(251, 191, 36, 0.3); font-size: 0.72rem;">
                        <i class="fa-solid fa-box-open"></i> فائض: ${activeSurplus.quantity}
                    </span>
                    <span class="badge-status" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); font-size: 0.72rem;">
                        <i class="fa-solid fa-lock"></i> حجز: ${reserved}
                    </span>
                </div>
            `;
        } else if (activeSurplus) {
            platformStatusHtml = `
                <span class="badge-status" style="background: rgba(251, 191, 36, 0.15); color: #fbbf24; border: 1px solid rgba(251, 191, 36, 0.3); font-size: 0.74rem;">
                    <i class="fa-solid fa-box-open"></i> فائض معلن (${activeSurplus.quantity})
                </span>
            `;
        } else if (reserved > 0) {
            platformStatusHtml = `
                <span class="badge-status" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); font-size: 0.74rem;">
                    <i class="fa-solid fa-lock"></i> محجوز لمناقلة (${reserved})
                </span>
            `;
        } else {
            platformStatusHtml = `<span class="badge-status badge-draft" style="font-size: 0.74rem;"><i class="fa-solid fa-minus"></i> جرد محلي</span>`;
        }

        // خلية الفرع المالك (لإدارة الوكالة فقط)
        let branchCell = "";
        if (isAgencyMaster) {
            const seller = MOCK_PHARMACIES.find(p => p.id === item.pharmacy_id);
            let bName = seller ? seller.name.replace("صيدلية الشفاء - ", "").replace("مجموعة صيدليات الشفاء التخصصية (", "").replace(")", "") : "المركز الرئيسي";
            branchCell = `<td><span class="badge-branch-tag"><i class="fa-solid fa-location-dot"></i> ${bName}</span></td>`;
        }

        // خلايا الخصم والسعر (للإدارة العامة فقط)
        let discountCellHtml = "";
        let priceCellHtml = "";
        if (isAgencyMaster) {
            discountCellHtml = `
                <td>
                    <div class="discount-inline-group" title="قرار إداري مركزي">
                        <input type="number" min="5" max="85" step="5" value="${item.discount_percent}" class="discount-cell-input agency-master-input" onchange="updateItemDiscount('${item.id}', this.value)">
                        <span class="discount-percent-symbol">%</span>
                    </div>
                </td>
            `;
            priceCellHtml = `<td style="color: var(--primary-light); font-weight: 800; font-size: 0.95rem;">${item.clearance_price?.toLocaleString() || item.original_price} ر.ي</td>`;
        }

        // أزرار التحكم والإجراء
        let actionCellHtml = "";
        if (isAgencyBranch) {
            actionCellHtml = `
                <td style="text-align: center;">
                    <div style="display: inline-flex; gap: 6px; align-items: center; justify-content: center;">
                        <button class="btn-item-action" onclick="openBranchItemActionModal('${item.id}')" title="فتح نافذة إجراءات الصنف">
                            <i class="fa-solid fa-bolt"></i> إجراءات
                        </button>
                        <button class="btn-row-details" onclick="toggleRowDetails('${item.id}', this)" title="عرض التفاصيل الإضافية وسجل الحجوزات">
                            <i class="fa-solid fa-circle-info"></i> تفاصيل
                        </button>
                    </div>
                </td>
            `;
        } else if (isAgencyMaster) {
            const masterTransferBtn = !item.is_published ? `
                <button class="btn-direct-transfer" onclick="openInternalTransferModal('${item.id}')" title="أمر مناقلة داخلية مجانية">
                    <i class="fa-solid fa-shuffle"></i> مناقلة
                </button>
            ` : "";
            const masterMarketBtn = item.is_published ? `
                <button class="btn-unpublish" onclick="togglePublishListing('${item.id}')" title="سحب للوضع الداخلي">
                    <i class="fa-solid fa-pause"></i> سحب
                </button>
            ` : `
                <button class="btn-master-approve" onclick="openMasterDiscountModal('${item.id}')" title="اعتماد الخصم والطرح للبورصة">
                    <i class="fa-solid fa-stamp"></i> تسعير وطرح
                </button>
            `;
            actionCellHtml = `
                <td style="text-align: center;">
                    <div style="display: inline-flex; gap: 6px; align-items: center;">
                        ${masterTransferBtn}
                        ${masterMarketBtn}
                    </div>
                </td>
            `;
        } else {
            actionCellHtml = `
                <td style="text-align: center;">
                    <button class="btn-publish" onclick="togglePublishListing('${item.id}')">
                        <i class="fa-solid fa-rocket"></i> ${item.is_published ? 'سحب' : 'إطلاق للبورصة'}
                    </button>
                </td>
            `;
        }

        // تفاصيل الحجوزات النشطة لصف التوسعة
        let resDetailsHtml = '<div style="color: var(--text-muted); font-size: 0.8rem;">لا توجد حجوزات نشطة حالياً.</div>';
        if (itemReservations.length > 0) {
            resDetailsHtml = itemReservations.map(r => `
                <div style="padding: 4px 0; border-bottom: 1px dashed rgba(255,255,255,0.08); font-size: 0.8rem;">
                    <i class="fa-solid fa-ticket text-info"></i> حجز رقم <code>${r.id}</code> لطلب مناقلة <strong>${r.transfer_id || 'عام'}</strong>: 
                    <strong style="color: #f87171;">${r.reserved_quantity} ${item.unit || 'باكت'}</strong>
                </div>
            `).join("");
        }

        // تفاصيل الفائض المعلن لصف التوسعة
        let surplusDetailsHtml = '<div style="color: var(--text-muted); font-size: 0.8rem;">غير منشور بساحة التكافل.</div>';
        if (activeSurplus) {
            surplusDetailsHtml = `
                <div style="font-size: 0.8rem; line-height: 1.5;">
                    <div>الكمية المعروضة أصلاً: <strong>${activeSurplus.quantity} ${item.unit || 'باكت'}</strong></div>
                    <div>المتبقي القابل للطلب: <strong style="color: #fbbf24;">${activeSurplus.quantity} ${item.unit || 'باكت'}</strong></div>
                    <div style="color: #94a3b8; font-size: 0.76rem; margin-top: 3px;">ملاحظات الإعلان: ${activeSurplus.reason || 'فائض راكد'}</div>
                </div>
            `;
        }

        return `
            <tr id="row-${item.id}">
                <td>
                    <div class="brand-hero-cell">${item.brand_name}</div>
                    <div class="brand-meta-sub">${item.active_ingredient || ''} ${item.strength ? '• ' + item.strength : ''} ${item.form ? '• ' + item.form : ''}</div>
                </td>
                ${branchCell}
                <td><code style="font-size: 0.82rem; font-weight: 700; color: #f1f5f9;">${item.batch_number}</code></td>
                <td>
                    <span style="font-size: 0.84rem; display: block; font-weight: 600;">${item.expiry_date}</span>
                    <span class="badge ${expiryBadgeClass}" style="font-size: 0.72rem; padding: 2px 6px;">${expiryLabel}</span>
                </td>
                <td><span style="font-size: 0.84rem;">${item.unit || 'باكت'}</span></td>
                <td><strong style="color: #38bdf8; font-size: 0.95rem;">${physical}</strong></td>
                <td><strong style="color: ${reserved > 0 ? '#f87171' : 'var(--text-muted)'}; font-size: 0.95rem;">${reserved}</strong></td>
                <td><strong style="color: #34d399; font-size: 1.05rem;">${available}</strong></td>
                <td>${platformStatusHtml}</td>
                ${discountCellHtml}
                ${priceCellHtml}
                ${actionCellHtml}
            </tr>
            <tr id="details-row-${item.id}" class="row-details-expanded" style="display: none;">
                <td colspan="12">
                    <div class="row-details-content">
                        <div class="row-detail-box">
                            <h5><i class="fa-solid fa-lock"></i> الحجوزات النشطة المرتبطة</h5>
                            ${resDetailsHtml}
                        </div>
                        <div class="row-detail-box">
                            <h5><i class="fa-solid fa-box-open"></i> إعلان الفائض الداخلي بالساحة</h5>
                            ${surplusDetailsHtml}
                        </div>
                        <div class="row-detail-box">
                            <h5><i class="fa-solid fa-info-circle"></i> البيانات المرجعية وحالة التخزين</h5>
                            <div>سعر التكلفة المرجعي: <strong style="color: #38bdf8;">${item.original_price ? item.original_price.toLocaleString() + ' ر.ي' : 'غير محدد'}</strong> <small style="color: #94a3b8;">(للقراءة فقط)</small></div>
                            <div style="margin-top: 4px;">شروط التخزين: <strong>${item.storage_condition || 'درجة حرارة الغرفة (أقل من 25°C)'}</strong></div>
                            <div style="margin-top: 4px;">مهلة إرجاع المورد: <strong>${item.supplier_deadline ? item.supplier_deadline + ' (وفق سياسة المورد)' : 'غير مسجلة'}</strong></div>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }).join("");
}

// دالة طي وتوسيع قائمة التنقل الجانبية للفرع
function toggleBranchSidebar() {
    const sb = document.getElementById("branchErpSidebar");
    const icon = document.getElementById("sbToggleIcon");
    if (!sb) return;
    const isCollapsed = sb.classList.toggle("collapsed");
    if (icon) {
        icon.className = isCollapsed ? "fa-solid fa-angles-left" : "fa-solid fa-angles-right";
    }
}

// دالة طي وتوسيع مجموعات القائمة الجانبية
function toggleSidebarGroup(groupId) {
    const items = document.getElementById(groupId + "-items");
    const chevron = document.getElementById(groupId + "-chevron");
    if (!items) return;
    const isCollapsed = items.classList.toggle("collapsed");
    if (chevron) {
        chevron.style.transform = isCollapsed ? "rotate(-90deg)" : "rotate(0deg)";
    }
}

// دالة التصفية السريعة من القائمة الجانبية
function selectSidebarNav(navKey) {
    document.querySelectorAll(".sidebar-nav-item").forEach(el => el.classList.remove("active"));
    const activeEl = document.getElementById("sbItem-" + navKey);
    if (activeEl) activeEl.classList.add("active");

    if (navKey === "all") {
        clearAllInventoryFilters();
    } else if (navKey === "near_expiry") {
        setExpiryFilter("NEAR_EXPIRY");
    } else if (navKey === "expired") {
        setExpiryFilter("EXPIRED");
    } else if (navKey === "surplus") {
        setInternalFilter("SURPLUS_POSTED");
    } else if (navKey === "reserved") {
        setInternalFilter("HAS_RESERVATION");
    } else if (navKey === "pending_b2b") {
        setExternalFilter("PENDING_APPROVAL");
    } else if (navKey === "published_b2b") {
        setExternalFilter("PUBLISHED");
    }
}

function togglePublishListing(id) {
    const item = MOCK_LISTINGS.find(x => x.id === id);
    if (!item) return;

    item.is_published = !item.is_published;
    item.status = item.is_published ? "active" : "draft";

    renderMyListingsTable();
    renderMarketplace();

    if (item.is_published) {
        showToast("🚀 تم إطلاق \"" + item.brand_name + "\" للبورصة الدوائية بنجاح!", "success");
    } else {
        showToast("⏸️ تم سحب \"" + item.brand_name + "\" من البورصة وإعادته للمخزون الداخلي الخاص.", "warning");
    }
}

function updateItemDiscount(id, newPercent) {
    if (CURRENT_USER.role === "agency_branch") {
        showToast("⚠️ غير مصرح: تحديد وتعديل نسب الخصم قرار إداري مركزي محصور بالإدارة العامة للوكالة فقط.", "warning");
        renderMyListingsTable();
        return;
    }

    let p = parseInt(newPercent);
    if (isNaN(p) || p < 5) p = 5;
    if (p > 90) p = 90;

    const item = MOCK_LISTINGS.find(x => x.id === id);
    if (!item) return;

    item.discount_percent = p;
    item.clearance_price = Math.round(item.original_price * (1 - p / 100));

    renderMyListingsTable();
    renderMarketplace();

    if (CURRENT_USER.role === "agency_master") {
        const branch = MOCK_PHARMACIES.find(p => p.id === item.pharmacy_id);
        const bName = branch ? branch.name : "الفرع";
        showToast("👑 [قرار إداري مركزي]: اعتمدت الإدارة العامة خصم " + p + "% لصنف " + item.brand_name + " التابع لـ (" + bName + "). تم تعميم السعر على الفرع والبورصة الخارجية!", "success");
    } else {
        showToast("✨ تم تعديل خصم \"" + item.brand_name + "\" إلى " + p + "% (سعر البورصة: " + item.clearance_price.toLocaleString() + " ر.ي)", "info");
    }
}

function publishAllMyListings() {
    const isAgencyMaster = CURRENT_USER.role === "agency_master";
    let count = 0;

    if (isAgencyMaster) {
        const agencyId = CURRENT_USER.profile.agency_id || "agency_shifa";
        const sisterBranchIds = MOCK_PHARMACIES.filter(p => p.agency_id === agencyId).map(p => p.id);
        sisterBranchIds.push(CURRENT_USER.profile.id);

        MOCK_LISTINGS.forEach(item => {
            if (sisterBranchIds.includes(item.pharmacy_id) && !item.is_published) {
                item.is_published = true;
                item.status = "active";
                count++;
            }
        });
    } else {
        const currentPharmacyId = CURRENT_USER.profile.id || "pharm_01";
        MOCK_LISTINGS.forEach(item => {
            if (item.pharmacy_id === currentPharmacyId && !item.is_published) {
                item.is_published = true;
                item.status = "active";
                count++;
            }
        });
    }

    renderMyListingsTable();
    renderMarketplace();

    if (count > 0) {
        showToast(`⚡ تم إطلاق جميع الأصناف (${count} أصناف) للبورصة بنجاح!`, "success");
    } else {
        showToast("جميع الأصناف معروضة بالفعل في البورصة.", "info");
    }
}

function unpublishAllMyListings() {
    const isAgencyMaster = CURRENT_USER.role === "agency_master";
    let count = 0;

    if (isAgencyMaster) {
        const agencyId = CURRENT_USER.profile.agency_id || "agency_shifa";
        const sisterBranchIds = MOCK_PHARMACIES.filter(p => p.agency_id === agencyId).map(p => p.id);
        sisterBranchIds.push(CURRENT_USER.profile.id);

        MOCK_LISTINGS.forEach(item => {
            if (sisterBranchIds.includes(item.pharmacy_id) && item.is_published) {
                item.is_published = false;
                item.status = "draft";
                count++;
            }
        });
    } else {
        const currentPharmacyId = CURRENT_USER.profile.id || "pharm_01";
        MOCK_LISTINGS.forEach(item => {
            if (item.pharmacy_id === currentPharmacyId && item.is_published) {
                item.is_published = false;
                item.status = "draft";
                count++;
            }
        });
    }

    renderMyListingsTable();
    renderMarketplace();

    if (count > 0) {
        showToast(`⏸️ تم سحب جميع الأصناف (${count} أصناف) وإعادتها لوضع المخزون المحلي.`, "warning");
    } else {
        showToast("جميع الأصناف مسحوبة بالفعل في الوضع المحلي.", "info");
    }
}

function deleteMyListing(id) {
    const idx = MOCK_LISTINGS.findIndex(x => x.id === id);
    if (idx !== -1) {
        const name = MOCK_LISTINGS[idx].brand_name;
        MOCK_LISTINGS.splice(idx, 1);
        renderMyListingsTable();
        renderMarketplace();
        showToast(`تم حذف صنف "${name}" من قائمة المخزون.`, "info");
    }
}

function handleDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById("excelDropZone")?.classList.add("drag-active");
}

function handleDragLeave(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById("excelDropZone")?.classList.remove("drag-active");
}

function handleFileDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById("excelDropZone")?.classList.remove("drag-active");
    loadMockExcelData();
}

function triggerFileInput() {
    document.getElementById("excelFileInput")?.click();
}

function handleFileSelect(e) {
    loadMockExcelData();
}

let currentExcelReconcileReport = null;

function loadMockExcelData() {
    const isAgencyMaster = CURRENT_USER.role === "agency_master";
    const currentPharmacyId = CURRENT_USER.profile ? CURRENT_USER.profile.id : "pharm_agency_01";
    
    showToast("جاري فحص كشف النظام المحاسبي ومطابقة الحجوزات والمناقلات القائمة...", "info");

    const context = getSecurityContext();
    const rowsToInspect = MOCK_YEMENSOFT_EXCEL_DATA.map(r => ({
        ...r,
        pharmacy_id: isAgencyMaster ? "pharm_agency_01" : currentPharmacyId
    }));

    TransferService.previewAndReconcileExcelImport(context, {
        pharmacyId: currentPharmacyId,
        excelRows: rowsToInspect
    }).then(report => {
        currentExcelReconcileReport = report;
        renderExcelReconcileModal(report);
    }).catch(err => {
        showToast(`خطأ في معاينة الاستيراد: ${err.message}`, "error");
    });
}

function renderExcelReconcileModal(report) {
    const container = document.getElementById("excelReconcileReportArea");
    if (!container) return;

    let html = `
        <div style="display: flex; gap: 15px; margin-bottom: 15px;">
            <div style="flex: 1; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); padding: 12px; border-radius: 8px;">
                <div style="font-size: 0.82rem; color: #10b981;">أصناف جاهزة للاستيراد</div>
                <div style="font-size: 1.4rem; font-weight: 800; color: #10b981;">${report.summary.readyCount} أصناف</div>
                <small style="color: var(--text-muted);">أصناف مستقرة تؤسس رصيداً جديداً دون تعارض</small>
            </div>
            <div style="flex: 1; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); padding: 12px; border-radius: 8px;">
                <div style="font-size: 0.82rem; color: #fbbf24;">أصناف معلّقة للمراجعة</div>
                <div style="font-size: 1.4rem; font-weight: 800; color: #fbbf24;">${report.summary.suspendedCount} أصناف</div>
                <small style="color: var(--text-muted);">مرتبطة بحجوزات أو مناقلات جارية عُلقت منعاً لكسر الرصيد</small>
            </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
            <thead>
                <tr style="border-bottom: 2px solid var(--border-color); text-align: right; color: var(--text-muted);">
                    <th style="padding: 6px;">الصنف والتشغيلة</th>
                    <th style="padding: 6px; text-align: center;">الرصيد الحالي</th>
                    <th style="padding: 6px; text-align: center;">رصيد الملف</th>
                    <th style="padding: 6px; text-align: center;">الفارق</th>
                    <th style="padding: 6px;">حالة المطابقة والقرار</th>
                </tr>
            </thead>
            <tbody>
    `;

    // Suspended rows
    report.suspendedForReview.forEach(r => {
        html += `
            <tr style="background: rgba(245, 158, 11, 0.05); border-bottom: 1px solid rgba(245, 158, 11, 0.2);">
                <td style="padding: 8px;">
                    <strong>${r.item.brand_name}</strong>
                    <div style="font-size: 0.75rem; color: #94a3b8;">تشغيلة: <code>${r.item.batch_number}</code></div>
                </td>
                <td style="padding: 8px; text-align: center;">${r.existingPhysical}</td>
                <td style="padding: 8px; text-align: center; font-weight: 700;">${r.importedPhysical}</td>
                <td style="padding: 8px; text-align: center; color: ${r.variance >= 0 ? '#10b981' : '#f43f5e'}; font-weight: 700;">
                    ${r.variance > 0 ? ('+' + r.variance) : r.variance}
                </td>
                <td style="padding: 8px;">
                    <span class="badge-status" style="background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4); font-size: 0.75rem;">
                        <i class="fa-solid fa-pause"></i> معلّق للمراجعة
                    </span>
                    <div style="font-size: 0.72rem; color: #f59e0b; margin-top: 2px;">${r.reason}</div>
                </td>
            </tr>
        `;
    });

    // Ready rows
    report.readyToImport.forEach(r => {
        html += `
            <tr style="border-bottom: 1px solid var(--border-color);">
                <td style="padding: 8px;">
                    <strong>${r.item.brand_name}</strong>
                    <div style="font-size: 0.75rem; color: #94a3b8;">تشغيلة: <code>${r.item.batch_number}</code></div>
                </td>
                <td style="padding: 8px; text-align: center;">${r.type === 'NEW_ITEM' ? '-' : r.existingPhysical}</td>
                <td style="padding: 8px; text-align: center; font-weight: 700; color: #10b981;">${r.item.quantity}</td>
                <td style="padding: 8px; text-align: center;">${r.type === 'NEW_ITEM' ? ('+' + r.item.quantity) : r.variance}</td>
                <td style="padding: 8px;">
                    <span class="badge-status badge-active" style="font-size: 0.75rem;">
                        <i class="fa-solid fa-check"></i> جاهز للاستيراد
                    </span>
                </td>
            </tr>
        `;
    });

    html += `
            </tbody>
        </table>
    `;

    container.innerHTML = html;
    openModal("excelReconcileModal");
}

function confirmExcelReconciledImport() {
    if (!currentExcelReconcileReport) return;

    const currentPharmacyId = CURRENT_USER.profile ? CURRENT_USER.profile.id : "pharm_agency_01";
    let importedCount = 0;

    currentExcelReconcileReport.readyToImport.forEach((entry, idx) => {
        const excelItem = entry.item;
        const newItem = {
            id: `imp_${Date.now()}_${idx}`,
            brand_name: excelItem.brand_name,
            active_ingredient: excelItem.active_ingredient,
            manufacturer: excelItem.manufacturer || "شركة دوائية معتمدة",
            batch_number: excelItem.batch_number,
            quantity: excelItem.quantity,
            physical_quantity: excelItem.quantity,
            quarantine_quantity: 0,
            expiry_date: excelItem.expiry_date,
            days_left: excelItem.days_left || 65,
            urgency: (excelItem.days_left <= 60) ? "critical" : (excelItem.days_left <= 90 ? "moderate" : "safe"),
            original_price: excelItem.original_price,
            discount_percent: excelItem.discount_percent,
            clearance_price: Math.round(excelItem.original_price * (1 - excelItem.discount_percent / 100)),
            pharmacy_id: currentPharmacyId,
            status: "draft",
            is_published: false
        };
        MOCK_LISTINGS.unshift(newItem);
        importedCount++;
    });

    closeModal("excelReconcileModal");
    renderMyListingsTable();
    renderMarketplace();
    updateNavbarAndUI();

    showToast(`✨ تم استيراد (${importedCount} أصناف) جاهزة بنجاح، مع تعليق (${currentExcelReconcileReport.summary.suspendedCount} أصناف) مرتبطة بمناقلات للمراجعة اليدوية!`, "success");
}

/**
 * 12. صفقات الضمان وتحرير الدفعات
 */
function renderEscrowDeals() {
    const list = document.getElementById("activeDealsList");
    if (!list) return;

    list.innerHTML = MOCK_ESCROW_DEALS.map(deal => {
        let tagClass = "status-in-escrow";
        if (deal.status === "SHIPPED") tagClass = "status-shipped";
        if (deal.status === "COMPLETED") tagClass = "status-completed";

        return `
            <div class="deal-card">
                <div class="deal-header">
                    <div>
                        <span class="deal-id"><i class="fa-solid fa-file-contract"></i> صفقة رقم: ${deal.id}</span>
                        <div style="font-size: 0.88rem; color: #fff; margin-top: 4px; font-weight: 600;">${deal.drug_name}</div>
                    </div>
                    <span class="deal-status-tag ${tagClass}">
                        <i class="fa-solid fa-lock"></i> ${deal.status_text}
                    </span>
                </div>

                <div class="deal-stepper">
                    <div class="step-item ${deal.step >= 1 ? 'completed' : ''}">
                        <div class="step-circle"><i class="fa-solid fa-check"></i></div>
                        <span class="step-label">1. حجز المبلغ</span>
                    </div>
                    <div class="step-item ${deal.step >= 2 ? (deal.step === 2 ? 'active' : 'completed') : ''}">
                        <div class="step-circle">${deal.step > 2 ? '<i class="fa-solid fa-check"></i>' : '2'}</div>
                        <span class="step-label">2. الشحن والتسليم</span>
                    </div>
                    <div class="step-item ${deal.step >= 3 ? (deal.step === 3 ? 'active' : 'completed') : ''}">
                        <div class="step-circle">${deal.step > 3 ? '<i class="fa-solid fa-check"></i>' : '3'}</div>
                        <span class="step-label">3. فحص البضاعة</span>
                    </div>
                    <div class="step-item ${deal.step === 4 ? 'completed' : ''}">
                        <div class="step-circle">4</div>
                        <span class="step-label">4. تحرير الكاش للبائع</span>
                    </div>
                </div>

                <div class="deal-details-bar">
                    <div class="deal-parties">
                        <div>البائع: <strong>${deal.seller_pharmacy}</strong></div>
                        <div>المشتري: <strong>${deal.buyer_pharmacy}</strong></div>
                    </div>
                    <div class="deal-financials">
                        <div>المبلغ المحجوز بالضمان: <span class="deal-total-amount">${deal.amount.toLocaleString()} ر.ي</span></div>
                        ${deal.step === 3 ? `
                            <button class="btn btn-sm btn-primary" onclick="releaseEscrowPayment('${deal.id}')">
                                <i class="fa-solid fa-check-double"></i> تأكيد الفحص وتحرير الدفعة للبائع
                            </button>
                            <button class="btn btn-sm btn-light" onclick="raiseDispute('${deal.id}')" style="color: var(--danger-red);">
                                <i class="fa-solid fa-triangle-exclamation"></i> رفع نزاع
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }).join("");
}

function releaseEscrowPayment(dealId) {
    const deal = MOCK_ESCROW_DEALS.find(d => d.id === dealId);
    if (!deal) return;

    deal.status = "COMPLETED";
    deal.status_text = "تم الفحص بنجاح وتحرير المبلغ للبائع نقداً";
    deal.step = 4;

    if (CURRENT_USER.profile) {
        CURRENT_USER.profile.locked_balance = Math.max(0, (CURRENT_USER.profile.locked_balance || 0) - deal.amount);
    }

    updateNavbarAndUI();
    renderEscrowDeals();
    showToast(`✅ تم تأكيد مطابقة دواء الصفقة (${dealId}) وتحرير المبلغ للبائع بنجاح!`, "success");
}

function raiseDispute(dealId) {
    const reason = prompt("يرجى كتابة سبب الاعتراض على الشحنة (مثال: تاريخ انتهاء غير مطابق لما هو معروض في المنصة):");
    if (reason) {
        showToast("⚠️ تم تعليق الصفقة وتجميد المبلغ بالكامل وإحالة الشكوى لمدير المنصة للتحكيم.", "warning");
    }
}

/**
 * 13. رادار الأدوية
 */
function renderRadarGrid() {
    const grid = document.getElementById("radarCardsGrid");
    if (!grid) return;

    grid.innerHTML = MOCK_RADAR_ALERTS.map(rad => {
        return `
            <div class="radar-card">
                <div>
                    <div class="radar-header">
                        <span class="radar-signal"><i class="fa-solid fa-satellite-dish"></i> نشط ويرصد</span>
                        <span style="font-size: 0.78rem; color: var(--text-muted);">${rad.last_alert}</span>
                    </div>
                    <div class="radar-target-title" style="margin: 10px 0 6px;">${rad.target_name}</div>
                    <div style="font-size: 0.85rem; color: var(--text-secondary);">شرط الإشعار: خصم لا يقل عن <strong>${rad.min_discount}%</strong></div>
                    <div style="font-size: 0.82rem; color: var(--accent-blue); margin-top: 4px;">النطاق: ${rad.scope}</div>
                </div>
                <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--border-color); padding-top: 12px;">
                    <span style="font-size: 0.85rem; color: var(--primary-light); font-weight: 700;">
                        <i class="fa-solid fa-bell"></i> تم العثور على ${rad.matches_found} عروض
                    </span>
                    <button class="btn btn-sm btn-outline" onclick="switchTab('marketplace')">
                        عرض النتائج
                    </button>
                </div>
            </div>
        `;
    }).join("");
}

function openAddRadarModal() {
    openModal("addRadarModal");
}

function saveRadarAlert() {
    const target = document.getElementById("radarTargetDrug").value;
    const discount = document.getElementById("radarMinDiscount").value;
    const scope = document.getElementById("radarScopeCity").value;

    if (!target) {
        alert("يرجى إدخال اسم الدواء المستهدف في الرادار");
        return;
    }

    MOCK_RADAR_ALERTS.unshift({
        id: `rad_${Date.now()}`,
        target_name: target,
        min_discount: parseInt(discount) || 30,
        scope: scope === "all" ? "كل المحافظات" : scope,
        status: "active",
        matches_found: 0,
        last_alert: "الآن"
    });

    closeModal("addRadarModal");
    renderRadarGrid();
    showToast(`📡 تم تفعيل رادار المراقبة لدواء (${target}) بنجاح!`, "success");
}

/**
 * 14. منبه الموردين وإضافة صنف
 */
function generateSupplierReturnReport() {
    alert("📄 جاري توليد كشف المرتجع الرسمي لشركة (شفا للأدوية)... تم تضمين أسماء الأدوية، تواريخ الصلاحية، وأرقام التشغيلات لتسليمها للمندوب قبل انتهاء المهلة!");
    showToast("تم تصدير كشف المرتجع بنجاح بصيغة PDF قابلة للطباعة", "success");
}

function convertAlertToClearance() {
    document.getElementById("supplierAlertStrip").style.display = "none";
    showToast("تم تحويل صنف (أوجمنتين 1 جم) إلى البورصة الدوائية بخصم 45% لبيعه كاش!", "success");
}

function openAddModal() {
    const isAgencyBranch = CURRENT_USER.role === "agency_branch";
    const discInput = document.getElementById("addDiscountPercent");
    const discHint = document.getElementById("addDiscountBranchHint");
    const submitBtn = document.getElementById("btnAddMedicineSubmit");
    const labelDisc = document.getElementById("labelAddDiscount");

    if (isAgencyBranch) {
        if (discInput) {
            discInput.value = 35;
            discInput.disabled = true;
            discInput.style.background = "rgba(15, 23, 42, 0.7)";
            discInput.style.borderColor = "rgba(245, 158, 11, 0.4)";
        }
        if (discHint) {
            discHint.style.display = "block";
            discHint.innerHTML = `<span style="color: #fbbf24;"><i class="fa-solid fa-lock"></i> قرار إداري مركزي:</span> نسبة الخصم وسعر الطرح للبيع الخارجي تحددها الإدارة العامة للوكالة بعد مراجعة الصنف.`;
        }
        if (submitBtn) {
            submitBtn.innerHTML = `<i class="fa-solid fa-paper-plane"></i> حفظ وإحالة للإدارة لتحديد الخصم`;
        }
        if (labelDisc) {
            labelDisc.innerHTML = `نسبة الخصم المقترحة (معتمدة من الإدارة 🔒):`;
        }
    } else {
        if (discInput) {
            discInput.disabled = false;
            discInput.style.background = "";
            discInput.style.borderColor = "";
        }
        if (discHint) {
            discHint.style.display = "none";
        }
        if (submitBtn) {
            submitBtn.innerHTML = `<i class="fa-solid fa-check"></i> نشر في البورصة الدوائية`;
        }
        if (labelDisc) {
            labelDisc.innerHTML = `نسبة الخصم المعروضة (%):`;
        }
    }

    calcAddDiscountPrice();
    openModal("addMedicineModal");
}

function calcAddDiscountPrice() {
    const orig = parseFloat(document.getElementById("addOriginalPrice")?.value) || 0;
    const disc = parseFloat(document.getElementById("addDiscountPercent")?.value) || 0;
    const finalPrice = Math.round(orig * (1 - disc / 100));

    document.getElementById("addFinalPricePreview").innerText = `${finalPrice.toLocaleString()} ر.ي`;
    document.getElementById("addSavingsBadge").innerText = `توفير ${disc}%`;
}

function saveNewListing() {
    const name = document.getElementById("addDrugName").value;
    const active = document.getElementById("addActiveIng").value;
    const batch = document.getElementById("addBatch").value;
    const qty = parseInt(document.getElementById("addQuantity").value) || 10;
    const exp = document.getElementById("addExpiryDate").value || "2027-01-01";
    const orig = parseFloat(document.getElementById("addOriginalPrice").value) || 3000;
    const disc = parseFloat(document.getElementById("addDiscountPercent").value) || 35;
    const clearance = Math.round(orig * (1 - disc / 100));

    if (!name || !batch) {
        alert("يرجى ملء اسم الدواء ورقم التشغيلة");
        return;
    }

    const isBranch = CURRENT_USER.role === "agency_branch";

    const newListing = {
        id: `lst_${Date.now()}`,
        brand_name: name,
        active_ingredient: active || "غير محدد",
        manufacturer: "شركة معتمدة",
        batch_number: batch,
        quantity: qty,
        expiry_date: exp,
        days_left: 70,
        urgency: "moderate",
        original_price: orig,
        discount_percent: disc,
        clearance_price: clearance,
        pharmacy_id: CURRENT_USER.profile ? CURRENT_USER.profile.id : "pharm_01",
        status: isBranch ? "pending_clearance" : "active",
        clearance_requested: isBranch ? true : false,
        is_published: isBranch ? false : true
    };

    MOCK_LISTINGS.unshift(newListing);
    closeModal("addMedicineModal");
    renderMyListingsTable();
    renderMarketplace();

    if (isBranch) {
        showToast(`📤 تم حفظ صنف (${name}) بمخزون الفرع وإحالته للإدارة العامة لمراجعة المناقلة أو تحديد الخصم!`, "success");
    } else {
        showToast(`🚀 تم نشر صنف (${name}) بنجاح في البورصة الدوائية!`, "success");
    }
}

/**
 * 15. المودالات والإشعارات
 */
function openModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.add("active-modal");
}

function closeModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.remove("active-modal");
}

function openWithdrawModal() {
    const amount = prompt("أدخل المبلغ الذي ترغب في سحبه إلى حسابك في الكريمي المميز:", "200000");
    if (amount) {
        showToast(`تم إنشاء طلب سحب بقيمة (${parseInt(amount).toLocaleString()} ر.ي) لحساب الكريمي، ستصلك الحوالة خلال دقائق.`, "success");
    }
}

function openDepositModal() {
    alert("لإيداع رصيد بالمحفظة: يرجى التحويل إلى حساب ترياق B2B في بنك الكريمي رقم (12345678) أو محفظة ون كاش، ثم رفع رقم العملية.");
}

function showToast(message, type = "info") {
    const container = document.getElementById("toastContainer");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = "toast";
    let icon = '<i class="fa-solid fa-circle-info" style="color: var(--accent-blue);"></i>';
    if (type === "success") icon = '<i class="fa-solid fa-circle-check" style="color: var(--primary-light);"></i>';
    if (type === "warning") icon = '<i class="fa-solid fa-triangle-exclamation" style="color: var(--warning-amber);"></i>';

    toast.innerHTML = `${icon} <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(-100%)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}
