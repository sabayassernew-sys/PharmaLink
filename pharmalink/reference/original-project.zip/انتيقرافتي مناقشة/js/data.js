/**
 * ترياق B2B - قاعدة البيانات التجريبية الشاملة (Complete Mock Database)
 * تحتوي على كافة المستخدمين، الصيدليات، التراخيص، النزاعات، والفروع والصفقات
 */

// 1. المستخدمون والحسابات المتنوعة لاختبار كافة الصلاحيات
const MOCK_USERS = {
    // مدير المنصة
    admin: {
        id: "usr_admin",
        name: "إدارة منصة ترياق",
        pharmacist: "أدمن المنصة - م. هادي",
        role: "admin",
        email: "admin@tiryaq.ye",
        city: "صنعاء",
        district: "المركز الرئيسي",
        is_verified: true
    },
    // صيدلية فردية مستقلة موثقة
    independent: {
        id: "pharm_01",
        name: "صيدلية الأمل الحديثة",
        pharmacist: "د. محمد السقاف",
        role: "independent",
        email: "amal@tiryaq.ye",
        agency_id: null,
        city: "صنعاء",
        district: "السبعين",
        full_address: "شارع السبعين - أمام مستشفى السبعين للأطفال",
        phone: "777123456",
        license_no: "LIC-SN-10482",
        license_img: "license_sample_1.jpg",
        is_verified: true,
        verification_status: "approved",
        available_balance: 840000,
        locked_balance: 320000
    },
    // إدارة وكالة وسلسلة صيدليات (الفرع الرئيسي)
    agency_master: {
        id: "agency_shifa",
        name: "مجموعة صيدليات الشفاء التخصصية (الإدارة العامة)",
        pharmacist: "د. عبدالكريم طاهر (المدير التنفيذي)",
        role: "agency_master",
        email: "shifa.master@tiryaq.ye",
        agency_id: "agency_shifa",
        city: "صنعاء",
        district: "حدة",
        full_address: "شارع حدة - البرج الطبي",
        phone: "771000111",
        license_no: "LIC-SN-99001",
        is_verified: true,
        verification_status: "approved",
        branches_count: 3,
        available_balance: 3450000,
        locked_balance: 620000
    },
    // فرع وكالة (فرع حدة)
    agency_branch: {
        id: "pharm_agency_01",
        name: "صيدلية الشفاء - فرع حدة",
        pharmacist: "د. أحمد الصنعاني (مسؤول الفرع)",
        role: "agency_branch",
        email: "shifa.hadda@tiryaq.ye",
        agency_id: "agency_shifa",
        agency_name: "مجموعة صيدليات الشفاء التخصصية",
        city: "صنعاء",
        district: "حدة",
        full_address: "شارع حدة - جولة الرويشان",
        phone: "771987654",
        license_no: "LIC-SN-10920",
        is_verified: true,
        verification_status: "approved",
        available_balance: 1250000,
        locked_balance: 450000
    },
    // صيدلية جديدة قيد المراجعة للترخيص
    pending_user: {
        id: "pharm_pending_01",
        name: "صيدلية النور والشفاء الجديدة",
        pharmacist: "د. فؤاد الحمادي",
        role: "independent",
        email: "nour@tiryaq.ye",
        agency_id: null,
        city: "تعز",
        district: "الحوبان",
        full_address: "شارع الحوبان العام - جوار المستشفى الدولي",
        phone: "733445566",
        license_no: "LIC-TZ-77124",
        license_img: "license_sample_pending.jpg",
        is_verified: false,
        verification_status: "pending",
        available_balance: 0,
        locked_balance: 0
    }
};

// 2. قائمة الصيدليات العامة المسجلة بالمنصة
const MOCK_PHARMACIES = [
    MOCK_USERS.independent,
    MOCK_USERS.agency_branch,
    {
        id: "pharm_agency_02",
        name: "صيدلية الشفاء - فرع السبعين",
        pharmacist: "د. عبدالكريم طاهر",
        role: "agency_branch",
        agency_id: "agency_shifa",
        agency_name: "مجموعة صيدليات الشفاء التخصصية",
        city: "صنعاء",
        district: "السبعين",
        full_address: "حي الأصبحي - قرب المستشفى التخصصي",
        phone: "772456789",
        license_no: "LIC-SN-10921",
        is_verified: true
    },
    {
        id: "pharm_agency_03",
        name: "صيدلية الشفاء - فرع شعوب",
        pharmacist: "د. يحيى الشامي",
        role: "agency_branch",
        agency_id: "agency_shifa",
        agency_name: "مجموعة صيدليات الشفاء التخصصية",
        city: "صنعاء",
        district: "شعوب",
        full_address: "شارع هائل - تقاطع 16",
        phone: "773112233",
        license_no: "LIC-SN-10922",
        is_verified: true
    },
    {
        id: "pharm_03",
        name: "صيدلية المنارة التخصصية",
        pharmacist: "د. وسيم العدني",
        role: "independent",
        agency_id: null,
        city: "عدن",
        district: "المنصورة",
        full_address: "شارع التسعين - جولة السفينة",
        phone: "733998877",
        license_no: "LIC-AD-08412",
        is_verified: true
    },
    {
        id: "pharm_04",
        name: "صيدلية القدس المركزية",
        pharmacist: "د. صادق الشرعبي",
        role: "independent",
        agency_id: null,
        city: "صنعاء",
        district: "مذبح",
        full_address: "شارع الستين الشمالي - جوار المستشفى الجمهوري",
        phone: "770445566",
        license_no: "LIC-SN-11230",
        is_verified: true
    }
];

// 3. قائمة التراخيص المعلقة بانتظار موافقة مدير المنصة (Admin Verification Queue)
let MOCK_PENDING_LICENSES = [
    {
        id: "lic_req_01",
        pharmacy_name: "صيدلية النور والشفاء الجديدة",
        pharmacist: "د. فؤاد الحمادي",
        city: "تعز",
        district: "الحوبان",
        license_no: "LIC-TZ-77124",
        created_at: "منذ ساعتين",
        doc_type: "ترخيص مزاولة مهنة + سجل تجاري",
        status: "pending"
    },
    {
        id: "lic_req_02",
        pharmacy_name: "صيدلية النصر الحديثة",
        pharmacist: "د. رامي البعداني",
        city: "إب",
        district: "المشنة",
        license_no: "LIC-IB-55219",
        created_at: "منذ 5 ساعات",
        doc_type: "ترخيص فتح منشأة صيدلانية",
        status: "pending"
    }
];

// 4. قائمة النزاعات المالية المحالة للتحكيم (Admin Disputes Queue)
let MOCK_DISPUTES = [
    {
        id: "DISP-109",
        deal_id: "DEAL-7811",
        drug_name: "كونكور Concor 5mg (20 باكت)",
        amount: 54000,
        buyer_name: "صيدلية القدس المركزية",
        seller_name: "صيدلية السلام الكبرى",
        reason: "رقم التشغيلة المستلم مختلف عن المسجل في المنصة، والكرتون غير محكم الإغلاق.",
        status: "UNDER_REVIEW", // قيد المراجعة
        created_at: "2026-10-25 02:30 PM"
    }
];

// 5. الأدوية المعروضة في البورصة الدوائية
let MOCK_LISTINGS = [
    // أدوية معروضة من صيدليات أخرى
    {
        id: "lst_101",
        brand_name: "أوجمنتين Augmentin 1g",
        active_ingredient: "Amoxicillin + Clavulanic Acid",
        manufacturer: "GlaxoSmithKline (GSK)",
        batch_number: "BT-88421",
        quantity: 35,
        expiry_date: "2026-12-15",
        days_left: 51,
        urgency: "critical",
        supplier_deadline: "2026-11-08",
        original_price: 4200,
        discount_percent: 45,
        clearance_price: 2310,
        pharmacy_id: "pharm_agency_02",
        status: "active",
        is_published: true
    },
    {
        id: "lst_102",
        brand_name: "كلكسان Clexane 40mg",
        active_ingredient: "Enoxaparin Sodium (حقن سيولة)",
        manufacturer: "Sanofi",
        batch_number: "CX-90214",
        quantity: 20,
        expiry_date: "2027-01-20",
        days_left: 87,
        urgency: "moderate",
        supplier_deadline: "2026-11-25",
        original_price: 8500,
        discount_percent: 40,
        clearance_price: 5100,
        pharmacy_id: "pharm_03",
        status: "active",
        is_published: true
    },
    {
        id: "lst_103",
        brand_name: "لانتوس Lantus Solostar 100 IU",
        active_ingredient: "Insulin Glargine (أنسولين طويل المفعول)",
        manufacturer: "Sanofi Aventis",
        batch_number: "LT-44102",
        quantity: 15,
        expiry_date: "2027-04-10",
        days_left: 167,
        urgency: "safe",
        supplier_deadline: "2027-01-10",
        original_price: 11000,
        discount_percent: 30,
        clearance_price: 7700,
        pharmacy_id: "pharm_04",
        status: "active",
        is_published: true
    },
    {
        id: "lst_104",
        brand_name: "نيكسيوم Nexium 40mg",
        active_ingredient: "Esomeprazole (علاج حموضة وقرحة)",
        manufacturer: "AstraZeneca",
        batch_number: "NX-33108",
        quantity: 50,
        expiry_date: "2026-12-05",
        days_left: 41,
        urgency: "critical",
        supplier_deadline: "2026-11-01",
        original_price: 5800,
        discount_percent: 50,
        clearance_price: 2900,
        pharmacy_id: "pharm_agency_03",
        status: "active",
        is_published: true
    },
    {
        id: "lst_105",
        brand_name: "زينات Zinnat 500mg",
        active_ingredient: "Cefuroxime Axetil (مضاد حيوي واسع المجال)",
        manufacturer: "GSK",
        batch_number: "ZN-77120",
        quantity: 28,
        expiry_date: "2027-02-18",
        days_left: 116,
        urgency: "moderate",
        supplier_deadline: "2026-12-20",
        original_price: 6200,
        discount_percent: 35,
        clearance_price: 4030,
        pharmacy_id: "pharm_agency_02",
        status: "active",
        is_published: true
    },
    {
        id: "lst_106",
        brand_name: "كونكور Concor 5mg",
        active_ingredient: "Bisoprolol Fumarate (ضغط وقلب)",
        manufacturer: "Merck",
        batch_number: "CN-11029",
        quantity: 40,
        expiry_date: "2027-05-30",
        days_left: 217,
        urgency: "safe",
        supplier_deadline: "2027-02-15",
        original_price: 3600,
        discount_percent: 25,
        clearance_price: 2700,
        pharmacy_id: "pharm_04",
        status: "active",
        is_published: true
    },
    // ==========================================
    // 1. مخزون صيدلية الأمل الحديثة (المستقلة pharm_01)
    // ==========================================
    {
        id: "lst_amal_01",
        brand_name: "أوجمنتين Augmentin 1g",
        active_ingredient: "Amoxicillin + Clavulanate",
        manufacturer: "GlaxoSmithKline (GSK)",
        batch_number: "BT-99120",
        quantity: 25,
        expiry_date: "2026-12-10",
        days_left: 46,
        urgency: "critical",
        supplier_deadline: "2026-11-15",
        original_price: 4200,
        discount_percent: 40,
        clearance_price: 2520,
        pharmacy_id: "pharm_01",
        status: "active",
        is_published: true // معروض بالبورصة
    },
    {
        id: "lst_amal_02",
        brand_name: "بانادول إكسترا Panadol Extra",
        active_ingredient: "Paracetamol + Caffeine",
        manufacturer: "GSK",
        batch_number: "PD-44120",
        quantity: 50,
        expiry_date: "2027-01-25",
        days_left: 92,
        urgency: "moderate",
        supplier_deadline: "2026-12-25",
        original_price: 1500,
        discount_percent: 30,
        clearance_price: 1050,
        pharmacy_id: "pharm_01",
        status: "draft",
        is_published: false // مخزون محلي غير معروض
    },
    {
        id: "lst_amal_03",
        brand_name: "جلوكوفاج Glucophage 1000mg",
        active_ingredient: "Metformin HCl (منظم سكر)",
        manufacturer: "Merck Serono",
        batch_number: "GL-11082",
        quantity: 35,
        expiry_date: "2026-12-30",
        days_left: 65,
        urgency: "critical",
        supplier_deadline: "2026-11-20",
        original_price: 2800,
        discount_percent: 35,
        clearance_price: 1820,
        pharmacy_id: "pharm_01",
        status: "active",
        is_published: true
    },
    {
        id: "lst_amal_04",
        brand_name: "سيبرودار Cprodar 500mg",
        active_ingredient: "Ciprofloxacin (مضاد حيوي واسع)",
        manufacturer: "دار الدواء",
        batch_number: "CP-88319",
        quantity: 40,
        expiry_date: "2027-02-15",
        days_left: 112,
        urgency: "moderate",
        supplier_deadline: "2026-12-10",
        original_price: 2400,
        discount_percent: 25,
        clearance_price: 1800,
        pharmacy_id: "pharm_01",
        status: "draft",
        is_published: false
    },
    {
        id: "lst_amal_05",
        brand_name: "ليبيتور Lipitor 20mg",
        active_ingredient: "Atorvastatin (كوليسترول ودهون)",
        manufacturer: "Pfizer",
        batch_number: "LP-66291",
        quantity: 20,
        expiry_date: "2026-12-18",
        days_left: 54,
        urgency: "critical",
        supplier_deadline: "2026-11-10",
        original_price: 6800,
        discount_percent: 45,
        clearance_price: 3740,
        pharmacy_id: "pharm_01",
        status: "active",
        is_published: true
    },
    {
        id: "lst_amal_06",
        brand_name: "كابوتن Capoten 25mg",
        active_ingredient: "Captopril (علاج ضغط الدم)",
        manufacturer: "Bristol Myers",
        batch_number: "CP-44012",
        quantity: 30,
        expiry_date: "2027-03-30",
        days_left: 155,
        urgency: "safe",
        supplier_deadline: "2027-01-15",
        original_price: 2100,
        discount_percent: 20,
        clearance_price: 1680,
        pharmacy_id: "pharm_01",
        status: "draft",
        is_published: false
    },
    {
        id: "lst_amal_07",
        brand_name: "أموكسيل Amoxil 500mg",
        active_ingredient: "Amoxicillin (مضاد بكتيري)",
        manufacturer: "GSK",
        batch_number: "AX-55190",
        quantity: 60,
        expiry_date: "2027-01-10",
        days_left: 77,
        urgency: "moderate",
        supplier_deadline: "2026-11-30",
        original_price: 1900,
        discount_percent: 30,
        clearance_price: 1330,
        pharmacy_id: "pharm_01",
        status: "active",
        is_published: true
    },

    // ==========================================
    // 2. مخزون صيدليات الشفاء - فرع حدة (pharm_agency_01)
    // ==========================================
    {
        id: "lst_shifa_hadda_01",
        brand_name: "كلكسان Clexane 40mg",
        active_ingredient: "Enoxaparin Sodium",
        form: "حقن معبأة مسبقاً (Syringes)",
        strength: "40mg / 0.4ml",
        package_size: "باكت (2 حقنة)",
        unit: "باكت",
        manufacturer: "Sanofi",
        batch_number: "CX-88310",
        quantity: 25,
        physical_quantity: 25,
        expiry_date: "2027-01-15",
        days_left: 80,
        urgency: "moderate",
        storage_condition: "مبرّد 2-8°C",
        supplier_deadline: "2026-11-06", // مهلة مرتجع مورد تقترب بعد 6 أيام
        original_price: 8500,
        discount_percent: 35,
        clearance_price: 5525,
        pharmacy_id: "pharm_agency_01",
        status: "pending_clearance",
        clearance_requested: true, // محال للإدارة لتحديد الخصم
        is_published: false
    },
    {
        id: "lst_shifa_hadda_01_b2",
        brand_name: "كلكسان Clexane 40mg",
        active_ingredient: "Enoxaparin Sodium",
        form: "حقن معبأة مسبقاً (Syringes)",
        strength: "40mg / 0.4ml",
        package_size: "باكت (2 حقنة)",
        unit: "باكت",
        manufacturer: "Sanofi",
        batch_number: "CX-99420",
        quantity: 15,
        physical_quantity: 15,
        expiry_date: "2027-05-10",
        days_left: 191,
        urgency: "safe",
        storage_condition: "مبرّد 2-8°C",
        supplier_deadline: "2027-02-15",
        original_price: 8500,
        discount_percent: 25,
        clearance_price: 6375,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_02",
        brand_name: "أومبرازول Omeprazole 20mg",
        active_ingredient: "Omeprazole (حموضة ومعدة)",
        manufacturer: "شفاكو",
        batch_number: "OM-99214",
        quantity: 60,
        expiry_date: "2027-02-10",
        days_left: 105,
        urgency: "moderate",
        supplier_deadline: "2026-12-15",
        original_price: 1800,
        discount_percent: 30,
        clearance_price: 1260,
        pharmacy_id: "pharm_agency_01",
        status: "active",
        clearance_requested: true,
        is_published: true // معتمد ومعروض بالبورصة
    },
    {
        id: "lst_shifa_hadda_03",
        brand_name: "بانادول إكسترا Panadol Extra",
        active_ingredient: "Paracetamol + Caffeine",
        manufacturer: "GSK",
        batch_number: "PD-99210",
        quantity: 45,
        expiry_date: "2027-03-20",
        days_left: 142,
        urgency: "safe",
        supplier_deadline: "2027-01-05",
        original_price: 1500,
        discount_percent: 25,
        clearance_price: 1125,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false, // مخزون محلي بالفرع لم يُحل للإدارة بعد
        is_published: false
    },
    {
        id: "lst_shifa_hadda_04",
        brand_name: "نيكسيوم Nexium 40mg",
        active_ingredient: "Esomeprazole (علاج قرحة وحموضة)",
        manufacturer: "AstraZeneca",
        batch_number: "NX-77140",
        quantity: 30,
        expiry_date: "2026-12-20",
        days_left: 56,
        urgency: "critical",
        supplier_deadline: "2026-11-15",
        original_price: 5800,
        discount_percent: 45,
        clearance_price: 3190,
        pharmacy_id: "pharm_agency_01",
        status: "pending_clearance",
        clearance_requested: true, // محال للإدارة لتحديد الخصم
        is_published: false
    },
    {
        id: "lst_shifa_hadda_05",
        brand_name: "فنتولين بخاخ Ventolin Inhaler",
        active_ingredient: "Salbutamol (موسع قصبات وهوائي)",
        manufacturer: "GSK",
        batch_number: "VT-10920",
        quantity: 20,
        expiry_date: "2027-04-15",
        days_left: 170,
        urgency: "safe",
        supplier_deadline: "2027-01-20",
        original_price: 3400,
        discount_percent: 20,
        clearance_price: 2720,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_06",
        brand_name: "كلافوكس Clavox 1g",
        active_ingredient: "Amoxicillin + Clavulanate",
        manufacturer: "سبأ فارما",
        batch_number: "CL-55019",
        quantity: 35,
        expiry_date: "2026-12-28",
        days_left: 63,
        urgency: "critical",
        supplier_deadline: "2026-11-20",
        original_price: 3800,
        discount_percent: 40,
        clearance_price: 2280,
        pharmacy_id: "pharm_agency_01",
        status: "active",
        clearance_requested: true,
        is_published: true
    },
    {
        id: "lst_shifa_hadda_07",
        brand_name: "أنسولين لانتوس Lantus Solostar 100 IU",
        active_ingredient: "Insulin Glargine (أقلام أنسولين)",
        manufacturer: "Sanofi Aventis",
        batch_number: "LT-99214",
        quantity: 20,
        expiry_date: "2027-01-10",
        days_left: 70,
        urgency: "moderate",
        supplier_deadline: "2026-11-25",
        original_price: 11000,
        discount_percent: 30,
        clearance_price: 7700,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_08",
        brand_name: "كونكور Concor 5mg",
        active_ingredient: "Bisoprolol Fumarate (ضغط وقلب)",
        manufacturer: "Merck",
        batch_number: "CN-88219",
        quantity: 50,
        expiry_date: "2027-01-25",
        days_left: 85,
        urgency: "moderate",
        supplier_deadline: "2026-12-10",
        original_price: 3600,
        discount_percent: 25,
        clearance_price: 2700,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_09",
        brand_name: "جلوكوفاج Glucophage 1000mg",
        active_ingredient: "Metformin HCl (منظم سكر)",
        manufacturer: "Merck Serono",
        batch_number: "GL-55410",
        quantity: 40,
        expiry_date: "2027-02-05",
        days_left: 95,
        urgency: "moderate",
        supplier_deadline: "2026-12-20",
        original_price: 2800,
        discount_percent: 35,
        clearance_price: 1820,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_10",
        brand_name: "بروفين Brufen 400mg",
        active_ingredient: "Ibuprofen (مسكن ومضاد التهاب)",
        manufacturer: "Abbott",
        batch_number: "BR-22319",
        quantity: 65,
        expiry_date: "2027-02-20",
        days_left: 110,
        urgency: "moderate",
        supplier_deadline: "2027-01-05",
        original_price: 1800,
        discount_percent: 20,
        clearance_price: 1440,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_11",
        brand_name: "ليبيتور Lipitor 20mg",
        active_ingredient: "Atorvastatin (كوليسترول ودهون)",
        manufacturer: "Pfizer",
        batch_number: "LP-90114",
        quantity: 25,
        expiry_date: "2026-12-18",
        days_left: 49,
        urgency: "critical",
        supplier_deadline: "2026-11-10",
        original_price: 6800,
        discount_percent: 45,
        clearance_price: 3740,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_12",
        brand_name: "فولتارين أمبولات Voltaren 75mg",
        active_ingredient: "Diclofenac Sodium (حقن مسكنة)",
        manufacturer: "Novartis",
        batch_number: "VT-44019",
        quantity: 30,
        expiry_date: "2027-03-01",
        days_left: 120,
        urgency: "safe",
        supplier_deadline: "2027-01-15",
        original_price: 3200,
        discount_percent: 25,
        clearance_price: 2400,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_13",
        brand_name: "زينات Zinnat 500mg",
        active_ingredient: "Cefuroxime Axetil (مضاد حيوي)",
        manufacturer: "GSK",
        batch_number: "ZN-99120",
        quantity: 35,
        expiry_date: "2026-12-30",
        days_left: 62,
        urgency: "critical",
        supplier_deadline: "2026-11-20",
        original_price: 6200,
        discount_percent: 35,
        clearance_price: 4030,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_14",
        brand_name: "كابوتن Capoten 25mg",
        active_ingredient: "Captopril (علاج ضغط الدم)",
        manufacturer: "Bristol Myers",
        batch_number: "CP-77310",
        quantity: 45,
        expiry_date: "2027-03-15",
        days_left: 135,
        urgency: "safe",
        supplier_deadline: "2027-01-20",
        original_price: 2100,
        discount_percent: 20,
        clearance_price: 1680,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_15",
        brand_name: "سيبرودار Cprodar 500mg",
        active_ingredient: "Ciprofloxacin (مضاد بكتيري واسع)",
        manufacturer: "دار الدواء",
        batch_number: "CP-44910",
        quantity: 50,
        expiry_date: "2027-03-30",
        days_left: 150,
        urgency: "safe",
        supplier_deadline: "2027-01-30",
        original_price: 2400,
        discount_percent: 25,
        clearance_price: 1800,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_hadda_16",
        brand_name: "أوجمنتين Augmentin 625mg",
        active_ingredient: "Amoxicillin + Clavulanate",
        manufacturer: "GSK",
        batch_number: "AG-66102",
        quantity: 30,
        expiry_date: "2026-12-20",
        days_left: 52,
        urgency: "critical",
        supplier_deadline: "2026-11-15",
        original_price: 3400,
        discount_percent: 40,
        clearance_price: 2040,
        pharmacy_id: "pharm_agency_01",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },

    // ==========================================
    // 3. مخزون صيدليات الشفاء - فرع السبعين (pharm_agency_02)
    // ==========================================
    {
        id: "lst_shifa_sebaeen_01",
        brand_name: "أوجمنتين Augmentin 1g",
        active_ingredient: "Amoxicillin + Clavulanate",
        manufacturer: "GSK",
        batch_number: "AG-77192",
        quantity: 30,
        expiry_date: "2026-12-25",
        days_left: 58,
        urgency: "critical",
        supplier_deadline: "2026-11-12",
        original_price: 4200,
        discount_percent: 40,
        clearance_price: 2520,
        pharmacy_id: "pharm_agency_02",
        status: "pending_clearance",
        clearance_requested: true,
        is_published: false
    },
    {
        id: "lst_shifa_sebaeen_02",
        brand_name: "زينات Zinnat 500mg",
        active_ingredient: "Cefuroxime Axetil",
        manufacturer: "GSK",
        batch_number: "ZN-33109",
        quantity: 28,
        expiry_date: "2027-02-18",
        days_left: 116,
        urgency: "moderate",
        supplier_deadline: "2026-12-20",
        original_price: 6200,
        discount_percent: 35,
        clearance_price: 4030,
        pharmacy_id: "pharm_agency_02",
        status: "active",
        clearance_requested: true,
        is_published: true
    },
    {
        id: "lst_shifa_sebaeen_03",
        brand_name: "لانتوس سولوستار Lantus Solostar",
        active_ingredient: "Insulin Glargine (أنسولين)",
        manufacturer: "Sanofi",
        batch_number: "LT-88123",
        quantity: 18,
        expiry_date: "2026-12-15",
        days_left: 51,
        urgency: "critical",
        supplier_deadline: "2026-11-10",
        original_price: 11500,
        discount_percent: 40,
        clearance_price: 6900,
        pharmacy_id: "pharm_agency_02",
        status: "pending_clearance",
        clearance_requested: true,
        is_published: false
    },
    {
        id: "lst_shifa_sebaeen_04",
        brand_name: "بروفين Brufen 400mg",
        active_ingredient: "Ibuprofen (مسكن وخافض حرارة)",
        manufacturer: "Abbott",
        batch_number: "BF-66412",
        quantity: 55,
        expiry_date: "2027-03-10",
        days_left: 135,
        urgency: "safe",
        supplier_deadline: "2027-01-10",
        original_price: 1200,
        discount_percent: 25,
        clearance_price: 900,
        pharmacy_id: "pharm_agency_02",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },

    // ==========================================
    // 4. مخزون صيدليات الشفاء - فرع شعوب (pharm_agency_03)
    // ==========================================
    {
        id: "lst_shifa_shoob_01",
        brand_name: "فولتارين Voltaren 75mg Ampoules",
        active_ingredient: "Diclofenac Sodium (حقن مسكنة)",
        manufacturer: "Novartis",
        batch_number: "VT-44109",
        quantity: 40,
        expiry_date: "2027-04-10",
        days_left: 165,
        urgency: "safe",
        supplier_deadline: "2027-01-10",
        original_price: 3200,
        discount_percent: 20,
        clearance_price: 2560,
        pharmacy_id: "pharm_agency_03",
        status: "draft",
        clearance_requested: false,
        is_published: false
    },
    {
        id: "lst_shifa_shoob_02",
        brand_name: "كونكور Concor 5mg",
        active_ingredient: "Bisoprolol Fumarate (ضغط وقلب)",
        manufacturer: "Merck",
        batch_number: "CN-88410",
        quantity: 35,
        expiry_date: "2027-01-20",
        days_left: 86,
        urgency: "moderate",
        supplier_deadline: "2026-11-25",
        original_price: 3600,
        discount_percent: 30,
        clearance_price: 2520,
        pharmacy_id: "pharm_agency_03",
        status: "active",
        clearance_requested: true,
        is_published: true
    },
    {
        id: "lst_shifa_shoob_03",
        brand_name: "بلافيكس Plavix 75mg",
        active_ingredient: "Clopidogrel (مانع تجلط)",
        manufacturer: "Sanofi",
        batch_number: "PL-55102",
        quantity: 25,
        expiry_date: "2026-12-12",
        days_left: 48,
        urgency: "critical",
        supplier_deadline: "2026-11-08",
        original_price: 9200,
        discount_percent: 45,
        clearance_price: 5060,
        pharmacy_id: "pharm_agency_03",
        status: "pending_clearance",
        clearance_requested: true,
        is_published: false
    },
    {
        id: "lst_shifa_shoob_04",
        brand_name: "نيوروبيون Neurobion Ampoules",
        active_ingredient: "Vitamin B1 + B6 + B12 (أعصاب)",
        manufacturer: "Merck",
        batch_number: "NB-77290",
        quantity: 50,
        expiry_date: "2027-05-15",
        days_left: 200,
        urgency: "safe",
        supplier_deadline: "2027-02-01",
        original_price: 2600,
        discount_percent: 20,
        clearance_price: 2080,
        pharmacy_id: "pharm_agency_03",
        status: "draft",
        clearance_requested: false,
        is_published: false
    }
];

// 6. صفقات الضمان المالي الجارية
let MOCK_ESCROW_DEALS = [
    {
        id: "DEAL-8491",
        drug_name: "كلكسان Clexane 40mg (10 باكت)",
        seller_pharmacy: "صيدلية المنارة التخصصية (عدن)",
        buyer_pharmacy: "صيدلية الأمل الحديثة (صنعاء)",
        amount: 51000,
        escrow_fee: 765,
        payment_method: "محفظة ترياق الداخلية",
        status: "IN_ESCROW",
        status_text: "المبلغ محجوز بالضمان - بانتظار الشحن والتسليم",
        step: 2,
        created_at: "2026-10-24 11:30 AM"
    },
    {
        id: "DEAL-8430",
        drug_name: "أوجمنتين 1 جم (15 باكت)",
        seller_pharmacy: "صيدلية القدس المركزية",
        buyer_pharmacy: "صيدلية الأمل الحديثة",
        amount: 34650,
        escrow_fee: 520,
        payment_method: "الكريمي المميز",
        status: "SHIPPED",
        status_text: "تم وصول الشحنة - بانتظار فحصك وتأكيد الاستلام",
        step: 3,
        created_at: "2026-10-23 04:15 PM"
    }
];

// 7. تنبيهات رادار الأدوية اللحظية
let MOCK_RADAR_ALERTS = [
    {
        id: "rad_1",
        target_name: "Clexane 40mg (حقن كلكسان)",
        min_discount: 35,
        scope: "صنعاء",
        status: "active",
        matches_found: 2,
        last_alert: "اليوم 10:45 ص"
    },
    {
        id: "rad_2",
        target_name: "Lantus Solostar (أنسولين لانتوس)",
        min_discount: 30,
        scope: "كل المحافظات",
        status: "active",
        matches_found: 1,
        last_alert: "أمس 06:12 م"
    },
    {
        id: "rad_3",
        target_name: "Augmentin 1g (أوجمنتين باكتات)",
        min_discount: 40,
        scope: "صنعاء - السبعين",
        status: "active",
        matches_found: 3,
        last_alert: "منذ 3 ساعات"
    }
];

// 8. عينات كشوفات يمن سوفت (6 أصناف متكاملة مع معايير احتساب الخصومات)
const MOCK_YEMENSOFT_EXCEL_DATA = [
    {
        brand_name: "سيبرودار Cprodar 500mg",
        active_ingredient: "Ciprofloxacin (مضاد حيوي واسع)",
        manufacturer: "دار الدواء",
        batch_number: "CP-44910",
        quantity: 30,
        expiry_date: "2026-12-30",
        days_left: 65,
        original_price: 2400,
        discount_percent: 40,
        discount_reason: "أقل من 75 يوماً - خصم سيولة سريع لتفادي التلف"
    },
    {
        brand_name: "أومبرازول Omeprazole 20mg",
        active_ingredient: "Omeprazole (علاج حموضة ومعدة)",
        manufacturer: "شفاكو اليمنية",
        batch_number: "OM-11209",
        quantity: 45,
        expiry_date: "2027-01-15",
        days_left: 81,
        original_price: 1800,
        discount_percent: 35,
        discount_reason: "من 75-90 يوماً - مهلة متوسطة لتحفيز صيدليات أخرى"
    },
    {
        brand_name: "نيكسيوم Nexium 40mg",
        active_ingredient: "Esomeprazole (علاج قرحة وحموضة)",
        manufacturer: "AstraZeneca",
        batch_number: "NX-88210",
        quantity: 25,
        expiry_date: "2026-12-05",
        days_left: 40,
        original_price: 5800,
        discount_percent: 50,
        discount_reason: "أقل من 45 يوماً (منطقة حرجة) - خصم إنقاذ رأس المال"
    },
    {
        brand_name: "كلكسان Clexane 40mg",
        active_ingredient: "Enoxaparin Sodium (حقن سيولة)",
        manufacturer: "Sanofi",
        batch_number: "CX-33412",
        quantity: 20,
        expiry_date: "2027-01-20",
        days_left: 86,
        original_price: 8500,
        discount_percent: 35,
        discount_reason: "صنف تخصصي باهظ - يحتاج خصماً مشجعاً للمستشفيات"
    },
    {
        brand_name: "بروفين Brufen 400mg",
        active_ingredient: "Ibuprofen (مسكن وخافض حرارة)",
        manufacturer: "Abbott",
        batch_number: "BF-99201",
        quantity: 70,
        expiry_date: "2027-03-05",
        days_left: 130,
        original_price: 1200,
        discount_percent: 25,
        discount_reason: "دوران سريع جداً ومهلة أكثر من 4 أشهر - خصم كافٍ للتصريف"
    },
    {
        brand_name: "فولتارين Voltaren 75mg Ampoules",
        active_ingredient: "Diclofenac Sodium (حقن مسكنة)",
        manufacturer: "Novartis",
        batch_number: "VT-10492",
        quantity: 40,
        expiry_date: "2027-04-19",
        days_left: 175,
        original_price: 3200,
        discount_percent: 20,
        discount_reason: "أكثر من 5 أشهر (منطقة مريحة) - خصم تشجيعي معتدل"
    }
];

// 8. سياسات السلاسل وسجلات الحجوزات والحركات الرسمية
const MOCK_CHAIN_POLICIES = {
    agency_shifa: {
        chain_id: "agency_shifa",
        name: "مجموعة صيدليات الشفاء التخصصية",
        default_policy: "centralized", // 'centralized': اعتماد مركزي | 'branch_delegated': تفويض الفروع
        announcement_sla_hours: 48,
        reservation_sla_hours: 24,
        min_expiry_days: 30
    }
};

let MOCK_INVENTORY_RESERVATIONS = [
    {
        id: "RES-INIT-9041",
        transfer_id: "TRF-9041",
        transfer_item_id: "ITM-9041-1",
        inventory_item_id: "lst_shifa_hadda_07",
        pharmacy_id: "pharm_agency_01",
        reserved_quantity: 20,
        status: "active",
        created_at: "2026-10-30T09:30:00Z"
    },
    {
        id: "RES-INIT-9040",
        transfer_id: "TRF-9040",
        transfer_item_id: "ITM-9040-1",
        inventory_item_id: "lst_shifa_hadda_04",
        pharmacy_id: "pharm_agency_01",
        reserved_quantity: 10,
        status: "active",
        created_at: "2026-10-30T10:00:00Z"
    }
];

let MOCK_TRANSFER_DISCREPANCIES = [
    {
        id: "DISC-2026-01",
        transfer_id: "TRF-8995",
        transfer_code: "PL-TRF-2026-8995",
        from_pharmacy_id: "pharm_agency_03",
        to_pharmacy_id: "pharm_agency_01",
        item_name: "كلكسان Clexane 40mg",
        batch_number: "CX-90214",
        expected_qty: 15,
        received_qty: 13,
        discrepancy_type: "shortage",
        discrepancy_qty: 2,
        status: "OPEN", // اختلاف مفتوح يحتاج معالجة إجرائية
        reported_at: "2026-10-31T11:00:00Z",
        notes: "تم إثبات نقص 2 باكت في الاستلام الفعلي مقارنة بالسند المحرر، بانتظار تسوية الإدارة."
    }
];

// سجل المناقلات الداخلية المعتمد لمنظومة فارما لينك (PharmaLink Enterprise Transfers)
let MOCK_INTERNAL_TRANSFERS = [
    {
        id: "TRF-9040",
        transfer_code: "PL-TRF-2026-9040",
        chain_id: "agency_shifa",
        from_pharmacy_id: "pharm_agency_01",
        from_pharmacy_name: "صيدلية الشفاء - فرع حدة",
        from_pharmacist: "د. أحمد الصنعاني",
        to_pharmacy_id: "pharm_agency_02",
        to_pharmacy_name: "صيدلية الشفاء - فرع السبعين",
        to_pharmacist: "د. عبدالكريم طاهر",
        policy_applied: "centralized",
        status: "approved_and_reserved", // معتمدة ومحجوزة وجاهزة للتجهيز والشحن فوراً
        step: 2,
        reason: "توجيه إداري لتعزيز رصيد فرع السبعين بعلاج نيكسيوم",
        courier_name: null,
        courier_phone: null,
        transport_cost: 0,
        platform_fee: 0.00,
        cooling_required: false,
        notes: "تم حجز الكمية بالفرع ومعتمدة إدارياً، بانتظار تكليف الناقل وتأكيد الإرسال.",
        created_by: "د. أحمد الصنعاني (مسؤول فرع حدة)",
        created_at: "اليوم 10:00 ص",
        sender_approved_by: "د. أحمد الصنعاني",
        sender_approved_at: "اليوم 10:05 ص",
        management_approved_by: "د. عبدالكريم طاهر (الإدارة العامة)",
        management_approved_at: "اليوم 10:15 ص",
        dispatched_by: null,
        dispatched_at: null,
        received_by: null,
        received_at: null,
        drug_name: "نيكسيوم Nexium 40mg",
        active_ingredient: "Esomeprazole (علاج قرحة وحموضة)",
        batch_number: "NX-77140",
        expiry_date: "2026-12-20",
        days_left: 56,
        quantity: 10,
        estimated_value: 58000,
        items: [
            {
                id: "ITM-9040-1",
                transfer_id: "TRF-9040",
                inventory_item_id: "lst_shifa_hadda_04",
                drug_name_snapshot: "نيكسيوم Nexium 40mg",
                batch_snapshot: "NX-77140",
                expiry_snapshot: "2026-12-20",
                unit_snapshot: "باكت",
                quantity_requested: 10,
                quantity_sent: 0,
                quantity_accepted: 0,
                quantity_rejected: 0,
                quantity_missing: 0
            }
        ],
        history: [
            { action: "CREATED", actor: "د. أحمد الصنعاني", timestamp: "2026-10-30 10:00", note: "طلب مناقلة" },
            { action: "SENDER_ALLOCATION_APPROVED", actor: "د. أحمد الصنعاني", timestamp: "2026-10-30 10:05", note: "تم حجز 10 باكت" },
            { action: "MANAGEMENT_APPROVED", actor: "د. عبدالكريم طاهر", timestamp: "2026-10-30 10:15", note: "معتمد وجاهز للتجهيز والإرسال" }
        ]
    },
    {
        id: "TRF-9041",
        transfer_code: "PL-TRF-2026-9041",
        chain_id: "agency_shifa",
        from_pharmacy_id: "pharm_agency_01",
        from_pharmacy_name: "صيدلية الشفاء - فرع حدة",
        from_pharmacist: "د. أحمد الصنعاني",
        to_pharmacy_id: "pharm_agency_02",
        to_pharmacy_name: "صيدلية الشفاء - فرع السبعين",
        to_pharmacist: "د. عبدالكريم طاهر",
        policy_applied: "centralized",
        status: "pending_management_approval", // ينتظر موافقة الإدارة العامة بعد حجز الفرع
        step: 2,
        reason: "ركود الصنف في فرع حدة + طلب متزايد من مرضى عيادة السكر في السبعين",
        courier_name: "صالح ناصر العماري (مسؤول نقل معتمد)",
        courier_phone: "770123987",
        transport_cost: 1500, // تكلفة النقل مستقلة
        platform_fee: 0.00,   // عمولة المنصة صفر
        cooling_required: true,
        notes: "ضرورة النقل في صندوق التبريد (درجة حرارة 2-8 مئوية) وتسليمها للمناوب.",
        created_by: "د. أحمد الصنعاني (مسؤول فرع حدة)",
        created_at: "اليوم 09:30 ص",
        sender_approved_by: "د. أحمد الصنعاني",
        sender_approved_at: "اليوم 09:35 ص",
        management_approved_by: null,
        management_approved_at: null,
        dispatched_by: null,
        dispatched_at: null,
        received_by: null,
        received_at: null,
        // توافق مع العرض المباشر
        drug_name: "أنسولين لانتوس Lantus Solostar 100 IU",
        active_ingredient: "Insulin Glargine (أقلام أنسولين)",
        batch_number: "LT-99214",
        expiry_date: "2027-01-10",
        days_left: 70,
        quantity: 20,
        estimated_value: 154000,
        items: [
            {
                id: "ITM-9041-1",
                transfer_id: "TRF-9041",
                inventory_item_id: "lst_shifa_hadda_07",
                drug_name_snapshot: "أنسولين لانتوس Lantus Solostar 100 IU",
                batch_snapshot: "LT-99214",
                expiry_snapshot: "2027-01-10",
                unit_snapshot: "باكت",
                quantity_requested: 20,
                quantity_sent: 0,
                quantity_accepted: 0,
                quantity_rejected: 0,
                quantity_missing: 0
            }
        ],
        history: [
            { action: "CREATED", actor: "د. أحمد الصنعاني", timestamp: "2026-10-30 09:30", note: "طلب مناقلة لتغطية نقص السبعين" },
            { action: "SENDER_ALLOCATION_APPROVED", actor: "د. أحمد الصنعاني", timestamp: "2026-10-30 09:35", note: "تخصيص وحجز 20 باكت، بانتظار اعتماد الإدارة" }
        ]
    },
    {
        id: "TRF-8995",
        transfer_code: "PL-TRF-2026-8995",
        chain_id: "agency_shifa",
        from_pharmacy_id: "pharm_agency_03",
        from_pharmacy_name: "صيدلية الشفاء - فرع شعوب",
        from_pharmacist: "د. يحيى الشامي",
        to_pharmacy_id: "pharm_agency_01",
        to_pharmacy_name: "صيدلية الشفاء - فرع حدة",
        to_pharmacist: "د. أحمد الصنعاني",
        policy_applied: "centralized",
        status: "in_transit", // قيد النقل مع الناقل بعد استهلاك الحجز وصرف المخزون
        step: 3,
        reason: "توجيه إداري لتعزيز مخزون فرع حدة لموقعه الحيوي بالقرب من المراكز الطبية",
        courier_name: "محمد هزاع الوصابي (سائق الحركة)",
        courier_phone: "771556677",
        transport_cost: 2000,
        platform_fee: 0.00,
        cooling_required: false,
        notes: "تم استلام الشحنة من فرع شعوب وجاري التوجه بها لفرع حدة.",
        created_by: "الإدارة العامة (د. عبدالكريم طاهر)",
        created_at: "أمس 04:15 م",
        sender_approved_by: "د. يحيى الشامي",
        sender_approved_at: "أمس 04:30 م",
        management_approved_by: "د. عبدالكريم طاهر",
        management_approved_at: "أمس 05:00 م",
        dispatched_by: "د. يحيى الشامي",
        dispatched_at: "أمس 05:30 م",
        received_by: null,
        received_at: null,
        drug_name: "كلكسان Clexane 40mg",
        active_ingredient: "Enoxaparin Sodium (حقن سيولة)",
        batch_number: "CX-90214",
        expiry_date: "2027-01-20",
        days_left: 85,
        quantity: 15,
        estimated_value: 127500,
        items: [
            {
                id: "ITM-8995-1",
                transfer_id: "TRF-8995",
                inventory_item_id: "lst_102",
                drug_name_snapshot: "كلكسان Clexane 40mg",
                batch_snapshot: "CX-90214",
                expiry_snapshot: "2027-01-20",
                unit_snapshot: "باكت",
                quantity_requested: 15,
                quantity_sent: 15,
                quantity_accepted: 0,
                quantity_rejected: 0,
                quantity_missing: 0
            }
        ],
        history: [
            { action: "DISPATCHED", actor: "د. يحيى الشامي", timestamp: "أمس 05:30 م", note: "صرف المخزون وتأكيد الخروج مع السائق محمد هزاع" }
        ]
    },
    {
        id: "TRF-8720",
        transfer_code: "PL-TRF-2026-8720",
        chain_id: "agency_shifa",
        from_pharmacy_id: "pharm_agency_01",
        from_pharmacy_name: "صيدلية الشفاء - فرع حدة",
        from_pharmacist: "د. أحمد الصنعاني",
        to_pharmacy_id: "pharm_agency_02",
        to_pharmacy_name: "صيدلية الشفاء - فرع السبعين",
        to_pharmacist: "د. عبدالكريم طاهر",
        policy_applied: "centralized",
        status: "completed",
        step: 4,
        reason: "قرب انتهاء الصلاحية وتصريف الصنف في الفرع الأعلى مبيعاً",
        courier_name: "فؤاد الريمي (سائق معتمد)",
        courier_phone: "770123987",
        transport_cost: 1000,
        platform_fee: 0.00,
        cooling_required: false,
        notes: "تم فحص الباتش ومطابقة الكميات بنجاح واستلامها كاملة.",
        created_by: "د. أحمد الصنعاني",
        created_at: "2026-10-22",
        sender_approved_by: "د. أحمد الصنعاني",
        sender_approved_at: "2026-10-22",
        management_approved_by: "د. عبدالكريم طاهر",
        management_approved_at: "2026-10-22",
        dispatched_by: "د. أحمد الصنعاني",
        dispatched_at: "2026-10-22",
        received_by: "د. عبدالكريم طاهر",
        received_at: "2026-10-23",
        drug_name: "أوجمنتين Augmentin 1g",
        active_ingredient: "Amoxicillin + Clavulanic Acid",
        batch_number: "BT-88421",
        expiry_date: "2026-12-15",
        days_left: 50,
        quantity: 30,
        estimated_value: 126000,
        items: [
            {
                id: "ITM-8720-1",
                transfer_id: "TRF-8720",
                inventory_item_id: "lst_101",
                drug_name_snapshot: "أوجمنتين Augmentin 1g",
                batch_snapshot: "BT-88421",
                expiry_snapshot: "2026-12-15",
                unit_snapshot: "باكت",
                quantity_requested: 30,
                quantity_sent: 30,
                quantity_accepted: 30,
                quantity_rejected: 0,
                quantity_missing: 0
            }
        ],
        history: [
            { action: "RECEIVED", actor: "د. عبدالكريم طاهر", timestamp: "2026-10-23", note: "استلام كامل ومطابقة 100%" }
        ]
    }
];

// 9. ساحة التبادل والتكافل الداخلي بين أفرع الوكالة (فوائض ونواقص الفروع مع مهلة 48 ساعة)
let MOCK_AGENCY_EXCHANGE_POSTS = [
    {
        id: "POST-101",
        type: "SURPLUS", // فائض راكد للمناقلة
        drug_name: "كلكسان Clexane 40mg (حقن سيولة)",
        active_ingredient: "Enoxaparin Sodium",
        batch_number: "CX-90214",
        expiry_date: "2027-01-20",
        days_left: 85,
        quantity: 20,
        original_price: 8500,
        branch_id: "pharm_agency_01",
        branch_name: "صيدلية الشفاء - فرع حدة",
        pharmacist: "د. أحمد الصنعاني",
        phone: "771987654",
        created_at: "منذ 14 ساعة",
        hours_elapsed: 14,
        sla_hours: 48,
        status: "ACTIVE", // نشط في ساحة التبادل الداخلي
        urgency: "moderate",
        notes: "دواء راكد بالفرع ولا يوجد مرضى له حالياً في حدة، متاح لأي فرع شقيق يحتاجه مجاناً بنقل عهدة فوري."
    },
    {
        id: "POST-102",
        type: "SURPLUS", // فائض راكد للمناقلة انتهت مهلته الداخلية
        drug_name: "أوجمنتين Augmentin 1g",
        active_ingredient: "Amoxicillin + Clavulanic Acid",
        batch_number: "BT-88421",
        expiry_date: "2026-12-15",
        days_left: 48,
        quantity: 35,
        original_price: 4200,
        branch_id: "pharm_agency_03",
        branch_name: "صيدلية الشفاء - فرع شعوب",
        pharmacist: "د. يحيى الشامي",
        phone: "773112233",
        created_at: "منذ 49 ساعة (انتهت المهلة الداخلية)",
        hours_elapsed: 49,
        sla_hours: 48,
        status: "READY_FOR_ESCALATION", // لم يستجب أي فرع - جاهز للإحالة للإدارة لتحديد الخصم والبورصة
        urgency: "critical",
        notes: "تم عرضه لمدة 48 ساعة داخلياً ولم يستجب أي فرع لوجود وفرة لديهم. نوصي برفعه للإدارة لتحديد نسبة الخصم وبيعه بالبورصة الخارجية."
    },
    {
        id: "POST-103",
        type: "SHORTAGE", // طلب نقص عاجل
        drug_name: "أنسولين لانتوس Lantus Solostar 100 IU",
        active_ingredient: "Insulin Glargine (أقلام أنسولين)",
        batch_number: "أي تشغيلة سارية",
        expiry_date: "صلاحية لا تقل عن 3 أشهر",
        days_left: 90,
        quantity: 15,
        original_price: 7500,
        branch_id: "pharm_agency_02",
        branch_name: "صيدلية الشفاء - فرع السبعين",
        pharmacist: "د. عبدالكريم طاهر",
        phone: "772456789",
        created_at: "منذ ساعتين",
        hours_elapsed: 2,
        sla_hours: 48,
        status: "ACTIVE", // نشط بانتظار مساعدة فرع شقيق
        urgency: "critical",
        notes: "لدينا عجز حاد بسبب وصفات عيادة السكر بالمستشفى، نطلب من أي فرع لديه فائض تزويدنا بـ 15 باكت عاجلاً."
    },
    {
        id: "POST-104",
        type: "SHORTAGE", // طلب نقص تم التكافل وتلبيته
        drug_name: "فولتارين Voltaren 75mg Ampoules",
        active_ingredient: "Diclofenac Sodium",
        batch_number: "VT-10492",
        expiry_date: "2027-04-19",
        days_left: 175,
        quantity: 25,
        original_price: 3200,
        branch_id: "pharm_agency_01",
        branch_name: "صيدلية الشفاء - فرع حدة",
        pharmacist: "د. أحمد الصنعاني",
        phone: "771987654",
        created_at: "أمس",
        hours_elapsed: 24,
        sla_hours: 48,
        status: "FULFILLED", // تم التكافل الداخلي
        fulfilled_by: "صيدلية الشفاء - فرع السبعين",
        urgency: "normal",
        notes: "تمت تلبية الطلب بنجاح وتوفيره من فرع السبعين عبر أمر مناقلة رسمي."
    }
];

// 10. تهيئة ومزامنة محرك العمليات الذري (TransferService Initialization)
(function syncPharmaLinkData() {
    if (typeof MOCK_LISTINGS !== "undefined") {
        MOCK_LISTINGS.forEach(item => {
            if (typeof item.physical_quantity === "undefined") {
                item.physical_quantity = item.quantity;
            }
            if (typeof item.quarantine_quantity === "undefined") {
                item.quarantine_quantity = 0;
            }
            item.unit = item.unit || "باكت";
        });
    }

    if (typeof TransferService !== "undefined" && TransferService.initDatabase) {
        const invMap = {};
        (MOCK_LISTINGS || []).forEach(it => { invMap[it.id] = it; });

        const pharmMap = {};
        (MOCK_PHARMACIES || []).forEach(p => { pharmMap[p.id] = p; });

        TransferService.initDatabase({
            chains: MOCK_CHAIN_POLICIES,
            pharmacies: pharmMap,
            users: MOCK_USERS,
            inventory: invMap,
            reservations: MOCK_INVENTORY_RESERVATIONS,
            transfers: MOCK_INTERNAL_TRANSFERS,
            discrepancies: MOCK_TRANSFER_DISCREPANCIES,
            movements: MOCK_INVENTORY_MOVEMENTS
        });
    }
})();

// دالة احتساب الرصيد المتاح رياضياً (المتاح = الفعلي - الحجوزات النشطة)
function getCalculatedAvailableStock(itemId) {
    if (typeof TransferService !== "undefined" && TransferService.getItemAvailability) {
        const avail = TransferService.getItemAvailability(itemId);
        if (avail) return avail.availableQuantity;
    }
    const item = (MOCK_LISTINGS || []).find(l => l.id === itemId);
    if (!item) return 0;
    const activeRes = (MOCK_INVENTORY_RESERVATIONS || [])
        .filter(r => r.inventory_item_id === itemId && r.status === 'active')
        .reduce((sum, r) => sum + r.reserved_quantity, 0);
    return Math.max(0, (item.physical_quantity || item.quantity) - activeRes);
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        MOCK_USERS,
        MOCK_PHARMACIES,
        MOCK_PENDING_LICENSES,
        MOCK_DISPUTES,
        MOCK_LISTINGS,
        MOCK_ESCROW_DEALS,
        MOCK_RADAR_ALERTS,
        MOCK_YEMENSOFT_EXCEL_DATA,
        MOCK_CHAIN_POLICIES,
        MOCK_INVENTORY_RESERVATIONS,
        MOCK_TRANSFER_DISCREPANCIES,
        MOCK_INTERNAL_TRANSFERS,
        MOCK_AGENCY_EXCHANGE_POSTS,
        getCalculatedAvailableStock
    };
}


