-- ==============================================================================
-- PharmaLink - Enterprise Internal Transfer System Migration
-- Schema, Tables, Constraints, RLS Policies, and Atomic RPC Functions
-- ==============================================================================

-- 1. ENUMS & EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

DO $$ BEGIN
    CREATE TYPE transfer_status_enum AS ENUM (
        'draft',
        'pending_counterpart_approval',
        'pending_management_approval',
        'approved_and_reserved',
        'in_preparation',
        'in_transit',
        'needs_discrepancy_resolution',
        'completed',
        'rejected',
        'cancelled',
        'expired'
    );
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
    CREATE TYPE reservation_status_enum AS ENUM ('active', 'consumed', 'released');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
    CREATE TYPE movement_type_enum AS ENUM (
        'initial_import',
        'reservation_held',
        'reservation_released',
        'dispatch_deduction',
        'receipt_accepted_addition',
        'receipt_quarantine_addition',
        'adjustment_reconciliation'
    );
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
    CREATE TYPE discrepancy_type_enum AS ENUM (
        'rejected_damaged',
        'missing_investigation',
        'surplus_unauthorized'
    );
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
    CREATE TYPE chain_policy_enum AS ENUM ('centralized', 'branch_delegated');
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- 2. CHAINS & PHARMACIES
CREATE TABLE IF NOT EXISTS chains (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    default_policy chain_policy_enum NOT NULL DEFAULT 'centralized',
    announcement_sla_hours INT NOT NULL DEFAULT 48,
    reservation_sla_hours INT NOT NULL DEFAULT 24,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pharmacies (
    id VARCHAR(64) PRIMARY KEY,
    chain_id VARCHAR(64) REFERENCES chains(id) ON DELETE RESTRICT,
    name VARCHAR(255) NOT NULL,
    pharmacist_name VARCHAR(255) NOT NULL,
    phone VARCHAR(32),
    city VARCHAR(64) NOT NULL,
    district VARCHAR(64),
    full_address TEXT,
    license_no VARCHAR(64),
    is_verified BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_profiles (
    id UUID PRIMARY KEY, -- maps to auth.uid()
    chain_id VARCHAR(64) REFERENCES chains(id) ON DELETE RESTRICT,
    pharmacy_id VARCHAR(64) REFERENCES pharmacies(id) ON DELETE SET NULL,
    full_name VARCHAR(255) NOT NULL,
    role VARCHAR(32) NOT NULL CHECK (role IN ('agency_master', 'agency_branch', 'admin', 'independent')),
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(32),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. INVENTORY & BATCHES
CREATE TABLE IF NOT EXISTS inventory_items (
    id VARCHAR(64) PRIMARY KEY,
    pharmacy_id VARCHAR(64) NOT NULL REFERENCES pharmacies(id) ON DELETE RESTRICT,
    brand_name VARCHAR(255) NOT NULL,
    scientific_name VARCHAR(255),
    form VARCHAR(64) NOT NULL DEFAULT 'باكت',
    concentration VARCHAR(64),
    package_size VARCHAR(64),
    unit VARCHAR(32) NOT NULL DEFAULT 'باكت',
    batch_number VARCHAR(64) NOT NULL,
    expiry_date DATE NOT NULL,
    physical_quantity INT NOT NULL DEFAULT 0 CHECK (physical_quantity >= 0),
    quarantine_quantity INT NOT NULL DEFAULT 0 CHECK (quarantine_quantity >= 0),
    original_price NUMERIC(12, 2) NOT NULL DEFAULT 0,
    is_cold_chain BOOLEAN NOT NULL DEFAULT false,
    is_controlled BOOLEAN NOT NULL DEFAULT false,
    min_expiry_days INT NOT NULL DEFAULT 30,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_pharmacy_batch UNIQUE (pharmacy_id, brand_name, batch_number)
);

-- 4. INTERNAL ANNOUNCEMENTS (Surplus / Shortage)
CREATE TABLE IF NOT EXISTS internal_announcements (
    id VARCHAR(64) PRIMARY KEY,
    chain_id VARCHAR(64) NOT NULL REFERENCES chains(id) ON DELETE CASCADE,
    pharmacy_id VARCHAR(64) NOT NULL REFERENCES pharmacies(id) ON DELETE CASCADE,
    type VARCHAR(16) NOT NULL CHECK (type IN ('SURPLUS', 'SHORTAGE')),
    drug_name VARCHAR(255) NOT NULL,
    batch_number VARCHAR(64),
    expiry_date DATE,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit VARCHAR(32) NOT NULL DEFAULT 'باكت',
    sla_hours INT NOT NULL DEFAULT 48,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'MATCHED', 'EXPIRED', 'ARCHIVED')),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

-- 5. TRANSFERS & LINE ITEMS
CREATE TABLE IF NOT EXISTS internal_transfers (
    id VARCHAR(64) PRIMARY KEY,
    transfer_code VARCHAR(64) UNIQUE NOT NULL,
    chain_id VARCHAR(64) NOT NULL REFERENCES chains(id) ON DELETE RESTRICT,
    from_pharmacy_id VARCHAR(64) NOT NULL REFERENCES pharmacies(id) ON DELETE RESTRICT,
    to_pharmacy_id VARCHAR(64) NOT NULL REFERENCES pharmacies(id) ON DELETE RESTRICT,
    policy_applied chain_policy_enum NOT NULL,
    status transfer_status_enum NOT NULL DEFAULT 'draft',
    idempotency_key VARCHAR(128) UNIQUE,
    courier_name VARCHAR(128),
    courier_phone VARCHAR(32),
    transport_cost NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    platform_fee NUMERIC(10, 2) NOT NULL DEFAULT 0.00 CHECK (platform_fee = 0.00),
    notes TEXT,
    sender_approved_by VARCHAR(255),
    sender_approved_at TIMESTAMPTZ,
    management_approved_by VARCHAR(255),
    management_approved_at TIMESTAMPTZ,
    dispatched_by VARCHAR(255),
    dispatched_at TIMESTAMPTZ,
    received_by VARCHAR(255),
    received_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_different_branches CHECK (from_pharmacy_id <> to_pharmacy_id)
);

CREATE TABLE IF NOT EXISTS transfer_items (
    id VARCHAR(64) PRIMARY KEY,
    transfer_id VARCHAR(64) NOT NULL REFERENCES internal_transfers(id) ON DELETE CASCADE,
    inventory_item_id VARCHAR(64) NOT NULL REFERENCES inventory_items(id) ON DELETE RESTRICT,
    drug_name_snapshot VARCHAR(255) NOT NULL,
    batch_snapshot VARCHAR(64) NOT NULL,
    expiry_snapshot DATE NOT NULL,
    unit_snapshot VARCHAR(32) NOT NULL,
    quantity_requested INT NOT NULL CHECK (quantity_requested > 0),
    quantity_sent INT NOT NULL DEFAULT 0 CHECK (quantity_sent >= 0),
    quantity_accepted INT NOT NULL DEFAULT 0 CHECK (quantity_accepted >= 0),
    quantity_rejected INT NOT NULL DEFAULT 0 CHECK (quantity_rejected >= 0),
    quantity_missing INT NOT NULL DEFAULT 0 CHECK (quantity_missing >= 0),
    CONSTRAINT chk_sent_balance CHECK (
        quantity_sent = 0 OR quantity_sent = (quantity_accepted + quantity_rejected + quantity_missing)
    )
);

-- 6. INVENTORY RESERVATIONS
CREATE TABLE IF NOT EXISTS inventory_reservations (
    id VARCHAR(64) PRIMARY KEY,
    transfer_id VARCHAR(64) NOT NULL REFERENCES internal_transfers(id) ON DELETE CASCADE,
    transfer_item_id VARCHAR(64) NOT NULL REFERENCES transfer_items(id) ON DELETE CASCADE,
    inventory_item_id VARCHAR(64) NOT NULL REFERENCES inventory_items(id) ON DELETE RESTRICT,
    pharmacy_id VARCHAR(64) NOT NULL REFERENCES pharmacies(id) ON DELETE RESTRICT,
    reserved_quantity INT NOT NULL CHECK (reserved_quantity > 0),
    status reservation_status_enum NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    consumed_at TIMESTAMPTZ,
    released_at TIMESTAMPTZ
);

-- 7. DISCREPANCIES & RETURNS
CREATE TABLE IF NOT EXISTS transfer_discrepancies (
    id VARCHAR(64) PRIMARY KEY,
    transfer_id VARCHAR(64) NOT NULL REFERENCES internal_transfers(id) ON DELETE CASCADE,
    transfer_item_id VARCHAR(64) NOT NULL REFERENCES transfer_items(id) ON DELETE CASCADE,
    discrepancy_type discrepancy_type_enum NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    reason TEXT NOT NULL,
    notes TEXT,
    resolution_status VARCHAR(32) NOT NULL DEFAULT 'pending_investigation'
        CHECK (resolution_status IN ('pending_investigation', 'returned_to_sender', 'written_off_damaged', 'settled_accepted')),
    financial_claim_status VARCHAR(32) NOT NULL DEFAULT 'unassigned'
        CHECK (financial_claim_status IN ('unassigned', 'billed_to_carrier', 'absorbed_by_chain', 'waived')),
    resolved_by VARCHAR(255),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transfer_returns (
    id VARCHAR(64) PRIMARY KEY,
    transfer_id VARCHAR(64) NOT NULL REFERENCES internal_transfers(id) ON DELETE CASCADE,
    discrepancy_id VARCHAR(64) NOT NULL REFERENCES transfer_discrepancies(id) ON DELETE RESTRICT,
    from_pharmacy_id VARCHAR(64) NOT NULL REFERENCES pharmacies(id) ON DELETE RESTRICT,
    to_pharmacy_id VARCHAR(64) NOT NULL REFERENCES pharmacies(id) ON DELETE RESTRICT,
    quantity INT NOT NULL CHECK (quantity > 0),
    status VARCHAR(32) NOT NULL DEFAULT 'in_return_transit' CHECK (status IN ('in_return_transit', 'received_by_original_sender')),
    dispatched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    received_at TIMESTAMPTZ
);

-- 8. IMMUTABLE INVENTORY LEDGER (Audit Trail)
CREATE TABLE IF NOT EXISTS inventory_movements (
    id VARCHAR(64) PRIMARY KEY,
    inventory_item_id VARCHAR(64) NOT NULL REFERENCES inventory_items(id) ON DELETE RESTRICT,
    pharmacy_id VARCHAR(64) NOT NULL REFERENCES pharmacies(id) ON DELETE RESTRICT,
    transfer_id VARCHAR(64) REFERENCES internal_transfers(id) ON DELETE SET NULL,
    movement_type movement_type_enum NOT NULL,
    delta_physical INT NOT NULL DEFAULT 0,
    delta_quarantine INT NOT NULL DEFAULT 0,
    balance_after_physical INT NOT NULL CHECK (balance_after_physical >= 0),
    balance_after_quarantine INT NOT NULL CHECK (balance_after_quarantine >= 0),
    actor_id VARCHAR(255) NOT NULL,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ==============================================================================
-- 9. COMPUTED AVAILABLE QUANTITY VIEW / FUNCTION
-- Available = Physical - SUM(Active Reservations)
-- ==============================================================================
CREATE OR REPLACE VIEW v_inventory_availability AS
SELECT 
    i.id AS inventory_item_id,
    i.pharmacy_id,
    i.brand_name,
    i.batch_number,
    i.expiry_date,
    i.physical_quantity,
    i.quarantine_quantity,
    COALESCE(SUM(r.reserved_quantity) FILTER (WHERE r.status = 'active'), 0)::INT AS total_active_reserved,
    (i.physical_quantity - COALESCE(SUM(r.reserved_quantity) FILTER (WHERE r.status = 'active'), 0))::INT AS available_quantity
FROM inventory_items i
LEFT JOIN inventory_reservations r ON i.id = r.inventory_item_id
GROUP BY i.id, i.pharmacy_id, i.brand_name, i.batch_number, i.expiry_date, i.physical_quantity, i.quarantine_quantity;

-- ==============================================================================
-- 10. ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================
ALTER TABLE chains ENABLE ROW LEVEL SECURITY;
ALTER TABLE pharmacies ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE internal_announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE internal_transfers ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfer_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfer_discrepancies ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_movements ENABLE ROW LEVEL SECURITY;

-- Helper function to get current user profile
CREATE OR REPLACE FUNCTION current_user_profile()
RETURNS TABLE (chain_id VARCHAR(64), pharmacy_id VARCHAR(64), role VARCHAR(32)) AS $$
    SELECT chain_id, pharmacy_id, role FROM user_profiles WHERE id = auth.uid();
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- Internal Transfers Policy:
-- agency_master: see all in chain
-- agency_branch: see only where pharmacy_id is sender or receiver
CREATE POLICY transfers_chain_isolation ON internal_transfers
    FOR ALL
    USING (
        chain_id IN (SELECT chain_id FROM user_profiles WHERE id = auth.uid())
        AND (
            (SELECT role FROM user_profiles WHERE id = auth.uid()) = 'agency_master'
            OR from_pharmacy_id = (SELECT pharmacy_id FROM user_profiles WHERE id = auth.uid())
            OR to_pharmacy_id = (SELECT pharmacy_id FROM user_profiles WHERE id = auth.uid())
        )
    );

-- Inventory Items Policy:
-- Branch can only update its own inventory; master can view all in chain
CREATE POLICY inventory_branch_isolation ON inventory_items
    FOR SELECT
    USING (
        pharmacy_id IN (
            SELECT p.id FROM pharmacies p 
            JOIN user_profiles u ON p.chain_id = u.chain_id 
            WHERE u.id = auth.uid()
        )
    );

CREATE POLICY inventory_branch_modify ON inventory_items
    FOR ALL
    USING (
        pharmacy_id = (SELECT pharmacy_id FROM user_profiles WHERE id = auth.uid())
    );

-- ==============================================================================
-- 11. ATOMIC RPC TRANSACTIONS (WITH ROW LOCKS FOR UPDATE & IDEMPOTENCY)
-- ==============================================================================

-- RPC 1: SENDER APPROVAL & ATOMIC RESERVATION
CREATE OR REPLACE FUNCTION rpc_approve_and_reserve_transfer(
    p_transfer_id VARCHAR(64),
    p_actor_name VARCHAR(255),
    p_actor_pharmacy_id VARCHAR(64),
    p_idempotency_key VARCHAR(128)
)
RETURNS JSONB AS $$
DECLARE
    v_transfer internal_transfers%ROWTYPE;
    v_item transfer_items%ROWTYPE;
    v_inv inventory_items%ROWTYPE;
    v_active_reserved INT;
    v_available INT;
    v_new_status transfer_status_enum;
BEGIN
    -- Idempotency check
    SELECT * INTO v_transfer FROM internal_transfers WHERE id = p_transfer_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Transfer % not found', p_transfer_id;
    END IF;

    IF v_transfer.from_pharmacy_id <> p_actor_pharmacy_id THEN
        RAISE EXCEPTION 'Unauthorized: only sender branch can approve allocation';
    END IF;

    IF v_transfer.status = 'approved_and_reserved' OR v_transfer.status = 'pending_management_approval' THEN
        RETURN jsonb_build_object('success', true, 'message', 'Already approved', 'status', v_transfer.status);
    END IF;

    -- Verify and reserve each line item
    FOR v_item IN SELECT * FROM transfer_items WHERE transfer_id = p_transfer_id LOOP
        SELECT * INTO v_inv FROM inventory_items WHERE id = v_item.inventory_item_id FOR UPDATE;
        
        -- Calculate current active reservations
        SELECT COALESCE(SUM(reserved_quantity), 0) INTO v_active_reserved
        FROM inventory_reservations
        WHERE inventory_item_id = v_item.inventory_item_id AND status = 'active';

        v_available := v_inv.physical_quantity - v_active_reserved;

        IF v_available < v_item.quantity_requested THEN
            RAISE EXCEPTION 'Insufficient stock for % (Batch %). Available: %, Requested: %',
                v_item.drug_name_snapshot, v_item.batch_snapshot, v_available, v_item.quantity_requested;
        END IF;

        -- Create active reservation
        INSERT INTO inventory_reservations (
            id, transfer_id, transfer_item_id, inventory_item_id, pharmacy_id, reserved_quantity, status
        ) VALUES (
            'RES-' || substr(md5(random()::text), 1, 12),
            p_transfer_id,
            v_item.id,
            v_item.inventory_item_id,
            v_transfer.from_pharmacy_id,
            v_item.quantity_requested,
            'active'
        );

        -- Ledger entry for reservation
        INSERT INTO inventory_movements (
            id, inventory_item_id, pharmacy_id, transfer_id, movement_type,
            delta_physical, delta_quarantine, balance_after_physical, balance_after_quarantine,
            actor_id, notes
        ) VALUES (
            'MOV-' || substr(md5(random()::text), 1, 12),
            v_item.inventory_item_id,
            v_transfer.from_pharmacy_id,
            p_transfer_id,
            'reservation_held',
            0, 0, v_inv.physical_quantity, v_inv.quarantine_quantity,
            p_actor_name,
            'Reservation held for transfer ' || v_transfer.transfer_code
        );
    END LOOP;

    -- Determine next status based on chain policy
    IF v_transfer.policy_applied = 'centralized' AND v_transfer.management_approved_at IS NULL THEN
        v_new_status := 'pending_management_approval';
    ELSE
        v_new_status := 'approved_and_reserved';
    END IF;

    UPDATE internal_transfers SET
        status = v_new_status,
        sender_approved_by = p_actor_name,
        sender_approved_at = NOW(),
        updated_at = NOW()
    WHERE id = p_transfer_id;

    RETURN jsonb_build_object('success', true, 'status', v_new_status);
END;
$$ LANGUAGE plpgsql;

-- RPC 2: DISPATCH TRANSFER (RECORDS DISPATCHING USER & TIME, CONSUMES RESERVATION & DEDUCTS PHYSICAL STOCK ONCE)
-- Note: PharmaLink does NOT manage delivery. Branches arrange transport externally.
CREATE OR REPLACE FUNCTION rpc_dispatch_transfer(
    p_transfer_id VARCHAR(64),
    p_actor_name VARCHAR(255),
    p_actor_pharmacy_id VARCHAR(64),
    p_notes TEXT DEFAULT NULL,
    p_idempotency_key VARCHAR(128) DEFAULT NULL,
    -- Legacy optional parameters preserved for historical schema compatibility:
    p_courier_name VARCHAR(128) DEFAULT NULL,
    p_courier_phone VARCHAR(32) DEFAULT NULL,
    p_transport_cost NUMERIC(10, 2) DEFAULT 0.00
)
RETURNS JSONB AS $$
DECLARE
    v_transfer internal_transfers%ROWTYPE;
    v_item transfer_items%ROWTYPE;
    v_inv inventory_items%ROWTYPE;
BEGIN
    SELECT * INTO v_transfer FROM internal_transfers WHERE id = p_transfer_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Transfer % not found', p_transfer_id;
    END IF;

    IF v_transfer.from_pharmacy_id <> p_actor_pharmacy_id THEN
        RAISE EXCEPTION 'Unauthorized: only sender branch can dispatch shipment';
    END IF;

    IF v_transfer.status = 'in_transit' THEN
        RETURN jsonb_build_object('success', true, 'message', 'Already dispatched', 'status', 'in_transit');
    END IF;

    IF v_transfer.status <> 'approved_and_reserved' AND v_transfer.status <> 'in_preparation' THEN
        RAISE EXCEPTION 'Cannot dispatch transfer in status %', v_transfer.status;
    END IF;

    -- Process items and apply physical inventory deduction once
    FOR v_item IN SELECT * FROM transfer_items WHERE transfer_id = p_transfer_id LOOP
        SELECT * INTO v_inv FROM inventory_items WHERE id = v_item.inventory_item_id FOR UPDATE;

        IF v_inv.physical_quantity < v_item.quantity_requested THEN
            RAISE EXCEPTION 'Critical: physical inventory deficit during dispatch for %', v_item.drug_name_snapshot;
        END IF;

        -- 1. Deduct physical quantity once
        UPDATE inventory_items
        SET physical_quantity = physical_quantity - v_item.quantity_requested,
            updated_at = NOW()
        WHERE id = v_item.inventory_item_id;

        -- 2. Mark reservation as CONSUMED (NOT deleted or released!)
        UPDATE inventory_reservations
        SET status = 'consumed',
            consumed_at = NOW()
        WHERE transfer_id = p_transfer_id AND inventory_item_id = v_item.inventory_item_id AND status = 'active';

        -- 3. Set quantity_sent
        UPDATE transfer_items
        SET quantity_sent = v_item.quantity_requested
        WHERE id = v_item.id;

        -- 4. Ledger movement
        INSERT INTO inventory_movements (
            id, inventory_item_id, pharmacy_id, transfer_id, movement_type,
            delta_physical, delta_quarantine, balance_after_physical, balance_after_quarantine,
            actor_id, notes
        ) VALUES (
            'MOV-' || substr(md5(random()::text), 1, 12),
            v_item.inventory_item_id,
            v_transfer.from_pharmacy_id,
            p_transfer_id,
            'dispatch_deduction',
            -v_item.quantity_requested, 0,
            v_inv.physical_quantity - v_item.quantity_requested, v_inv.quarantine_quantity,
            p_actor_name,
            'Dispatched transfer ' || v_transfer.transfer_code || COALESCE(' - ' || p_notes, '')
        );
    END LOOP;

    -- Update transfer status to in_transit (تم الإرسال — بانتظار الاستلام)
    UPDATE internal_transfers SET
        status = 'in_transit',
        dispatched_by = p_actor_name,
        dispatched_at = NOW(),
        notes = COALESCE(p_notes, notes),
        courier_name = p_courier_name,
        courier_phone = p_courier_phone,
        transport_cost = COALESCE(p_transport_cost, transport_cost, 0.00),
        updated_at = NOW()
    WHERE id = p_transfer_id;

    RETURN jsonb_build_object('success', true, 'status', 'in_transit');
END;
$$ LANGUAGE plpgsql;

-- RPC 3: RECEIVE TRANSFER & RECONCILE DISCREPANCIES ATOMICALLY
CREATE OR REPLACE FUNCTION rpc_receive_transfer(
    p_transfer_id VARCHAR(64),
    p_actor_name VARCHAR(255),
    p_actor_pharmacy_id VARCHAR(64),
    p_receipt_lines JSONB, -- array of {item_id, accepted, rejected, missing, notes}
    p_idempotency_key VARCHAR(128)
)
RETURNS JSONB AS $$
DECLARE
    v_transfer internal_transfers%ROWTYPE;
    v_line JSONB;
    v_item transfer_items%ROWTYPE;
    v_dest_inv inventory_items%ROWTYPE;
    v_acc INT;
    v_rej INT;
    v_mis INT;
    v_has_discrepancy BOOLEAN := false;
BEGIN
    SELECT * INTO v_transfer FROM internal_transfers WHERE id = p_transfer_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Transfer % not found', p_transfer_id;
    END IF;

    IF v_transfer.to_pharmacy_id <> p_actor_pharmacy_id THEN
        RAISE EXCEPTION 'Unauthorized: only destination branch can confirm receipt';
    END IF;

    IF v_transfer.status = 'completed' OR v_transfer.status = 'needs_discrepancy_resolution' THEN
        RETURN jsonb_build_object('success', true, 'message', 'Already received', 'status', v_transfer.status);
    END IF;

    IF v_transfer.status <> 'in_transit' THEN
        RAISE EXCEPTION 'Transfer must be in_transit to confirm receipt';
    END IF;

    -- Process each receipt line
    FOR v_line IN SELECT * FROM jsonb_array_elements(p_receipt_lines) LOOP
        SELECT * INTO v_item FROM transfer_items 
        WHERE transfer_id = p_transfer_id AND id = (v_line->>'item_id') FOR UPDATE;

        v_acc := (v_line->>'accepted')::INT;
        v_rej := (v_line->>'rejected')::INT;
        v_mis := (v_line->>'missing')::INT;

        -- Mathematical balance verification: Sent = Accepted + Rejected + Missing
        IF v_item.quantity_sent <> (v_acc + v_rej + v_mis) THEN
            RAISE EXCEPTION 'Line balance mismatch for %. Sent: %, Sum of receipt: %',
                v_item.drug_name_snapshot, v_item.quantity_sent, (v_acc + v_rej + v_mis);
        END IF;

        IF v_rej > 0 OR v_mis > 0 THEN
            v_has_discrepancy := true;
        END IF;

        -- Update line item
        UPDATE transfer_items SET
            quantity_accepted = v_acc,
            quantity_rejected = v_rej,
            quantity_missing = v_mis
        WHERE id = v_item.id;

        -- Find or create destination inventory record for this batch
        SELECT * INTO v_dest_inv FROM inventory_items
        WHERE pharmacy_id = v_transfer.to_pharmacy_id 
          AND brand_name = v_item.drug_name_snapshot 
          AND batch_number = v_item.batch_snapshot FOR UPDATE;

        IF NOT FOUND THEN
            -- Insert new batch record at destination
            INSERT INTO inventory_items (
                id, pharmacy_id, brand_name, batch_number, expiry_date, unit,
                physical_quantity, quarantine_quantity
            ) VALUES (
                'INV-' || substr(md5(random()::text), 1, 12),
                v_transfer.to_pharmacy_id,
                v_item.drug_name_snapshot,
                v_item.batch_snapshot,
                v_item.expiry_snapshot,
                v_item.unit_snapshot,
                v_acc,
                v_rej
            ) RETURNING * INTO v_dest_inv;
        ELSE
            -- Update destination physical (+accepted) and quarantine (+rejected)
            UPDATE inventory_items SET
                physical_quantity = physical_quantity + v_acc,
                quarantine_quantity = quarantine_quantity + v_rej,
                updated_at = NOW()
            WHERE id = v_dest_inv.id
            RETURNING * INTO v_dest_inv;
        END IF;

        -- Ledger entry for accepted quantity
        IF v_acc > 0 THEN
            INSERT INTO inventory_movements (
                id, inventory_item_id, pharmacy_id, transfer_id, movement_type,
                delta_physical, delta_quarantine, balance_after_physical, balance_after_quarantine,
                actor_id, notes
            ) VALUES (
                'MOV-' || substr(md5(random()::text), 1, 12),
                v_dest_inv.id,
                v_transfer.to_pharmacy_id,
                p_transfer_id,
                'receipt_accepted_addition',
                v_acc, 0, v_dest_inv.physical_quantity, v_dest_inv.quarantine_quantity,
                p_actor_name,
                'Accepted stock from transfer ' || v_transfer.transfer_code
            );
        END IF;

        -- Ledger entry and discrepancy record for rejected/damaged quantity (in quarantine custody)
        IF v_rej > 0 THEN
            INSERT INTO inventory_movements (
                id, inventory_item_id, pharmacy_id, transfer_id, movement_type,
                delta_physical, delta_quarantine, balance_after_physical, balance_after_quarantine,
                actor_id, notes
            ) VALUES (
                'MOV-' || substr(md5(random()::text), 1, 12),
                v_dest_inv.id,
                v_transfer.to_pharmacy_id,
                p_transfer_id,
                'receipt_quarantine_addition',
                0, v_rej, v_dest_inv.physical_quantity, v_dest_inv.quarantine_quantity,
                p_actor_name,
                'Quarantine intake for damaged/rejected items'
            );

            INSERT INTO transfer_discrepancies (
                id, transfer_id, transfer_item_id, discrepancy_type, quantity,
                reason, notes, resolution_status
            ) VALUES (
                'DISC-' || substr(md5(random()::text), 1, 12),
                p_transfer_id,
                v_item.id,
                'rejected_damaged',
                v_rej,
                COALESCE(v_line->>'reject_reason', 'بضاعة تالفة أو غير مطابقة عند الفحص'),
                v_line->>'notes',
                'pending_investigation'
            );
        END IF;

        -- Record missing quantity (under investigation, NOT added to receiver, NOT restored to sender)
        IF v_mis > 0 THEN
            INSERT INTO transfer_discrepancies (
                id, transfer_id, transfer_item_id, discrepancy_type, quantity,
                reason, notes, resolution_status
            ) VALUES (
                'DISC-' || substr(md5(random()::text), 1, 12),
                p_transfer_id,
                v_item.id,
                'missing_investigation',
                v_mis,
                COALESCE(v_line->>'missing_reason', 'عجز في عدد العبوات المسلمة مع الناقل'),
                v_line->>'notes',
                'pending_investigation'
            );
        END IF;
    END LOOP;

    -- Update final transfer status
    IF v_has_discrepancy THEN
        UPDATE internal_transfers SET
            status = 'needs_discrepancy_resolution',
            received_by = p_actor_name,
            received_at = NOW(),
            updated_at = NOW()
        WHERE id = p_transfer_id;
    ELSE
        UPDATE internal_transfers SET
            status = 'completed',
            received_by = p_actor_name,
            received_at = NOW(),
            updated_at = NOW()
        WHERE id = p_transfer_id;
    END IF;

    RETURN jsonb_build_object(
        'success', true, 
        'status', CASE WHEN v_has_discrepancy THEN 'needs_discrepancy_resolution' ELSE 'completed' END,
        'has_discrepancy', v_has_discrepancy
    );
END;
$$ LANGUAGE plpgsql;
